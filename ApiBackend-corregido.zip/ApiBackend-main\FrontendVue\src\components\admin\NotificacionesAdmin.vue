<script setup>
import { ref, computed, onMounted } from 'vue';
import api from '@/api/axios';
import { toast } from '@/ui/feedback';
import { fechaHora, haceCuanto, mensajeError } from '@/utils/format';
import AppIcon from '@/ui/AppIcon.vue';
import EncabezadoPagina from '@/ui/EncabezadoPagina.vue';
import EstadoVacio from '@/ui/EstadoVacio.vue';

// Alertas de stock bajo y avisos del administrador para el usuario que inició sesión.
const items = ref([]);
const cargando = ref(true);
const errorCarga = ref('');
const soloNoLeidas = ref(false);

async function cargar() {
  cargando.value = true;
  errorCarga.value = '';
  try {
    items.value = (await api.get('/notificaciones')).data || [];
  } catch (e) {
    errorCarga.value = mensajeError(e, 'No se pudieron cargar las notificaciones.');
  } finally {
    cargando.value = false;
  }
}

const noLeidas = computed(() => items.value.filter((n) => !n.leido).length);
const visibles = computed(() => (soloNoLeidas.value ? items.value.filter((n) => !n.leido) : items.value));
const esAlertaStock = (n) => /stock bajo/i.test(n.mensaje);

async function leer(n) {
  try {
    await api.post(`/notificaciones/${n.id}/leer`);
    n.leido = true;
  } catch (e) {
    toast.error(mensajeError(e));
  }
}
async function leerTodas() {
  try {
    await api.post('/notificaciones/leer-todas');
    items.value.forEach((n) => (n.leido = true));
    toast.ok('Todas las notificaciones quedaron como leídas.');
  } catch (e) {
    toast.error(mensajeError(e));
  }
}
async function quitar(n) {
  try {
    await api.delete(`/notificaciones/${n.id}`);
    items.value = items.value.filter((x) => x.id !== n.id);
  } catch (e) {
    toast.error(mensajeError(e));
  }
}

onMounted(cargar);
</script>

<template>
  <div>
    <EncabezadoPagina titulo="Notificaciones" :subtitulo="noLeidas ? `${noLeidas} sin leer` : 'Estás al día'">
      <div class="segmentos" role="group" aria-label="Filtrar">
        <button type="button" class="segmento" :class="{ activo: !soloNoLeidas }" @click="soloNoLeidas = false">Todas</button>
        <button type="button" class="segmento" :class="{ activo: soloNoLeidas }" @click="soloNoLeidas = true">Sin leer</button>
      </div>
      <button type="button" class="btn btn-secundario" :disabled="!noLeidas" @click="leerTodas"><AppIcon name="check" :size="16" /> Marcar todas como leídas</button>
    </EncabezadoPagina>

    <div v-if="errorCarga" class="aviso-linea error" role="alert" style="margin-bottom: 16px">
      <AppIcon name="alert" :size="18" /> <span class="crece">{{ errorCarga }}</span>
      <button type="button" class="btn btn-secundario btn-sm" @click="cargar">Reintentar</button>
    </div>

    <div class="tarjeta">
      <div v-if="cargando" class="tarjeta-cuerpo pila-sm"><span class="esqueleto"></span><span class="esqueleto"></span><span class="esqueleto"></span></div>
      <EstadoVacio v-else-if="!visibles.length" icono="bell" :titulo="soloNoLeidas ? 'No hay notificaciones sin leer' : 'No tenés notificaciones'" texto="Acá vas a ver las alertas de stock bajo y los avisos del administrador." />
      <ul v-else class="lista">
        <li v-for="n in visibles" :key="n.id" class="noti" :class="{ nueva: !n.leido }">
          <div class="icono" :class="{ alerta: esAlertaStock(n) }"><AppIcon :name="esAlertaStock(n) ? 'alert' : 'bell'" :size="18" /></div>
          <div class="crece">
            <p :class="{ negrita: !n.leido }">{{ n.mensaje }}</p>
            <p class="texto-chico texto-tenue" :title="fechaHora(n.fecha)">{{ haceCuanto(n.fecha) }}</p>
          </div>
          <button v-if="!n.leido" type="button" class="btn btn-secundario btn-sm" @click="leer(n)">Marcar leída</button>
          <button type="button" class="btn btn-fantasma btn-sm btn-icono" aria-label="Eliminar notificación" @click="quitar(n)"><AppIcon name="trash" :size="16" /></button>
        </li>
      </ul>
    </div>
  </div>
</template>

<style scoped>
.lista { list-style: none; margin: 0; padding: 0; }
.noti { display: flex; align-items: center; gap: 14px; padding: 14px 18px; border-bottom: 1px solid var(--borde); }
.noti:last-child { border-bottom: none; }
.noti.nueva { background: #fffaf0; box-shadow: inset 3px 0 0 var(--marca); }
.icono { flex: none; width: 36px; height: 36px; border-radius: 50%; display: grid; place-items: center; background: var(--info-suave); color: var(--info); }
.icono.alerta { background: var(--aviso-suave); color: var(--aviso); }
</style>
