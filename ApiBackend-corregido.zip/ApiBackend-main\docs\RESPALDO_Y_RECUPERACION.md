# Respaldo y recuperación de la base de datos

## Qué se respalda y cómo

Se usa `BACKUP DATABASE` de SQL Server con `CHECKSUM`, y cada respaldo se verifica con `RESTORE VERIFYONLY`.
Hay tres formas de hacerlo; todas generan el mismo tipo de archivo `DB_Panaderia2_AAAAMMDD_HHMMSS.bak`.

| Forma | Cuándo |
|---|---|
| **Automático** | La API hace un respaldo por día a las 06:00 UTC (02:00 en Bolivia). Se ajusta con `Backup__HoraUtc` y se apaga con `Backup__Automatico=false`. |
| **Desde el panel** | *Sistema y respaldos → Hacer respaldo ahora* (solo administrador). Muestra también el historial. |
| **Por script** | `.\scripts\respaldar.ps1` (útil para el Programador de tareas de Windows). Borra los respaldos propios de más de 14 días (`-DiasRetencion`). |

**Dónde quedan los archivos**
- SQL Server local: la carpeta de respaldos de la instancia (por ejemplo
  `C:\Program Files\Microsoft SQL Server\MSSQL17.SQLEXPRESS\MSSQL\Backup`). Se cambia con `Backup__Carpeta`.
- Docker: el volumen `mssql_backups`, montado en `/var/opt/mssql/backup`.

> **Importante:** un respaldo en el mismo disco que la base no protege contra la pérdida del disco ni del
> equipo. Copiá periódicamente los `.bak` a otro lugar (disco externo, nube).

## Cómo restaurar

La restauración reemplaza todos los datos actuales, por eso **no se hace desde la API**.

1. Detené el backend (`.\scripts\detener-local.ps1` o `docker compose stop backend`).
2. Elegí el archivo `.bak` (el historial del panel o `GET /api/respaldos` lista los últimos).
3. Ejecutá:
   ```powershell
   .\scripts\restaurar.ps1 -Archivo "C:\ruta\DB_Panaderia2_20261021_060000.bak" -Confirmar
   ```
   Sin `-Confirmar` el script solo muestra qué haría. Verifica el archivo, cierra las conexiones abiertas,
   restaura y deja la base de nuevo en modo multiusuario.
4. Iniciá el backend de nuevo.

**Ensayo sin riesgo:** restaurá en otra base para comprobar que el respaldo sirve, sin tocar la real:

```powershell
.\scripts\restaurar.ps1 -Archivo "<archivo>.bak" -Base DB_Panaderia2_ensayo -Confirmar
```

En Docker agregá `-Servidor "localhost,1433" -Usuario sa -Clave "<SA_PASSWORD>"`.

## Programar el respaldo diario en Windows (opcional)

```powershell
$accion = New-ScheduledTaskAction -Execute "powershell.exe" -Argument '-NoProfile -File "C:\ruta\al\proyecto\scripts\respaldar.ps1"'
$disparador = New-ScheduledTaskTrigger -Daily -At 2am
Register-ScheduledTask -TaskName "Respaldo Kiataque" -Action $accion -Trigger $disparador
```

## Comprobado

El respaldo y la restauración se probaron de punta a punta: se respaldó una base con ventas, pedidos y
movimientos de inventario, se restauró en otra base y los datos coincidieron (usuarios, ventas, pedidos y
movimientos).
