﻿<#
.SYNOPSIS
  Arma un entorno de DEMOSTRACIÓN aislado (no toca tu base real):
    - base nueva DB_Panaderia2_demo
    - API en http://localhost:5209  y  frontend en http://localhost:5174
  Luego ejecutá  .\scripts\demo_requisitos.ps1  para cargar datos y ver los 11 requisitos.

  Para volver a empezar de cero basta con ejecutar este script otra vez.
#>
param([string]$Servidor = ".\SQLEXPRESS", [string]$Base = "DB_Panaderia2_demo")
$ErrorActionPreference = 'Stop'
$raiz = Split-Path -Parent $PSScriptRoot
$tmp = Join-Path $env:TEMP "kiataque-demo"
New-Item -ItemType Directory -Force $tmp | Out-Null

# Detiene solo la demo anterior (puertos 5209 y 5174), nunca el proyecto real.
Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -match '5209|5174' -and $_.Name -in 'dotnet.exe', 'node.exe' } |
    ForEach-Object { Stop-Process -Id $_.ProcessId -Force }
Start-Sleep 2

foreach ($f in 'init', '02_requisitos') {
    (Get-Content (Join-Path $raiz "db\$f.sql") -Raw -Encoding UTF8) -replace 'DB_Panaderia2', $Base | Set-Content "$tmp\$f.sql" -Encoding UTF8
}
sqlcmd -S $Servidor -E -C -Q "IF DB_ID('$Base') IS NOT NULL BEGIN ALTER DATABASE [$Base] SET SINGLE_USER WITH ROLLBACK IMMEDIATE; DROP DATABASE [$Base]; END" | Out-Null
sqlcmd -S $Servidor -E -C -b -i "$tmp\init.sql" | Out-Null
sqlcmd -S $Servidor -E -C -b -i "$tmp\02_requisitos.sql" | Out-Null

$env:ConnectionStrings__ConexionDB = "Server=$Servidor;Database=$Base;Trusted_Connection=True;TrustServerCertificate=True;"
$env:Jwt__Key = "clave-demo-kiataque-0123456789-abcdefghijklmnop"
$env:ASPNETCORE_ENVIRONMENT = "Development"
$env:Setup__Usuario = "instalador@kiataque.local"
$env:Setup__Clave = "Instal-Demo-2026!"
$env:Backup__Automatico = "false"
$env:Cors__Origins__0 = "http://localhost:5174"
$env:Cors__Origins__1 = "http://127.0.0.1:5174"
# La presentación inicia sesión varias veces seguidas: límite algo mayor que el normal (8/min).
$env:RateLimit__LoginPorMinuto = "15"
Start-Process dotnet -ArgumentList "run --project `"$raiz\BackendApi`" --no-launch-profile --urls http://localhost:5209" -WindowStyle Hidden `
    -RedirectStandardOutput "$tmp\back.log" -RedirectStandardError "$tmp\back.err"
$env:VITE_API_URL = "http://127.0.0.1:5209/api"
Start-Process npm.cmd -ArgumentList "run dev -- --host 127.0.0.1 --port 5174 --strictPort" -WorkingDirectory (Join-Path $raiz "FrontendVue") -WindowStyle Hidden `
    -RedirectStandardOutput "$tmp\front.log" -RedirectStandardError "$tmp\front.err"

for ($i = 0; $i -lt 40; $i++) {
    Start-Sleep 1
    try { if ((Invoke-WebRequest http://localhost:5209/api/productos -UseBasicParsing -TimeoutSec 2).StatusCode -eq 200) { break } } catch { }
}
Write-Host "Demo lista:  API http://localhost:5209/swagger   Frontend http://127.0.0.1:5174" -ForegroundColor Green
