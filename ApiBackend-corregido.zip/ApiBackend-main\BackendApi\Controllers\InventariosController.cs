using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using BackendApi.Models;
using BackendApi.Services;

namespace BackendApi.Controllers;

public class MovimientoDto
{
    public string Tipo { get; set; } = string.Empty;
    public int Cantidad { get; set; }
    public string? Motivo { get; set; }
}

[ApiController]
[Route("api/[controller]")]
[Authorize(Policy = "Staff")]
public class InventariosController : ControllerBase
{
    private readonly ApplicationDbContext _context;
    private readonly InventarioService _inventario;
    private readonly AuditoriaService _auditoria;

    public InventariosController(ApplicationDbContext context, InventarioService inventario, AuditoriaService auditoria)
    {
        _context = context;
        _inventario = inventario;
        _auditoria = auditoria;
    }

    // Req. 9: cada sucursal ve su propio stock; el administrador ve todas.
    private IQueryable<Inventario> Visibles()
    {
        var q = _context.Inventarios.AsNoTracking().AsQueryable();
        var restringida = RolHelper.SucursalRestringida(User);
        return restringida.HasValue ? q.Where(i => i.SucursalId == restringida.Value) : q;
    }

    [HttpGet]
    public async Task<IActionResult> ObtenerInventarios([FromQuery] int? sucursalId)
    {
        var q = Visibles();
        if (sucursalId.HasValue) q = q.Where(i => i.SucursalId == sucursalId.Value);
        return Ok(await q.ToListAsync());
    }

    // Productos cuyo stock está en o bajo el mínimo configurado.
    [HttpGet("stock-bajo")]
    public async Task<IActionResult> StockBajo()
    {
        var bajos = await Visibles()
            .Where(i => i.StockMinimo != null && i.StockActual <= i.StockMinimo)
            .Select(i => new { i.Id, i.ProductoId, producto = i.Producto.Nombre, i.SucursalId, i.StockActual, i.StockMinimo })
            .ToListAsync();
        return Ok(bajos);
    }

    [HttpGet("{id}")]
    public async Task<IActionResult> ObtenerInventarioPorId(int id)
    {
        var inventario = await Visibles().FirstOrDefaultAsync(i => i.Id == id);

        if (inventario == null)
            return NotFound(new { mensaje = $"Inventario con id {id} no encontrado" });

        return Ok(inventario);
    }

    [Authorize(Policy = "Inventario")]
    [HttpPost]
    public async Task<IActionResult> CrearInventario([FromBody] Inventario nuevoInventario)
    {
        if (nuevoInventario == null)
            return BadRequest(new { mensaje = "Los datos del inventario son requeridos" });

        var restringida = RolHelper.SucursalRestringida(User);
        if (restringida.HasValue && nuevoInventario.SucursalId != restringida.Value)
            return Forbid();
        if (nuevoInventario.StockActual < 0 || nuevoInventario.StockMinimo < 0)
            return BadRequest(new { mensaje = "El stock no puede ser negativo" });
        if (!await _context.Productos.AnyAsync(p => p.Id == nuevoInventario.ProductoId))
            return BadRequest(new { mensaje = $"No existe el producto {nuevoInventario.ProductoId}" });
        if (!await _context.Sucursales.AnyAsync(s => s.Id == nuevoInventario.SucursalId))
            return BadRequest(new { mensaje = $"No existe la sucursal {nuevoInventario.SucursalId}" });
        if (await _context.Inventarios.AnyAsync(i => i.ProductoId == nuevoInventario.ProductoId && i.SucursalId == nuevoInventario.SucursalId))
            return Conflict(new { mensaje = "Ese producto ya tiene inventario en esa sucursal" });

        var inicial = nuevoInventario.StockActual;
        nuevoInventario.Id = 0;
        nuevoInventario.StockActual = 0;
        nuevoInventario.Producto = null!;
        nuevoInventario.Sucursal = null!;
        _context.Inventarios.Add(nuevoInventario);
        await _context.SaveChangesAsync();

        // El stock inicial entra como una ENTRADA para que quede en el historial.
        if (inicial > 0)
        {
            var r = await _inventario.AplicarMovimientoAsync(nuevoInventario.Id, "ENTRADA", inicial, "Stock inicial",
                RolHelper.UsuarioId(User) ?? 0, restringida);
            if (r.Ok) nuevoInventario.StockActual = r.StockActual ?? inicial;
        }

        return CreatedAtAction(nameof(ObtenerInventarioPorId), new { id = nuevoInventario.Id }, nuevoInventario);
    }

    // El stock solo cambia con movimientos (ENTRADA/SALIDA); acá se edita el mínimo de alerta.
    [Authorize(Policy = "Inventario")]
    [HttpPut("{id}")]
    public async Task<IActionResult> ActualizarInventario(int id, [FromBody] Inventario inventarioActualizado)
    {
        var inventario = await _context.Inventarios.FindAsync(id);
        var restringida = RolHelper.SucursalRestringida(User);

        if (inventario == null || (restringida.HasValue && inventario.SucursalId != restringida.Value))
            return NotFound(new { mensaje = $"Inventario con id {id} no encontrado" });
        if (inventarioActualizado.StockMinimo < 0)
            return BadRequest(new { mensaje = "El stock mínimo no puede ser negativo" });

        inventario.StockMinimo = inventarioActualizado.StockMinimo;
        await _context.SaveChangesAsync();

        return Ok(new { mensaje = "Inventario actualizado correctamente", inventario });
    }

    // Req. 1: registra una entrada o salida y actualiza el stock en una sola operación.
    [Authorize(Policy = "Inventario")]
    [HttpPost("{id}/movimiento")]
    public async Task<IActionResult> RegistrarMovimiento(int id, [FromBody] MovimientoDto dto)
    {
        var usuarioId = RolHelper.UsuarioId(User);
        if (usuarioId is null or 0) return Forbid();

        var r = await _inventario.AplicarMovimientoAsync(id, dto.Tipo, dto.Cantidad, dto.Motivo, usuarioId.Value, RolHelper.SucursalRestringida(User));
        if (!r.Ok) return StatusCode(r.Codigo, new { mensaje = r.Mensaje });

        return StatusCode(201, new { mensaje = r.Mensaje, stockActual = r.StockActual, movimientoId = r.Movimiento!.Id });
    }

    [Authorize(Policy = "Admin")]
    [HttpDelete("{id}")]
    public async Task<IActionResult> EliminarInventario(int id)
    {
        var inventario = await _context.Inventarios.FindAsync(id);

        if (inventario == null)
            return NotFound(new { mensaje = $"Inventario con id {id} no encontrado" });

        _context.Inventarios.Remove(inventario);
        await _context.SaveChangesAsync();
        await _auditoria.RegistrarAsync("ELIMINAR", "Inventario", $"Inventario {id}");

        return Ok(new { mensaje = $"Inventario {id} eliminado correctamente" });
    }
}
