<script setup>
defineProps({ titulo: String, subtitulo: String });
</script>

<template>
  <div class="encabezado-pagina">
    <div class="crece">
      <h2>{{ titulo }}</h2>
      <p v-if="subtitulo" class="texto-suave">{{ subtitulo }}</p>
    </div>
    <div v-if="$slots.default" class="fila fila-envolver acciones"><slot /></div>
  </div>
</template>

<style scoped>
.encabezado-pagina {
  display: flex;
  align-items: flex-end;
  justify-content: space-between;
  gap: 16px;
  flex-wrap: wrap;
  margin-bottom: 22px;
}
.encabezado-pagina p { margin-top: 2px; }
</style>
