// Avisos flotantes (toast) y diálogo de confirmación, compartidos por toda la app.
// Reemplazan a alert() / confirm() del navegador.
import { reactive } from 'vue';

export const toasts = reactive([]);
let siguienteId = 1;

export function quitarToast(id) {
  const i = toasts.findIndex((t) => t.id === id);
  if (i >= 0) toasts.splice(i, 1);
}

function mostrar(tipo, mensaje, ms = 4500) {
  const id = siguienteId++;
  toasts.push({ id, tipo, mensaje });
  if (toasts.length > 4) toasts.shift();
  if (ms > 0) setTimeout(() => quitarToast(id), ms);
  return id;
}

export const toast = {
  ok: (m, ms) => mostrar('ok', m, ms),
  error: (m, ms = 7000) => mostrar('error', m, ms),
  aviso: (m, ms) => mostrar('aviso', m, ms),
  info: (m, ms) => mostrar('info', m, ms),
};

export const dialogo = reactive({
  abierto: false,
  titulo: '',
  mensaje: '',
  textoOk: 'Aceptar',
  textoCancelar: 'Cancelar',
  peligro: false,
  resolver: null,
});

// const si = await confirmar({ titulo, mensaje, textoOk, peligro: true })
export function confirmar({ titulo = '¿Confirmás?', mensaje = '', textoOk = 'Aceptar', textoCancelar = 'Cancelar', peligro = false } = {}) {
  return new Promise((resolver) => {
    Object.assign(dialogo, { abierto: true, titulo, mensaje, textoOk, textoCancelar, peligro, resolver });
  });
}

export function responderDialogo(valor) {
  const r = dialogo.resolver;
  dialogo.abierto = false;
  dialogo.resolver = null;
  if (r) r(valor);
}
