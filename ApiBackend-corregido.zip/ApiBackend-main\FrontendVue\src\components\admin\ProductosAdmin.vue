<script setup>
import { ref, computed, onMounted } from 'vue';
import api from '@/api/axios';
import { puedeVer } from '@/store';
import { toast, confirmar } from '@/ui/feedback';
import { bs, mensajeError, descargarCsv } from '@/utils/format';
import AppIcon from '@/ui/AppIcon.vue';
import AppModal from '@/ui/AppModal.vue';
import Campo from '@/ui/Campo.vue';
import EncabezadoPagina from '@/ui/EncabezadoPagina.vue';
import EstadoVacio from '@/ui/EstadoVacio.vue';
import ImagenProducto from '@/ui/ImagenProducto.vue';
import Insignia from '@/ui/Insignia.vue';

const productos = ref([]);
const categorias = ref([]);
const proveedores = ref([]);
const cargando = ref(true);
const errorCarga = ref('');

// Solo administración e inventario modifican productos (el cajero los consulta).
const puedeEditar = puedeVer('inventario');

const busqueda = ref('');
const categoriaSel = ref(0);
const vista = ref('cuadricula'); // cuadricula | lista

async function cargar() {
  cargando.value = true;
  errorCarga.value = '';
  try {
    const [p, c, pr] = await Promise.all([
      api.get('/productos'),
      api.get('/categorias').catch(() => ({ data: [] })),
      api.get('/proveedores').catch(() => ({ data: [] })),
    ]);
    productos.value = p.data || [];
    categorias.value = c.data || [];
    proveedores.value = pr.data || [];
  } catch (e) {
    errorCarga.value = mensajeError(e, 'No se pudieron cargar los productos.');
  } finally {
    cargando.value = false;
  }
}

const nombreCategoria = (id) => categorias.value.find((c) => c.id === id)?.nombre || 'Sin categoría';

const filtrados = computed(() => {
  const t = busqueda.value.trim().toLowerCase();
  return productos.value.filter(
    (p) => (categoriaSel.value === 0 || p.categoriaId === categoriaSel.value) && (!t || (p.nombre || '').toLowerCase().includes(t))
  );
});

function estadoStock(s) {
  const n = s ?? 0;
  if (n <= 0) return { tono: 'peligro', texto: 'Sin stock' };
  if (n < 15) return { tono: 'aviso', texto: `${n} u. · bajo` };
  return { tono: 'ok', texto: `${n} u.` };
}

// ----- Formulario -----
const modal = ref(false);
const editandoId = ref(null);
const guardando = ref(false);
const form = ref({});
const errores = ref({});

const vacio = () => ({
  nombre: '',
  precio: '',
  stock: 0,
  categoriaId: null,
  proveedorId: null,
  emprendimientoId: categorias.value[0]?.emprendimientoId ?? 1,
  imagenUrl: '',
});

function abrirNuevo() {
  editandoId.value = null;
  form.value = vacio();
  errores.value = {};
  modal.value = true;
}
function abrirEditar(p) {
  editandoId.value = p.id;
  form.value = { ...vacio(), ...p, imagenUrl: p.imagenUrl || '' };
  errores.value = {};
  modal.value = true;
}

function validar() {
  const e = {};
  const f = form.value;
  if (!f.nombre?.trim()) e.nombre = 'Poné un nombre al producto.';
  const precio = Number(f.precio);
  if (f.precio === '' || isNaN(precio) || precio < 0) e.precio = 'El precio tiene que ser un número mayor o igual a 0.';
  const stock = Number(f.stock);
  if (isNaN(stock) || stock < 0 || !Number.isInteger(stock)) e.stock = 'El stock tiene que ser un número entero mayor o igual a 0.';
  if (f.imagenUrl && !/^https?:\/\//i.test(f.imagenUrl.trim())) e.imagenUrl = 'Pegá un enlace que empiece con http:// o https://';
  errores.value = e;
  return !Object.keys(e).length;
}

async function guardar() {
  if (!validar()) return;
  guardando.value = true;
  try {
    const cuerpo = {
      ...form.value,
      nombre: form.value.nombre.trim(),
      precio: Number(form.value.precio),
      stock: Number(form.value.stock),
      imagenUrl: (form.value.imagenUrl || '').trim() || null,
    };
    if (editandoId.value) await api.put('/productos/' + editandoId.value, cuerpo);
    else await api.post('/productos', cuerpo);
    toast.ok(editandoId.value ? 'Producto actualizado.' : 'Producto creado.');
    modal.value = false;
    await cargar();
  } catch (e) {
    toast.error(mensajeError(e, 'No se pudo guardar el producto.'));
  } finally {
    guardando.value = false;
  }
}

async function eliminar(p) {
  const si = await confirmar({
    titulo: 'Eliminar producto',
    mensaje: `¿Eliminar "${p.nombre}"? Si ya tiene ventas registradas, el sistema no lo va a permitir.`,
    textoOk: 'Eliminar',
    peligro: true,
  });
  if (!si) return;
  try {
    await api.delete('/productos/' + p.id);
    toast.ok('Producto eliminado.');
    await cargar();
  } catch (e) {
    toast.error(mensajeError(e, 'No se pudo eliminar el producto.'));
  }
}

function exportar() {
  descargarCsv('productos.csv', [
    ['Producto', 'Categoría', 'Precio', 'Stock'],
    ...filtrados.value.map((p) => [p.nombre, nombreCategoria(p.categoriaId), p.precio, p.stock ?? 0]),
  ]);
}

onMounted(cargar);
</script>

<template>
  <div>
    <EncabezadoPagina titulo="Productos" :subtitulo="`${productos.length} en el catálogo`">
      <button type="button" class="btn btn-secundario" :disabled="!filtrados.length" @click="exportar"><AppIcon name="download" :size="16" /> Exportar</button>
      <button v-if="puedeEditar" type="button" class="btn btn-primario" @click="abrirNuevo"><AppIcon name="plus" :size="16" /> Nuevo producto</button>
    </EncabezadoPagina>

    <div v-if="errorCarga" class="aviso-linea error" role="alert" style="margin-bottom: 16px">
      <AppIcon name="alert" :size="18" /> <span class="crece">{{ errorCarga }}</span>
      <button type="button" class="btn btn-secundario btn-sm" @click="cargar">Reintentar</button>
    </div>

    <div class="barra-filtros">
      <div class="entrada-icono buscador">
        <AppIcon name="search" :size="17" class="icono-izq" />
        <input v-model="busqueda" type="search" placeholder="Buscar producto..." aria-label="Buscar producto" />
      </div>
      <div class="chips" role="group" aria-label="Filtrar por categoría">
        <button type="button" class="chip" :class="{ activo: categoriaSel === 0 }" @click="categoriaSel = 0">Todas</button>
        <button v-for="c in categorias" :key="c.id" type="button" class="chip" :class="{ activo: categoriaSel === c.id }" @click="categoriaSel = c.id">{{ c.nombre }}</button>
      </div>
      <div class="segmentos" role="group" aria-label="Tipo de vista">
        <button type="button" class="segmento" :class="{ activo: vista === 'cuadricula' }" aria-label="Cuadrícula" @click="vista = 'cuadricula'"><AppIcon name="grid" :size="16" /></button>
        <button type="button" class="segmento" :class="{ activo: vista === 'lista' }" aria-label="Lista" @click="vista = 'lista'"><AppIcon name="list" :size="16" /></button>
      </div>
    </div>

    <div v-if="cargando" class="cuadricula">
      <div v-for="n in 8" :key="n" class="tarjeta"><span class="esqueleto" style="height: 150px; border-radius: 12px 12px 0 0"></span><div class="tarjeta-cuerpo pila-sm"><span class="esqueleto"></span><span class="esqueleto" style="width: 50%"></span></div></div>
    </div>

    <div v-else-if="!filtrados.length" class="tarjeta">
      <EstadoVacio
        icono="package"
        :titulo="productos.length ? 'No hay productos con ese filtro' : 'Todavía no hay productos'"
        :texto="productos.length ? 'Probá con otra búsqueda o categoría.' : 'Cargá el primer producto para armar tu catálogo.'"
      >
        <button v-if="puedeEditar && !productos.length" type="button" class="btn btn-primario" @click="abrirNuevo"><AppIcon name="plus" :size="16" /> Crear producto</button>
      </EstadoVacio>
    </div>

    <div v-else-if="vista === 'cuadricula'" class="cuadricula">
      <article v-for="p in filtrados" :key="p.id" class="tarjeta producto">
        <div class="foto"><ImagenProducto :url="p.imagenUrl" :nombre="p.nombre" /></div>
        <div class="datos">
          <div class="texto-tenue texto-chico">{{ nombreCategoria(p.categoriaId) }}</div>
          <h3 class="truncar" :title="p.nombre">{{ p.nombre }}</h3>
          <div class="fila entre">
            <strong class="precio numeros">{{ bs(p.precio) }}</strong>
            <Insignia :tono="estadoStock(p.stock).tono">{{ estadoStock(p.stock).texto }}</Insignia>
          </div>
        </div>
        <div v-if="puedeEditar" class="acciones-prod">
          <button type="button" class="btn btn-secundario btn-sm crece" @click="abrirEditar(p)"><AppIcon name="edit" :size="15" /> Editar</button>
          <button type="button" class="btn btn-peligro btn-sm btn-icono" :aria-label="`Eliminar ${p.nombre}`" @click="eliminar(p)"><AppIcon name="trash" :size="15" /></button>
        </div>
      </article>
    </div>

    <div v-else class="tarjeta tabla-contenedor">
      <table class="tabla">
        <thead><tr><th>Producto</th><th>Categoría</th><th class="num">Precio</th><th>Stock</th><th v-if="puedeEditar" class="acciones">Acciones</th></tr></thead>
        <tbody>
          <tr v-for="p in filtrados" :key="p.id">
            <td><div class="fila"><div class="mini"><ImagenProducto :url="p.imagenUrl" :nombre="p.nombre" /></div><strong>{{ p.nombre }}</strong></div></td>
            <td>{{ nombreCategoria(p.categoriaId) }}</td>
            <td class="num">{{ bs(p.precio) }}</td>
            <td><Insignia :tono="estadoStock(p.stock).tono">{{ estadoStock(p.stock).texto }}</Insignia></td>
            <td v-if="puedeEditar" class="acciones">
              <button type="button" class="btn btn-secundario btn-sm" @click="abrirEditar(p)"><AppIcon name="edit" :size="15" /> Editar</button>
              <button type="button" class="btn btn-peligro btn-sm btn-icono" :aria-label="`Eliminar ${p.nombre}`" @click="eliminar(p)"><AppIcon name="trash" :size="15" /></button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>

    <AppModal v-model="modal" :titulo="editandoId ? 'Editar producto' : 'Nuevo producto'" tamano="lg">
      <form id="form-producto" class="formulario dos" novalidate @submit.prevent="guardar">
        <Campo label="Nombre" requerido :error="errores.nombre" class="ancho-total" v-slot="{ id, invalido }">
          <input :id="id" v-model="form.nombre" maxlength="200" :aria-invalid="invalido" />
        </Campo>
        <Campo label="Precio (Bs)" requerido :error="errores.precio" v-slot="{ id, invalido }">
          <input :id="id" v-model="form.precio" type="number" min="0" step="0.01" inputmode="decimal" :aria-invalid="invalido" />
        </Campo>
        <Campo label="Stock" :error="errores.stock" ayuda="Unidades generales. El stock por sucursal se maneja en Inventario." v-slot="{ id, invalido }">
          <input :id="id" v-model="form.stock" type="number" min="0" step="1" :aria-invalid="invalido" />
        </Campo>
        <Campo label="Categoría" v-slot="{ id }">
          <select :id="id" v-model="form.categoriaId">
            <option :value="null">Sin categoría</option>
            <option v-for="c in categorias" :key="c.id" :value="c.id">{{ c.nombre }}</option>
          </select>
        </Campo>
        <Campo label="Proveedor" v-slot="{ id }">
          <select :id="id" v-model="form.proveedorId">
            <option :value="null">Sin proveedor</option>
            <option v-for="p in proveedores" :key="p.id" :value="p.id">{{ p.nombre }}</option>
          </select>
        </Campo>
        <Campo label="Foto (enlace)" :error="errores.imagenUrl" ayuda="Pegá el enlace de una imagen. Si no hay foto se muestra la inicial." class="ancho-total" v-slot="{ id, invalido }">
          <div class="fila" style="align-items: flex-start">
            <input :id="id" v-model="form.imagenUrl" type="url" placeholder="https://..." :aria-invalid="invalido" />
            <div class="vista-previa"><ImagenProducto :url="form.imagenUrl" :nombre="form.nombre" /></div>
          </div>
        </Campo>
      </form>
      <template #pie>
        <button type="button" class="btn btn-secundario" @click="modal = false">Cancelar</button>
        <button type="submit" form="form-producto" class="btn btn-primario" :disabled="guardando">{{ guardando ? 'Guardando...' : 'Guardar' }}</button>
      </template>
    </AppModal>
  </div>
</template>

<style scoped>
.barra-filtros { display: flex; gap: 14px; align-items: center; flex-wrap: wrap; margin-bottom: 20px; }
.buscador { width: min(300px, 100%); }
.barra-filtros .chips { flex: 1; }

.cuadricula { display: grid; grid-template-columns: repeat(auto-fill, minmax(210px, 1fr)); gap: 18px; }
.producto { overflow: hidden; display: flex; flex-direction: column; transition: box-shadow 0.15s, transform 0.15s; }
.producto:hover { box-shadow: var(--sombra-2); transform: translateY(-2px); }
.foto { aspect-ratio: 4 / 3; background: var(--superficie-2); }
.datos { padding: 14px 16px 10px; display: grid; gap: 4px; flex: 1; }
.precio { font-size: 17px; }
.acciones-prod { display: flex; gap: 8px; padding: 0 16px 14px; }
.mini { width: 40px; height: 40px; border-radius: 8px; overflow: hidden; flex: none; font-size: 1rem; }
.vista-previa { width: 72px; height: 72px; border-radius: 10px; overflow: hidden; flex: none; border: 1px solid var(--borde); font-size: 1.5rem; }
</style>
