// Definición de los módulos del panel: menú lateral y formularios de los módulos CRUD genéricos.
// Cada campo: { campo, etiqueta, tipo, opciones, requerido, ocultarEnTabla, ocultarEnForm, ayuda, min, max, maxlength }
// tipos: text | number | money | select | checkbox | date | password | textarea

// Menú lateral (las claves coinciden con accesoDeRol() de store.js).
export const MENU = [
  {
    seccion: 'Operación',
    items: [
      { clave: 'inicio', texto: 'Inicio', icono: 'home' },
      { clave: 'ventas', texto: 'Punto de venta', icono: 'receipt' },
      { clave: 'pedidos', texto: 'Pedidos', icono: 'clipboard' },
      { clave: 'inventario', texto: 'Inventario', icono: 'boxes' },
      { clave: 'productos', texto: 'Productos', icono: 'package' },
    ],
  },
  {
    seccion: 'Negocio',
    items: [
      { clave: 'clientes', texto: 'Clientes', icono: 'users' },
      { clave: 'categorias', texto: 'Categorías', icono: 'tag' },
      { clave: 'proveedores', texto: 'Proveedores', icono: 'truck' },
      { clave: 'promociones', texto: 'Promociones', icono: 'gift' },
      { clave: 'resenas', texto: 'Reseñas', icono: 'star' },
      { clave: 'reportes', texto: 'Reportes', icono: 'chart' },
    ],
  },
  {
    seccion: 'Administración',
    items: [
      { clave: 'usuarios', texto: 'Usuarios', icono: 'key' },
      { clave: 'roles', texto: 'Roles', icono: 'shield' },
      { clave: 'empleados', texto: 'Empleados', icono: 'user' },
      { clave: 'sucursales', texto: 'Sucursales', icono: 'store' },
      { clave: 'ciudades', texto: 'Ciudades', icono: 'pin' },
      { clave: 'metodospago', texto: 'Métodos de pago', icono: 'card' },
      { clave: 'emprendimientos', texto: 'Empresa', icono: 'building' },
      { clave: 'sistema', texto: 'Sistema y respaldos', icono: 'database' },
    ],
  },
];

// Pantallas con componente propio (el resto usa TablaCrud con la config de abajo).
export const MODULOS_PROPIOS = ['inicio', 'ventas', 'pedidos', 'inventario', 'productos', 'notificaciones', 'reportes', 'sistema'];

export const TITULOS = {
  inicio: 'Inicio',
  ventas: 'Punto de venta',
  pedidos: 'Pedidos',
  inventario: 'Inventario',
  productos: 'Productos',
  notificaciones: 'Notificaciones',
  reportes: 'Reportes',
  sistema: 'Sistema y respaldos',
};

const op = (lista, texto) => lista.map((x) => ({ valor: x.id, texto: texto(x) }));

// ref = { roles, ciudades, emprendimientos, usuarios, sucursales, productos, clientes } (arrays ya resueltos)
export function crearConfigs(ref) {
  const emp = op(ref.emprendimientos, (x) => x.nombre);
  const empDefecto = ref.emprendimientos[0]?.id ?? 1;
  const campoEmp = { campo: 'emprendimientoId', etiqueta: 'Empresa', tipo: 'select', opciones: emp, ocultarEnTabla: true, requerido: true };

  return {
    sucursales: {
      titulo: 'Sucursales',
      subtitulo: 'Locales de la panadería. Cada sucursal tiene su propio inventario, ventas y pedidos.',
      endpoint: '/sucursales',
      nombreItem: 'sucursal',
      nuevoModelo: () => ({ nombre: '', direccion: '', telefono: '', ciudadId: null, emprendimientoId: empDefecto }),
      campos: [
        { campo: 'nombre', etiqueta: 'Nombre', tipo: 'text', requerido: true, maxlength: 100 },
        { campo: 'direccion', etiqueta: 'Dirección', tipo: 'text', requerido: true, maxlength: 200 },
        { campo: 'telefono', etiqueta: 'Teléfono', tipo: 'text', maxlength: 30 },
        { campo: 'ciudadId', etiqueta: 'Ciudad', tipo: 'select', opciones: op(ref.ciudades, (x) => x.nombre), requerido: true },
        campoEmp,
      ],
    },
    categorias: {
      titulo: 'Categorías',
      subtitulo: 'Para ordenar los productos de la tienda',
      endpoint: '/categorias',
      nombreItem: 'categoría',
      nuevoModelo: () => ({ nombre: '', descripcion: '', emprendimientoId: empDefecto }),
      campos: [
        { campo: 'nombre', etiqueta: 'Nombre', tipo: 'text', requerido: true, maxlength: 100 },
        { campo: 'descripcion', etiqueta: 'Descripción', tipo: 'text', maxlength: 200 },
        campoEmp,
      ],
    },
    clientes: {
      titulo: 'Clientes',
      subtitulo: 'Personas que compraron o fueron registradas. Los datos personales se tratan con su consentimiento.',
      endpoint: '/clientes',
      nombreItem: 'cliente',
      nuevoModelo: () => ({ nombre: '', cI_NIT: '', telefono: '', email: '', direccion: '', emprendimientoId: empDefecto }),
      campos: [
        { campo: 'nombre', etiqueta: 'Nombre', tipo: 'text', requerido: true, maxlength: 120 },
        { campo: 'cI_NIT', etiqueta: 'CI / NIT', tipo: 'text', maxlength: 30 },
        { campo: 'telefono', etiqueta: 'Teléfono', tipo: 'text', maxlength: 30 },
        { campo: 'email', etiqueta: 'Correo', tipo: 'text', maxlength: 150 },
        { campo: 'direccion', etiqueta: 'Dirección', tipo: 'text', maxlength: 200 },
        campoEmp,
      ],
    },
    usuarios: {
      titulo: 'Usuarios',
      subtitulo: 'Quién puede entrar al sistema y con qué rol',
      endpoint: '/usuarios',
      nombreItem: 'usuario',
      nuevoModelo: () => ({ nombre: '', email: '', passwordHash: '', rolId: null, activo: true, emprendimientoId: empDefecto }),
      campos: [
        { campo: 'nombre', etiqueta: 'Nombre', tipo: 'text', requerido: true, maxlength: 100 },
        { campo: 'email', etiqueta: 'Correo', tipo: 'text', requerido: true, maxlength: 150 },
        {
          campo: 'passwordHash',
          etiqueta: 'Contraseña',
          tipo: 'password',
          ocultarEnTabla: true,
          ayuda: 'Mínimo 8 caracteres con mayúscula, minúscula y número. Al editar, dejala vacía para no cambiarla.',
          requeridoAlCrear: true,
        },
        { campo: 'rolId', etiqueta: 'Rol', tipo: 'select', opciones: op(ref.roles, (x) => x.nombre), requerido: true },
        { campo: 'activo', etiqueta: 'Activo', tipo: 'checkbox', ayuda: 'Un usuario inactivo no puede iniciar sesión.' },
        campoEmp,
      ],
    },
    roles: {
      titulo: 'Roles',
      subtitulo: 'Los permisos dependen del nombre del rol: Administrador, Cajero, Vendedor o Inventario',
      endpoint: '/roles',
      nombreItem: 'rol',
      nuevoModelo: () => ({ nombre: '', descripcion: '' }),
      campos: [
        { campo: 'nombre', etiqueta: 'Nombre', tipo: 'text', requerido: true, maxlength: 100 },
        { campo: 'descripcion', etiqueta: 'Descripción', tipo: 'text', maxlength: 200 },
      ],
    },
    empleados: {
      titulo: 'Empleados por sucursal',
      subtitulo: 'Un empleado que no es administrador solo ve los datos de su sucursal',
      endpoint: '/empleados',
      nombreItem: 'empleado',
      nuevoModelo: () => ({ usuarioId: null, sucursalId: null, cargo: '', salario: 0 }),
      campos: [
        { campo: 'usuarioId', etiqueta: 'Usuario', tipo: 'select', opciones: op(ref.usuarios, (x) => `${x.nombre} (${x.email})`), requerido: true },
        { campo: 'sucursalId', etiqueta: 'Sucursal', tipo: 'select', opciones: op(ref.sucursales, (x) => x.nombre), requerido: true },
        { campo: 'cargo', etiqueta: 'Cargo', tipo: 'text', requerido: true, maxlength: 80 },
        { campo: 'salario', etiqueta: 'Salario', tipo: 'money', min: 0 },
      ],
    },
    promociones: {
      titulo: 'Promociones',
      subtitulo: 'Descuentos que se muestran en la tienda mientras están vigentes',
      endpoint: '/promociones',
      nombreItem: 'promoción',
      nuevoModelo: () => ({ nombre: '', descuento: 10, fechaInicio: '', fechaFin: '', emprendimientoId: empDefecto }),
      campos: [
        { campo: 'nombre', etiqueta: 'Nombre', tipo: 'text', requerido: true, maxlength: 100 },
        { campo: 'descuento', etiqueta: 'Descuento (%)', tipo: 'number', requerido: true, min: 0, max: 100 },
        { campo: 'fechaInicio', etiqueta: 'Desde', tipo: 'date', requerido: true },
        { campo: 'fechaFin', etiqueta: 'Hasta', tipo: 'date', requerido: true },
        campoEmp,
      ],
    },
    resenas: {
      titulo: 'Reseñas',
      subtitulo: 'Opiniones de clientes que compraron el producto. Podés moderarlas.',
      endpoint: '/resenas',
      nombreItem: 'reseña',
      sinCrear: true,
      campos: [
        { campo: 'productoId', etiqueta: 'Producto', tipo: 'select', opciones: op(ref.productos, (x) => x.nombre), ocultarEnForm: true },
        { campo: 'clienteId', etiqueta: 'Cliente', tipo: 'select', opciones: op(ref.clientes, (x) => x.nombre), ocultarEnForm: true },
        { campo: 'calificacion', etiqueta: 'Calificación', tipo: 'number', requerido: true, min: 1, max: 5 },
        { campo: 'comentario', etiqueta: 'Comentario', tipo: 'textarea', maxlength: 500 },
      ],
    },
    ciudades: {
      titulo: 'Ciudades',
      subtitulo: 'Ciudades y departamentos donde hay sucursales',
      endpoint: '/ciudades',
      nombreItem: 'ciudad',
      nuevoModelo: () => ({ nombre: '', departamento: '' }),
      campos: [
        { campo: 'nombre', etiqueta: 'Nombre', tipo: 'text', requerido: true, maxlength: 100 },
        { campo: 'departamento', etiqueta: 'Departamento', tipo: 'text', maxlength: 100 },
      ],
    },
    metodospago: {
      titulo: 'Métodos de pago',
      subtitulo: 'Formas de pago que se ofrecen en la tienda y el punto de venta',
      endpoint: '/metodospago',
      nombreItem: 'método de pago',
      nuevoModelo: () => ({ nombre: '', descripcion: '' }),
      campos: [
        { campo: 'nombre', etiqueta: 'Nombre', tipo: 'text', requerido: true, maxlength: 100 },
        { campo: 'descripcion', etiqueta: 'Descripción', tipo: 'text', maxlength: 200 },
      ],
    },
    proveedores: {
      titulo: 'Proveedores',
      subtitulo: 'Quién nos provee los insumos',
      endpoint: '/proveedores',
      nombreItem: 'proveedor',
      nuevoModelo: () => ({ nombre: '', contacto: '', telefono: '', email: '', emprendimientoId: empDefecto }),
      campos: [
        { campo: 'nombre', etiqueta: 'Nombre', tipo: 'text', requerido: true, maxlength: 120 },
        { campo: 'contacto', etiqueta: 'Contacto', tipo: 'text', maxlength: 100 },
        { campo: 'telefono', etiqueta: 'Teléfono', tipo: 'text', maxlength: 30 },
        { campo: 'email', etiqueta: 'Correo', tipo: 'text', maxlength: 150 },
        campoEmp,
      ],
    },
    emprendimientos: {
      titulo: 'Datos de la empresa',
      subtitulo: 'Información general del negocio',
      endpoint: '/emprendimientos',
      nombreItem: 'empresa',
      nuevoModelo: () => ({ nombre: '', nIT_RUC: '', direccion: '', telefono: '', email: '' }),
      campos: [
        { campo: 'nombre', etiqueta: 'Nombre', tipo: 'text', requerido: true, maxlength: 120 },
        { campo: 'nIT_RUC', etiqueta: 'NIT', tipo: 'text', maxlength: 30 },
        { campo: 'direccion', etiqueta: 'Dirección', tipo: 'text', maxlength: 200 },
        { campo: 'telefono', etiqueta: 'Teléfono', tipo: 'text', maxlength: 30 },
        { campo: 'email', etiqueta: 'Correo', tipo: 'text', maxlength: 150 },
      ],
    },
  };
}
