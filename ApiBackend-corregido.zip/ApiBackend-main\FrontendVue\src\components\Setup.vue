<script setup>
import { ref, computed } from 'vue';
import api from '@/api/axios';
import { store } from '@/store';
import { mensajeError } from '@/utils/format';
import AppIcon from '@/ui/AppIcon.vue';
import Campo from '@/ui/Campo.vue';

// Pantalla oculta: solo aparece cuando entra el super-usuario de instalación
// (credenciales Setup__Usuario / Setup__Clave del servidor) y todavía no hay administradores.
const nombre = ref('');
const email = ref('');
const clave = ref('');
const clave2 = ref('');
const verClave = ref(false);
const error = ref('');
const creado = ref(false);
const guardando = ref(false);

// Mismas reglas que el servidor: 8+ caracteres con mayúscula, minúscula y número.
const reglas = computed(() => [
  { texto: 'Al menos 8 caracteres', ok: clave.value.length >= 8 },
  { texto: 'Una mayúscula', ok: /[A-Z]/.test(clave.value) },
  { texto: 'Una minúscula', ok: /[a-z]/.test(clave.value) },
  { texto: 'Un número', ok: /\d/.test(clave.value) },
]);
const claveValida = computed(() => reglas.value.every((r) => r.ok));

async function crear() {
  error.value = '';
  if (!claveValida.value) {
    error.value = 'La contraseña no cumple los requisitos.';
    return;
  }
  if (clave.value !== clave2.value) {
    error.value = 'Las contraseñas no coinciden.';
    return;
  }
  guardando.value = true;
  try {
    await api.post('/setup/primer-admin', {
      nombre: nombre.value.trim(),
      email: email.value.trim(),
      password: clave.value,
    });
    creado.value = true;
  } catch (e) {
    error.value = mensajeError(e, 'No se pudo crear el administrador.');
  } finally {
    guardando.value = false;
  }
}
</script>

<template>
  <div class="setup">
    <div class="tarjeta caja">
      <div class="tarjeta-cuerpo pila">
        <div class="icono"><AppIcon name="shield" :size="26" /></div>
        <div>
          <h2>Crear el primer administrador</h2>
          <p class="texto-suave">
            Entraste con el super-usuario de instalación. Creá la cuenta del administrador: con ella se gestionan
            usuarios, roles y sucursales. Al terminar, el super-usuario deja de funcionar.
          </p>
        </div>

        <template v-if="!creado">
          <div v-if="error" class="aviso-linea error" role="alert"><AppIcon name="alert" :size="18" /> <span>{{ error }}</span></div>
          <form class="pila" @submit.prevent="crear">
            <Campo label="Nombre" requerido v-slot="{ id }">
              <input :id="id" v-model="nombre" required maxlength="100" autocomplete="name" />
            </Campo>
            <Campo label="Correo electrónico" requerido v-slot="{ id }">
              <input :id="id" v-model="email" type="email" required maxlength="150" autocomplete="email" />
            </Campo>
            <Campo label="Contraseña" requerido v-slot="{ id }">
              <div class="entrada-icono">
                <input :id="id" v-model="clave" :type="verClave ? 'text' : 'password'" required autocomplete="new-password" style="padding-right: 44px" />
                <button type="button" class="btn btn-fantasma btn-icono btn-sm accion-der" :aria-label="verClave ? 'Ocultar' : 'Mostrar'" @click="verClave = !verClave">
                  <AppIcon :name="verClave ? 'eyeOff' : 'eye'" :size="18" />
                </button>
              </div>
            </Campo>
            <ul class="reglas" aria-label="Requisitos de la contraseña">
              <li v-for="r in reglas" :key="r.texto" :class="{ ok: r.ok }">
                <AppIcon :name="r.ok ? 'checkCircle' : 'clock'" :size="15" /> {{ r.texto }}
              </li>
            </ul>
            <Campo label="Repetir contraseña" requerido v-slot="{ id }">
              <input :id="id" v-model="clave2" :type="verClave ? 'text' : 'password'" required autocomplete="new-password" />
            </Campo>
            <div class="fila">
              <button class="btn btn-primario" :disabled="guardando">
                {{ guardando ? 'Creando...' : 'Crear administrador' }}
              </button>
              <button type="button" class="btn btn-secundario" @click="store.cerrarSesion()">Salir</button>
            </div>
          </form>
        </template>

        <template v-else>
          <div class="aviso-linea ok"><AppIcon name="checkCircle" :size="18" /> <span>Administrador creado. Ya podés iniciar sesión con esa cuenta.</span></div>
          <button class="btn btn-primario" @click="store.cerrarSesion()">Ir al inicio de sesión</button>
        </template>
      </div>
    </div>
  </div>
</template>

<style scoped>
.setup { min-height: 100vh; display: grid; place-items: center; padding: 24px; }
.caja { width: 100%; max-width: 480px; }
.icono { width: 52px; height: 52px; border-radius: 14px; display: grid; place-items: center; background: var(--marca-suave); color: var(--marca); }
.reglas { list-style: none; margin: -6px 0 0; padding: 0; display: grid; grid-template-columns: 1fr 1fr; gap: 4px 12px; font-size: 12px; color: var(--texto-3); }
.reglas li { display: flex; align-items: center; gap: 6px; }
.reglas li.ok { color: var(--ok); }
</style>
