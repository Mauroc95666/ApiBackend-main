using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using BackendApi.Models;
using BackendApi.Services;

namespace BackendApi.Controllers;

public class CambioEstadoDto
{
    public string Estado { get; set; } = string.Empty;
}

[ApiController]
[Route("api/[controller]")]
[Authorize(Policy = "Ventas")]
public class PedidosController : ControllerBase
{
    // Orden en que avanza un pedido; CANCELADO se puede aplicar desde cualquier estado abierto.
    private static readonly string[] Flujo = { "PENDIENTE", "EN PREPARACION", "LISTO", "ENTREGADO" };
    private static readonly string[] Modalidades = { "RETIRO", "DELIVERY" };

    private readonly ApplicationDbContext _context;
    private readonly AuditoriaService _auditoria;

    public PedidosController(ApplicationDbContext context, AuditoriaService auditoria)
    {
        _context = context;
        _auditoria = auditoria;
    }

    // Req. 9: el personal de sucursal solo ve los pedidos de las ventas de su sucursal.
    private IQueryable<Pedido> PedidosVisibles()
    {
        var q = _context.Pedidos.AsNoTracking().AsQueryable();
        var restringida = RolHelper.SucursalRestringida(User);
        if (restringida.HasValue) q = q.Where(p => p.Venta.SucursalId == restringida.Value);
        return q;
    }

    [HttpGet]
    public async Task<IActionResult> ObtenerPedidos([FromQuery] string? estado)
    {
        var q = PedidosVisibles();
        if (!string.IsNullOrWhiteSpace(estado))
        {
            var e = estado.Trim().ToUpperInvariant();
            q = q.Where(p => p.Estado == e);
        }
        var pedidos = await q.OrderByDescending(p => p.FechaCreacion).Take(2000).ToListAsync();
        return Ok(pedidos);
    }

    [HttpGet("{id}")]
    public async Task<IActionResult> ObtenerPedidoPorId(int id)
    {
        var pedido = await PedidosVisibles().FirstOrDefaultAsync(p => p.Id == id);

        if (pedido == null)
            return NotFound(new { mensaje = $"Pedido con id {id} no encontrado" });

        return Ok(pedido);
    }

    // Normalmente el pedido lo crea la venta (POST /api/ventas); este alta manual es para el mostrador.
    [HttpPost]
    public async Task<IActionResult> CrearPedido([FromBody] Pedido nuevoPedido)
    {
        if (nuevoPedido == null)
            return BadRequest(new { mensaje = "Los datos del pedido son requeridos" });

        if (nuevoPedido.VentaId <= 0 || !await _context.Ventas.AnyAsync(v => v.Id == nuevoPedido.VentaId))
            return BadRequest(new { mensaje = "El VentaId es obligatorio y debe existir" });

        var modalidad = (nuevoPedido.Modalidad ?? "RETIRO").Trim().ToUpperInvariant();
        if (!Modalidades.Contains(modalidad))
            return BadRequest(new { mensaje = "La modalidad debe ser RETIRO o DELIVERY" });
        if (modalidad == "DELIVERY" && string.IsNullOrWhiteSpace(nuevoPedido.DireccionEntrega))
            return BadRequest(new { mensaje = "Para delivery hace falta la dirección de entrega" });

        // El servidor decide el estado inicial y la hora de ingreso; no se aceptan del cliente.
        nuevoPedido.Venta = null!;
        nuevoPedido.Id = 0;
        nuevoPedido.Modalidad = modalidad;
        nuevoPedido.Estado = "PENDIENTE";
        nuevoPedido.FechaCreacion = DateTime.UtcNow;
        nuevoPedido.FechaPreparacion = nuevoPedido.FechaListo = nuevoPedido.FechaEntregado = null;

        _context.Pedidos.Add(nuevoPedido);
        await _context.SaveChangesAsync();

        return CreatedAtAction(nameof(ObtenerPedidoPorId), new { id = nuevoPedido.Id }, nuevoPedido);
    }

    // Aplica el cambio de estado y guarda la marca de tiempo de la etapa (req. 11).
    private string? AplicarEstado(Pedido pedido, string nuevo)
    {
        nuevo = nuevo.Trim().ToUpperInvariant();
        var actual = pedido.Estado;
        if (nuevo == actual) return null;

        if (actual == "ENTREGADO" || actual == "CANCELADO")
            return $"El pedido ya está {actual.ToLowerInvariant()} y no puede cambiar de estado.";

        if (nuevo != "CANCELADO")
        {
            var i = Array.IndexOf(Flujo, nuevo);
            if (i < 0) return "Estado inválido. Usá: PENDIENTE, EN PREPARACION, LISTO, ENTREGADO o CANCELADO.";
            if (i != Array.IndexOf(Flujo, actual) + 1)
                return $"No se puede pasar de {actual} a {nuevo}; el pedido avanza paso a paso.";
        }

        var ahora = DateTime.UtcNow;
        switch (nuevo)
        {
            case "EN PREPARACION": pedido.FechaPreparacion = ahora; break;
            case "LISTO": pedido.FechaListo = ahora; break;
            case "ENTREGADO":
                pedido.FechaEntregado = ahora;
                pedido.FechaEntrega = ahora;
                break;
        }
        pedido.Estado = nuevo;
        return null;
    }

    [HttpPatch("{id}/estado")]
    public async Task<IActionResult> CambiarEstado(int id, [FromBody] CambioEstadoDto dto)
    {
        var pedido = await _context.Pedidos.Include(p => p.Venta).FirstOrDefaultAsync(p => p.Id == id);
        var restringida = RolHelper.SucursalRestringida(User);
        if (pedido == null || (restringida.HasValue && pedido.Venta.SucursalId != restringida.Value))
            return NotFound(new { mensaje = $"Pedido con id {id} no encontrado" });

        var error = AplicarEstado(pedido, dto?.Estado ?? "");
        if (error != null) return Conflict(new { mensaje = error });

        await _context.SaveChangesAsync();
        return Ok(new { mensaje = $"Pedido {id} → {pedido.Estado}", pedido.Id, pedido.Estado, pedido.TiempoServicioMinutos });
    }

    [HttpPut("{id}")]
    public async Task<IActionResult> ActualizarPedido(int id, [FromBody] Pedido pedidoActualizado)
    {
        var pedido = await _context.Pedidos.Include(p => p.Venta).FirstOrDefaultAsync(p => p.Id == id);
        var restringida = RolHelper.SucursalRestringida(User);
        if (pedido == null || (restringida.HasValue && pedido.Venta.SucursalId != restringida.Value))
            return NotFound(new { mensaje = $"Pedido con id {id} no encontrado" });

        if (!string.IsNullOrWhiteSpace(pedidoActualizado.Estado))
        {
            var error = AplicarEstado(pedido, pedidoActualizado.Estado);
            if (error != null) return Conflict(new { mensaje = error });
        }

        if (!string.IsNullOrWhiteSpace(pedidoActualizado.Modalidad))
        {
            var modalidad = pedidoActualizado.Modalidad.Trim().ToUpperInvariant();
            if (!Modalidades.Contains(modalidad))
                return BadRequest(new { mensaje = "La modalidad debe ser RETIRO o DELIVERY" });
            pedido.Modalidad = modalidad;
        }
        if (pedido.Modalidad == "DELIVERY")
        {
            if (pedidoActualizado.DireccionEntrega != null) pedido.DireccionEntrega = pedidoActualizado.DireccionEntrega.Trim();
            if (string.IsNullOrWhiteSpace(pedido.DireccionEntrega))
                return BadRequest(new { mensaje = "Para delivery hace falta la dirección de entrega" });
        }
        else pedido.DireccionEntrega = null;

        await _context.SaveChangesAsync();

        return Ok(new { mensaje = "Pedido actualizado correctamente", pedido });
    }

    [Authorize(Policy = "Admin")]
    [HttpDelete("{id}")]
    public async Task<IActionResult> EliminarPedido(int id)
    {
        var pedido = await _context.Pedidos.FindAsync(id);

        if (pedido == null)
            return NotFound(new { mensaje = $"Pedido con id {id} no encontrado" });

        _context.Pedidos.Remove(pedido);
        await _context.SaveChangesAsync();
        await _auditoria.RegistrarAsync("ELIMINAR", "Pedido", $"Pedido {id}");

        return Ok(new { mensaje = $"Pedido {id} eliminado correctamente" });
    }
}
