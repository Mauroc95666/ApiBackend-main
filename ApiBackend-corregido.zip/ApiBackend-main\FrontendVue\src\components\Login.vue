<script setup>
import { ref } from 'vue';
import api from '@/api/axios';
import { store } from '@/store';
import { mensajeError } from '@/utils/format';
import AppIcon from '@/ui/AppIcon.vue';
import Campo from '@/ui/Campo.vue';

const correo = ref('');
const clave = ref('');
const verClave = ref(false);
const cargando = ref(false);
const error = ref('');

async function iniciarSesion() {
  error.value = '';
  if (!correo.value.trim() || !clave.value) {
    error.value = 'Completá el correo y la contraseña.';
    return;
  }
  cargando.value = true;
  try {
    const { data } = await api.post('/auth/login', { email: correo.value.trim(), password: clave.value });
    store.iniciarSesion(data);
  } catch (e) {
    error.value = mensajeError(e, 'No se pudo iniciar sesión.');
    clave.value = '';
  } finally {
    cargando.value = false;
  }
}
</script>

<template>
  <div class="login">
    <aside class="marca" aria-hidden="true">
      <div class="marca-contenido">
        <div class="logo"><AppIcon name="loaf" :size="34" /></div>
        <h1>Panadería Kiataque</h1>
        <p class="lema">Pan fresco, cuentas claras.</p>
        <ul class="beneficios">
          <li><AppIcon name="boxes" :size="18" /> Inventario y sucursales en un solo lugar</li>
          <li><AppIcon name="clipboard" :size="18" /> Pedidos con seguimiento de tiempos</li>
          <li><AppIcon name="chart" :size="18" /> Ventas y reportes al instante</li>
        </ul>
      </div>
    </aside>

    <main class="formulario-lado">
      <div class="caja">
        <div class="logo-movil"><AppIcon name="loaf" :size="26" /> <strong>Kiataque</strong></div>
        <h2>Iniciar sesión</h2>
        <p class="texto-suave">Ingresá con tu cuenta del personal.</p>

        <div v-if="error" class="aviso-linea error" role="alert">
          <AppIcon name="alert" :size="18" /> <span>{{ error }}</span>
        </div>

        <form class="pila" novalidate @submit.prevent="iniciarSesion">
          <Campo label="Correo electrónico" v-slot="{ id }">
            <input
              :id="id"
              v-model="correo"
              type="email"
              autocomplete="username"
              placeholder="nombre@kiataque.bo"
              autofocus
              required
            />
          </Campo>

          <Campo label="Contraseña" v-slot="{ id }">
            <div class="entrada-icono">
              <input
                :id="id"
                v-model="clave"
                :type="verClave ? 'text' : 'password'"
                autocomplete="current-password"
                placeholder="Tu contraseña"
                required
                style="padding-right: 44px"
              />
              <button
                type="button"
                class="btn btn-fantasma btn-icono btn-sm accion-der"
                :aria-label="verClave ? 'Ocultar contraseña' : 'Mostrar contraseña'"
                @click="verClave = !verClave"
              >
                <AppIcon :name="verClave ? 'eyeOff' : 'eye'" :size="18" />
              </button>
            </div>
          </Campo>

          <button class="btn btn-primario btn-lg btn-bloque" :disabled="cargando">
            <AppIcon v-if="cargando" name="refresh" :size="18" class="girando" />
            {{ cargando ? 'Ingresando...' : 'Ingresar' }}
          </button>
        </form>

        <hr class="sep" />
        <p class="texto-suave tienda-link">
          ¿Querés hacer un pedido?
          <button type="button" class="enlace" @click="store.entrarComoVisitante()">
            Entrá a la tienda <AppIcon name="arrowRight" :size="15" />
          </button>
        </p>
        <p class="texto-tenue texto-chico ayuda-clave">
          ¿Olvidaste tu contraseña? Pedile al administrador que te asigne una nueva.
        </p>
      </div>
    </main>
  </div>
</template>

<style scoped>
.login { min-height: 100vh; display: grid; grid-template-columns: minmax(320px, 42%) 1fr; }

.marca {
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 48px;
  color: #f6ead9;
  background:
    radial-gradient(circle at 20% 15%, rgba(217, 138, 43, 0.28), transparent 45%),
    radial-gradient(circle at 85% 85%, rgba(217, 138, 43, 0.16), transparent 40%),
    var(--espresso);
}
.marca-contenido { max-width: 380px; }
.logo {
  width: 64px; height: 64px; border-radius: 18px; display: grid; place-items: center;
  background: #d98a2b; color: var(--espresso); margin-bottom: 22px;
}
.marca h1 { color: #fff; font-size: 32px; }
.lema { margin-top: 6px; font-size: 17px; color: #e6d3bb; }
.beneficios { list-style: none; margin: 36px 0 0; padding: 0; display: grid; gap: 14px; font-size: 14px; color: #dcc8ad; }
.beneficios li { display: flex; gap: 10px; align-items: center; }
.beneficios svg { color: #e9a64a; flex: none; }

.formulario-lado { display: flex; align-items: center; justify-content: center; padding: 32px 20px; }
.caja { width: 100%; max-width: 400px; display: grid; gap: 16px; }
.caja h2 { font-size: 26px; }
.logo-movil { display: none; align-items: center; gap: 8px; color: var(--marca); font-size: 18px; }
.tienda-link { text-align: center; font-size: 14px; }
.ayuda-clave { text-align: center; }
.enlace {
  display: inline-flex; align-items: center; gap: 4px; background: none; border: none;
  color: var(--marca); font-weight: 700; cursor: pointer; font-size: 14px; padding: 0;
}
.enlace:hover { text-decoration: underline; }

@media (max-width: 860px) {
  .login { grid-template-columns: 1fr; }
  .marca { display: none; }
  .logo-movil { display: flex; }
}
</style>
