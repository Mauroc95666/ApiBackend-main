<script setup>
// Campo de formulario con etiqueta asociada al control (accesible), ayuda y error.
// Uso:  <Campo label="Nombre" requerido v-slot="{ id }"><input :id="id" v-model="x" /></Campo>
import { useId } from 'vue';

defineProps({
  label: String,
  requerido: Boolean,
  ayuda: String,
  error: String,
});
const id = useId();
</script>

<template>
  <div class="campo">
    <label v-if="label" :for="id">
      {{ label }}<span v-if="requerido" class="requerido" aria-hidden="true">*</span>
    </label>
    <slot :id="id" :invalido="!!error" />
    <span v-if="error" class="error-campo" role="alert">{{ error }}</span>
    <span v-else-if="ayuda" class="ayuda">{{ ayuda }}</span>
  </div>
</template>
