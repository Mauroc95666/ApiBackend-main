using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using BackendApi.Models;
using BackendApi.Services;

namespace BackendApi.Controllers;

// Req. 4: cada usuario del panel ve sus propias notificaciones (stock bajo, avisos del administrador).
[ApiController]
[Route("api/[controller]")]
[Authorize(Policy = "Staff")]
public class NotificacionesController : ControllerBase
{
    private readonly ApplicationDbContext _context;

    public NotificacionesController(ApplicationDbContext context)
    {
        _context = context;
    }

    private bool EsAdmin => RolHelper.EsAdmin(User.FindFirst(System.Security.Claims.ClaimTypes.Role)?.Value);

    [HttpGet]
    public async Task<IActionResult> ObtenerNotificaciones([FromQuery] bool todas = false, [FromQuery] bool soloNoLeidas = false)
    {
        var yo = RolHelper.UsuarioId(User);
        var q = _context.Notificaciones.AsNoTracking().AsQueryable();
        if (!(todas && EsAdmin)) q = q.Where(n => n.UsuarioId == yo);
        if (soloNoLeidas) q = q.Where(n => n.Leido != true);
        return Ok(await q.OrderByDescending(n => n.Fecha).Take(200).ToListAsync());
    }

    [HttpGet("no-leidas")]
    public async Task<IActionResult> CantidadNoLeidas()
    {
        var yo = RolHelper.UsuarioId(User);
        var cantidad = await _context.Notificaciones.CountAsync(n => n.UsuarioId == yo && n.Leido != true);
        return Ok(new { cantidad });
    }

    [HttpGet("{id}")]
    public async Task<IActionResult> ObtenerNotificacionPorId(int id)
    {
        var yo = RolHelper.UsuarioId(User);
        var notificacion = await _context.Notificaciones.AsNoTracking()
            .FirstOrDefaultAsync(n => n.Id == id && (n.UsuarioId == yo || EsAdmin));

        if (notificacion == null)
            return NotFound(new { mensaje = $"Notificación con id {id} no encontrada" });

        return Ok(notificacion);
    }

    [Authorize(Policy = "Admin")]
    [HttpPost]
    public async Task<IActionResult> CrearNotificacion([FromBody] Notificacion nuevaNotificacion)
    {
        if (nuevaNotificacion == null || string.IsNullOrWhiteSpace(nuevaNotificacion.Mensaje))
            return BadRequest(new { mensaje = "El mensaje de la notificación es requerido" });
        if (!await _context.Usuarios.AnyAsync(u => u.Id == nuevaNotificacion.UsuarioId))
            return BadRequest(new { mensaje = $"No existe el usuario {nuevaNotificacion.UsuarioId}" });

        nuevaNotificacion.Id = 0;
        nuevaNotificacion.Usuario = null!;
        nuevaNotificacion.Leido = false;
        nuevaNotificacion.Fecha = DateTime.UtcNow;
        _context.Notificaciones.Add(nuevaNotificacion);
        await _context.SaveChangesAsync();

        return CreatedAtAction(nameof(ObtenerNotificacionPorId), new { id = nuevaNotificacion.Id }, nuevaNotificacion);
    }

    // Marca como leída una notificación propia.
    [HttpPost("{id}/leer")]
    public async Task<IActionResult> MarcarLeida(int id)
    {
        var yo = RolHelper.UsuarioId(User);
        var n = await _context.Notificaciones.FirstOrDefaultAsync(x => x.Id == id && x.UsuarioId == yo);
        if (n == null) return NotFound(new { mensaje = $"Notificación con id {id} no encontrada" });
        n.Leido = true;
        await _context.SaveChangesAsync();
        return Ok(new { mensaje = "Notificación leída" });
    }

    [HttpPost("leer-todas")]
    public async Task<IActionResult> MarcarTodasLeidas()
    {
        var yo = RolHelper.UsuarioId(User);
        var filas = await _context.Notificaciones.Where(n => n.UsuarioId == yo && n.Leido != true)
            .ExecuteUpdateAsync(s => s.SetProperty(n => n.Leido, true));
        return Ok(new { mensaje = $"{filas} notificaciones marcadas como leídas" });
    }

    [Authorize(Policy = "Admin")]
    [HttpPut("{id}")]
    public async Task<IActionResult> ActualizarNotificacion(int id, [FromBody] Notificacion notificacionActualizada)
    {
        var notificacion = await _context.Notificaciones.FindAsync(id);

        if (notificacion == null)
            return NotFound(new { mensaje = $"Notificación con id {id} no encontrada" });

        notificacion.Mensaje = notificacionActualizada.Mensaje;
        notificacion.Leido = notificacionActualizada.Leido;

        await _context.SaveChangesAsync();

        return Ok(new { mensaje = "Notificación actualizada correctamente", notificacion });
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> EliminarNotificacion(int id)
    {
        var yo = RolHelper.UsuarioId(User);
        var notificacion = await _context.Notificaciones.FirstOrDefaultAsync(n => n.Id == id && (n.UsuarioId == yo || EsAdmin));

        if (notificacion == null)
            return NotFound(new { mensaje = $"Notificación con id {id} no encontrada" });

        _context.Notificaciones.Remove(notificacion);
        await _context.SaveChangesAsync();

        return Ok(new { mensaje = $"Notificación {id} eliminada correctamente" });
    }
}
