using System.Security.Claims;

namespace BackendApi.Services;

public static class RolHelper
{
    public const string RolSetup = "SetupRoot";
    public const string ClaimSucursal = "sucursalId";

    // Mismo criterio que usa el frontend (store.js): se deduce por el nombre del rol.
    public static bool EsAdmin(string? nombreRol)
    {
        if (string.IsNullOrWhiteSpace(nombreRol)) return false;
        var n = nombreRol.ToLowerInvariant();
        return n.Contains("admin") || n.Contains("super") || n.Contains("gerente");
    }

    static bool Contiene(string? rol, params string[] claves) =>
        !string.IsNullOrWhiteSpace(rol) && claves.Any(c => rol.Contains(c, StringComparison.OrdinalIgnoreCase));

    // "Inventario" contiene "venta" (in-venta-rio): por eso se descarta primero el rol de inventario.
    public static bool EsCajeroOVendedor(string? rol) => !EsInventario(rol) && Contiene(rol, "cajero", "caja", "vendedor", "ventas");
    public static bool EsInventario(string? rol) => Contiene(rol, "inventario", "almac", "bodega", "stock");

    // Quién puede registrar ventas y atender pedidos.
    public static bool PuedeVentas(string? rol) => EsAdmin(rol) || EsCajeroOVendedor(rol);
    // Quién puede mover stock y editar productos.
    public static bool PuedeInventario(string? rol) => EsAdmin(rol) || EsInventario(rol);
    // Personal interno (cualquier rol de panel). El rol "Cliente" y el super-usuario oculto quedan fuera.
    public static bool EsStaff(string? rol) => PuedeVentas(rol) || PuedeInventario(rol);

    // Req. 9: el personal que no es administrador solo ve los datos de su sucursal.
    // Devuelve null cuando el usuario puede ver todas las sucursales.
    public static int? SucursalRestringida(ClaimsPrincipal user)
    {
        if (EsAdmin(user.FindFirstValue(ClaimTypes.Role))) return null;
        return int.TryParse(user.FindFirstValue(ClaimSucursal), out var id) ? id : null;
    }

    public static int? UsuarioId(ClaimsPrincipal user) =>
        int.TryParse(user.FindFirstValue(ClaimTypes.NameIdentifier), out var id) ? id : null;
}
