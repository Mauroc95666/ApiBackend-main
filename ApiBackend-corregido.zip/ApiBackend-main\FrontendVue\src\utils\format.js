// Utilidades de formato compartidas por todas las pantallas.

// Dinero en bolivianos: "Bs 1.234,50".
export function bs(valor) {
  const n = Number(valor);
  return (
    'Bs ' +
    (isNaN(n) ? 0 : n).toLocaleString('es-BO', { minimumFractionDigits: 2, maximumFractionDigits: 2 })
  );
}

export function entero(valor) {
  const n = Number(valor);
  return (isNaN(n) ? 0 : n).toLocaleString('es-BO');
}

// El servidor guarda las fechas en UTC y las devuelve sin zona ("2026-10-21T12:00:00").
// Sin la "Z" el navegador las leería como hora local y quedarían corridas.
export function aFecha(valor) {
  if (!valor) return null;
  if (valor instanceof Date) return valor;
  const s = String(valor);
  return new Date(/[zZ]$|[+-]\d\d:\d\d$/.test(s) ? s : s + 'Z');
}

export function fechaCorta(valor) {
  const d = aFecha(valor);
  return d && !isNaN(d) ? d.toLocaleDateString('es-BO', { day: '2-digit', month: 'short', year: 'numeric' }) : '—';
}

export function fechaHora(valor) {
  const d = aFecha(valor);
  return d && !isNaN(d)
    ? d.toLocaleString('es-BO', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' })
    : '—';
}

// "hace 5 min", "hace 2 h", "hace 3 días".
export function haceCuanto(valor) {
  const d = aFecha(valor);
  if (!d || isNaN(d)) return '';
  const min = Math.max(0, Math.round((Date.now() - d.getTime()) / 60000));
  if (min < 1) return 'ahora';
  if (min < 60) return `hace ${min} min`;
  const h = Math.floor(min / 60);
  if (h < 24) return `hace ${h} h`;
  const dias = Math.floor(h / 24);
  return `hace ${dias} ${dias === 1 ? 'día' : 'días'}`;
}

export function duracion(minutos) {
  if (minutos == null || isNaN(minutos)) return '—';
  const m = Math.round(minutos);
  return m >= 60 ? `${Math.floor(m / 60)} h ${m % 60} min` : `${m} min`;
}

// Clave de día en hora local: "2026-10-21".
export function claveDia(valor) {
  const d = aFecha(valor);
  if (!d || isNaN(d)) return '';
  const p = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
}

export function hoyLocal() {
  return claveDia(new Date());
}

// Mensaje legible a partir de un error de axios.
export function mensajeError(e, porDefecto = 'Ocurrió un error. Intentá de nuevo.') {
  if (e?.response?.data?.mensaje) return e.response.data.mensaje;
  if (e?.response?.status === 403) return 'No tenés permiso para hacer esto.';
  if (e?.response?.status === 429) return 'Demasiados intentos seguidos. Esperá un minuto y probá de nuevo.';
  if (!e?.response) return 'No se pudo conectar con el servidor. Revisá que el backend esté encendido.';
  return porDefecto;
}

export function iniciales(nombre) {
  const partes = String(nombre || '?').trim().split(/\s+/).slice(0, 2);
  return partes.map((p) => p.charAt(0).toUpperCase()).join('') || '?';
}

// Descarga una tabla como CSV (con BOM para que Excel respete los acentos).
export function descargarCsv(nombre, filas) {
  const celda = (v) => {
    const s = v == null ? '' : String(v);
    return /[",\n;]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
  };
  const texto = filas.map((f) => f.map(celda).join(';')).join('\r\n');
  const blob = new Blob(['\ufeff' + texto], { type: 'text/csv;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = nombre;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}
