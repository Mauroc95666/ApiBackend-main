<script setup>
// tono: ok | aviso | peligro | info | marca | '' (neutro)
defineProps({ tono: { type: String, default: '' }, sinPunto: Boolean });
</script>

<template>
  <span class="insignia" :class="[tono ? 'insignia-' + tono : '', { 'sin-punto': sinPunto }]"><slot /></span>
</template>
