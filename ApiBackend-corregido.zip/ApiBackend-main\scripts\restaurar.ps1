﻿<#
.SYNOPSIS
  Restaura la base de datos de la Panadería Kiataque desde un respaldo (requisito 10).

.DESCRIPTION
  OPERACIÓN DESTRUCTIVA: reemplaza todos los datos actuales de la base por los del respaldo.
  Por eso exige -Confirmar. Antes de reemplazar verifica el archivo y cierra las conexiones abiertas.
  Detené el backend antes de restaurar y volvé a iniciarlo después.

.EXAMPLE
  .\scripts\restaurar.ps1 -Archivo "C:\Respaldos\DB_Panaderia2_20261021_060000.bak" -Confirmar
  # Para ensayar sin tocar los datos reales, restaurá en otra base:
  .\scripts\restaurar.ps1 -Archivo ... -Base DB_Panaderia2_ensayo -Confirmar
#>
param(
    [Parameter(Mandatory = $true)][string]$Archivo,
    [string]$Servidor = ".\SQLEXPRESS",
    [string]$Base = "DB_Panaderia2",
    [string]$Usuario = "",
    [string]$Clave = "",
    [switch]$Confirmar
)
$ErrorActionPreference = 'Stop'

function Invocar-Sql([string]$consulta) {
    $args = @("-S", $Servidor, "-C", "-b", "-h", "-1", "-W", "-Q", $consulta)
    if ($Usuario) { $args += @("-U", $Usuario, "-P", $Clave) } else { $args += "-E" }
    $salida = & sqlcmd @args
    if ($LASTEXITCODE -ne 0) { throw "sqlcmd falló: $salida" }
    return $salida
}

if (-not $Confirmar) {
    Write-Host "Esto REEMPLAZARÁ los datos de '$Base' por los de '$Archivo'." -ForegroundColor Yellow
    Write-Host "Si estás seguro, volvé a ejecutar el comando agregando -Confirmar." -ForegroundColor Yellow
    exit 1
}

Write-Host "Verificando el respaldo ..."
Invocar-Sql "RESTORE VERIFYONLY FROM DISK = N'$Archivo' WITH CHECKSUM" | Out-Null

# Nombres lógicos y carpeta de datos, para restaurar también en una base con otro nombre.
$lista = Invocar-Sql "RESTORE FILELISTONLY FROM DISK = N'$Archivo'"
$logicos = $lista | Where-Object { $_ -match '\S' } | ForEach-Object { ($_ -split '\s+')[0] }
$dir = (Invocar-Sql "SET NOCOUNT ON; SELECT CAST(SERVERPROPERTY('InstanceDefaultDataPath') AS nvarchar(512))" | Select-Object -First 1).Trim()
$datos = $logicos[0]; $log = $logicos[1]

Write-Host "Restaurando '$Base' ..."
$existe = (Invocar-Sql "SET NOCOUNT ON; SELECT COUNT(*) FROM sys.databases WHERE name = N'$Base'" | Select-Object -First 1).Trim() -eq '1'
if ($existe) { Invocar-Sql "ALTER DATABASE [$Base] SET SINGLE_USER WITH ROLLBACK IMMEDIATE" | Out-Null }
try {
    Invocar-Sql ("RESTORE DATABASE [$Base] FROM DISK = N'$Archivo' WITH REPLACE, CHECKSUM, " +
        "MOVE N'$datos' TO N'${dir}${Base}.mdf', MOVE N'$log' TO N'${dir}${Base}_log.ldf', STATS = 25") | Out-Null
}
finally {
    Invocar-Sql "ALTER DATABASE [$Base] SET MULTI_USER" | Out-Null
}
Write-Host "Base '$Base' restaurada desde $Archivo" -ForegroundColor Green

