<script setup>
import AppIcon from './AppIcon.vue';
defineProps({
  titulo: String,
  valor: [String, Number],
  detalle: String,
  icono: { type: String, default: 'chart' },
  tono: { type: String, default: '' }, // '' | ok | aviso | peligro | info
  cargando: Boolean,
});
</script>

<template>
  <div class="tarjeta kpi">
    <div class="kpi-icono" :class="tono"><AppIcon :name="icono" :size="22" /></div>
    <div class="crece">
      <div class="kpi-titulo">{{ titulo }}</div>
      <span v-if="cargando" class="esqueleto" style="width: 90px; height: 26px; margin-top: 6px"></span>
      <div v-else class="kpi-valor">{{ valor }}</div>
      <div v-if="detalle" class="kpi-detalle">{{ detalle }}</div>
    </div>
  </div>
</template>
