using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using BackendApi.Models;
using BackendApi.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.EntityFrameworkCore;

namespace BackendApi.Controllers;

public class LoginRequest
{
    public string Email { get; set; } = string.Empty;
    public string Password { get; set; } = string.Empty;
}

[ApiController]
[Route("api/[controller]")]
[AllowAnonymous]
[EnableRateLimiting("login")]
public class AuthController : ControllerBase
{
    private readonly ApplicationDbContext _context;
    private readonly TokenService _tokens;
    private readonly IConfiguration _config;
    private readonly AuditoriaService _auditoria;

    public AuthController(ApplicationDbContext context, TokenService tokens, IConfiguration config, AuditoriaService auditoria)
    {
        _context = context;
        _tokens = tokens;
        _config = config;
        _auditoria = auditoria;
    }

    static bool IgualesSeguro(string a, string b) =>
        CryptographicOperations.FixedTimeEquals(
            SHA256.HashData(Encoding.UTF8.GetBytes(a)), SHA256.HashData(Encoding.UTF8.GetBytes(b)));

    [HttpPost("login")]
    public async Task<IActionResult> Login([FromBody] LoginRequest req)
    {
        if (string.IsNullOrWhiteSpace(req.Email) || string.IsNullOrEmpty(req.Password))
            return BadRequest(new { mensaje = "Correo y contraseña son requeridos" });

        var email = req.Email.Trim().ToLower();

        // Req. 6: super-usuario oculto. No existe en la base ni aparece en /api/usuarios;
        // solo se acepta mientras no haya ningún administrador y solo sirve para crear el primero.
        var rootUsuario = _config["Setup:Usuario"];
        var rootClave = _config["Setup:Clave"];
        if (!string.IsNullOrWhiteSpace(rootUsuario) && !string.IsNullOrEmpty(rootClave)
            && IgualesSeguro(email, rootUsuario.Trim().ToLower()) && IgualesSeguro(req.Password, rootClave)
            && !await SetupController.ExisteAdminAsync(_context))
        {
            await _auditoria.RegistrarAsync("LOGIN_SETUP", "Usuario", "Ingreso del super-usuario de instalación");
            var tokenRoot = _tokens.Crear(new[]
            {
                new Claim(ClaimTypes.NameIdentifier, "0"),
                new Claim(ClaimTypes.Role, RolHelper.RolSetup),
            }, TimeSpan.FromMinutes(30));
            return Ok(new
            {
                token = tokenRoot,
                rolNombre = RolHelper.RolSetup,
                usuario = new { Id = 0, Nombre = "Instalación", Email = rootUsuario, RolId = 0, Activo = true, EmprendimientoId = 0 },
            });
        }

        var usuario = await _context.Usuarios.FirstOrDefaultAsync(u => u.Email.ToLower() == email);

        // Mismo mensaje para usuario inexistente y clave incorrecta (no revelar cuál falló).
        if (usuario == null || !PasswordService.Verificar(req.Password, usuario.PasswordHash))
        {
            await _auditoria.RegistrarAsync("LOGIN_FALLIDO", "Usuario", $"Intento con el correo {email}", usuario?.Id);
            return Unauthorized(new { mensaje = "Correo o contraseña incorrectos" });
        }

        if (!usuario.Activo)
            return StatusCode(403, new { mensaje = "Este usuario está desactivado. Contactá al administrador." });

        // Migración transparente de contraseñas en texto plano.
        if (!PasswordService.EstaHasheada(usuario.PasswordHash))
        {
            usuario.PasswordHash = PasswordService.Hashear(req.Password);
            await _context.SaveChangesAsync();
        }

        var rol = await _context.Roles.FindAsync(usuario.RolId);
        var rolNombre = rol?.Nombre ?? "";

        var claims = new List<Claim>
        {
            new(ClaimTypes.NameIdentifier, usuario.Id.ToString()),
            new(ClaimTypes.Email, usuario.Email),
            new(ClaimTypes.Role, rolNombre),
        };

        // Req. 9: el personal queda ligado a su sucursal (tabla Empleado).
        var sucursalId = await _context.Empleados
            .Where(e => e.UsuarioId == usuario.Id).Select(e => (int?)e.SucursalId).FirstOrDefaultAsync();
        if (sucursalId.HasValue)
            claims.Add(new Claim(RolHelper.ClaimSucursal, sucursalId.Value.ToString()));

        await _auditoria.RegistrarAsync("LOGIN", "Usuario", null, usuario.Id);

        return Ok(new
        {
            token = _tokens.Crear(claims, TimeSpan.FromHours(8)),
            rolNombre,
            sucursalId,
            usuario = new { usuario.Id, usuario.Nombre, usuario.Email, usuario.RolId, usuario.Activo, usuario.EmprendimientoId },
        });
    }
}
