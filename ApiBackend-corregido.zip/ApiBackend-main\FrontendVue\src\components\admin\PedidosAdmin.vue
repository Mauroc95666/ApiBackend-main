<script setup>
import { ref, computed, onMounted, onBeforeUnmount } from 'vue';
import api from '@/api/axios';
import { store } from '@/store';
import { toast, confirmar } from '@/ui/feedback';
import { bs, aFecha, fechaHora, duracion, mensajeError, haceCuanto } from '@/utils/format';
import AppIcon from '@/ui/AppIcon.vue';
import AppModal from '@/ui/AppModal.vue';
import EncabezadoPagina from '@/ui/EncabezadoPagina.vue';
import EstadoVacio from '@/ui/EstadoVacio.vue';
import Insignia from '@/ui/Insignia.vue';

const META_MIN = 30; // meta de tiempo de servicio

const pedidos = ref([]);
const ventas = ref([]);
const clientes = ref([]);
const sucursales = ref([]);
const cargando = ref(true);
const errorCarga = ref('');
const ahora = ref(Date.now());
const tab = ref('tablero');
const filtroModalidad = ref('TODAS');
const filtroSucursal = ref(0);
const busqueda = ref('');
const moviendo = ref(null); // id del pedido que se está actualizando

const COLUMNAS = [
  { clave: 'PENDIENTE', titulo: 'Pendientes', siguiente: 'EN PREPARACION', accion: 'Empezar a preparar', tono: 'aviso' },
  { clave: 'EN PREPARACION', titulo: 'En preparación', siguiente: 'LISTO', accion: 'Marcar como listo', tono: 'info' },
  { clave: 'LISTO', titulo: 'Listos', siguiente: 'ENTREGADO', accion: 'Marcar entregado', tono: 'ok' },
];

async function cargar(silencioso = false) {
  if (!silencioso) cargando.value = true;
  errorCarga.value = '';
  try {
    const pedir = (url) => api.get(url).then((r) => r.data || []);
    const [pe, v, c, s] = await Promise.all([pedir('/pedidos'), pedir('/ventas'), pedir('/clientes').catch(() => []), pedir('/sucursales').catch(() => [])]);
    pedidos.value = pe;
    ventas.value = v;
    clientes.value = c;
    sucursales.value = s;
  } catch (e) {
    if (!silencioso) errorCarga.value = mensajeError(e, 'No se pudieron cargar los pedidos.');
  } finally {
    cargando.value = false;
  }
}

// Se refresca solo cada 30 s para que la cola de cocina esté al día y los relojes avancen.
let t1, t2;
onMounted(() => {
  cargar();
  t1 = setInterval(() => !document.hidden && cargar(true), 30000);
  t2 = setInterval(() => (ahora.value = Date.now()), 20000);
});
onBeforeUnmount(() => { clearInterval(t1); clearInterval(t2); });

const ventaDe = (p) => ventas.value.find((v) => v.id === p.ventaId);
const clienteDe = (p) => {
  const v = ventaDe(p);
  return v ? clientes.value.find((c) => c.id === v.clienteId)?.nombre || `Cliente #${v.clienteId}` : '—';
};
const totalDe = (p) => Number(ventaDe(p)?.total || 0);
const sucursalDe = (p) => sucursales.value.find((s) => s.id === ventaDe(p)?.sucursalId)?.nombre || '';

function minutosEnCurso(p) {
  const ini = aFecha(p.fechaCreacion);
  return ini ? Math.max(0, Math.round((ahora.value - ini.getTime()) / 60000)) : 0;
}
const minutosDe = (p) => (p.tiempoServicioMinutos != null ? p.tiempoServicioMinutos : minutosEnCurso(p));
const tarde = (p) => !['ENTREGADO', 'CANCELADO'].includes(p.estado) && minutosEnCurso(p) > META_MIN;

const visibles = computed(() => {
  const t = busqueda.value.trim().toLowerCase();
  return pedidos.value.filter((p) => {
    if (filtroModalidad.value !== 'TODAS' && p.modalidad !== filtroModalidad.value) return false;
    if (filtroSucursal.value && ventaDe(p)?.sucursalId !== filtroSucursal.value) return false;
    if (t && !(`#${p.id}`.includes(t) || String(p.id) === t || clienteDe(p).toLowerCase().includes(t))) return false;
    return true;
  });
});
const enColumna = (clave) => visibles.value.filter((p) => p.estado === clave).sort((a, b) => aFecha(a.fechaCreacion) - aFecha(b.fechaCreacion));
const historial = computed(() => visibles.value.filter((p) => ['ENTREGADO', 'CANCELADO'].includes(p.estado)));
const activos = computed(() => visibles.value.filter((p) => COLUMNAS.some((c) => c.clave === p.estado)).length);

const promedioEntregados = computed(() => {
  const t = historial.value.map((p) => p.tiempoServicioMinutos).filter((x) => x != null);
  return t.length ? t.reduce((a, b) => a + b, 0) / t.length : null;
});

async function cambiarEstado(p, estado) {
  moviendo.value = p.id;
  try {
    await api.patch(`/pedidos/${p.id}/estado`, { estado });
    toast.ok(estado === 'CANCELADO' ? `Pedido #${p.id} cancelado.` : `Pedido #${p.id} → ${estado.toLowerCase()}.`);
    detalle.value = null;
    await cargar(true);
  } catch (e) {
    toast.error(mensajeError(e, 'No se pudo cambiar el estado.'));
  } finally {
    moviendo.value = null;
  }
}

async function cancelar(p) {
  const si = await confirmar({ titulo: `Cancelar pedido #${p.id}`, mensaje: 'El pedido pasa a “cancelado” y ya no se puede reabrir. El stock no se devuelve automáticamente.', textoOk: 'Cancelar pedido', textoCancelar: 'Volver', peligro: true });
  if (si) cambiarEstado(p, 'CANCELADO');
}

async function eliminar(p) {
  const si = await confirmar({ titulo: `Eliminar pedido #${p.id}`, mensaje: 'Se borra el pedido del sistema. La venta asociada se conserva.', textoOk: 'Eliminar', peligro: true });
  if (!si) return;
  try {
    await api.delete(`/pedidos/${p.id}`);
    toast.ok('Pedido eliminado.');
    detalle.value = null;
    await cargar(true);
  } catch (e) {
    toast.error(mensajeError(e, 'No se pudo eliminar.'));
  }
}

// ----- Detalle con línea de tiempo -----
const detalle = ref(null);
const modalDetalle = computed({ get: () => !!detalle.value, set: (v) => { if (!v) detalle.value = null; } });
const etapas = computed(() => {
  const p = detalle.value;
  if (!p) return [];
  const marcas = [
    { texto: 'Pedido recibido', fecha: p.fechaCreacion },
    { texto: 'En preparación', fecha: p.fechaPreparacion },
    { texto: 'Listo', fecha: p.fechaListo },
    { texto: 'Entregado', fecha: p.fechaEntregado },
  ];
  return marcas.map((m, i) => ({
    ...m,
    hecho: !!m.fecha,
    desde: i > 0 && m.fecha && marcas[i - 1].fecha ? duracion((aFecha(m.fecha) - aFecha(marcas[i - 1].fecha)) / 60000) : null,
  }));
});

const tonoEstado = (e) => ({ PENDIENTE: 'aviso', 'EN PREPARACION': 'info', LISTO: 'ok', ENTREGADO: 'ok', CANCELADO: 'peligro' }[e] ?? '');
const puedeEliminar = store.esAdmin;
</script>

<template>
  <div>
    <EncabezadoPagina titulo="Pedidos" :subtitulo="`${activos} en curso${promedioEntregados != null ? ' · tiempo de servicio promedio ' + duracion(promedioEntregados) + ' (meta ' + META_MIN + ' min)' : ''}`">
      <button type="button" class="btn btn-secundario" :disabled="cargando" @click="cargar()"><AppIcon name="refresh" :size="16" :class="{ girando: cargando }" /> Actualizar</button>
    </EncabezadoPagina>

    <div v-if="errorCarga" class="aviso-linea error" role="alert" style="margin-bottom: 16px">
      <AppIcon name="alert" :size="18" /> <span class="crece">{{ errorCarga }}</span>
      <button type="button" class="btn btn-secundario btn-sm" @click="cargar()">Reintentar</button>
    </div>

    <div class="filtros">
      <div class="entrada-icono buscador">
        <AppIcon name="search" :size="17" class="icono-izq" />
        <input v-model="busqueda" type="search" placeholder="Buscar por N.º o cliente..." aria-label="Buscar pedido" />
      </div>
      <div class="segmentos" role="group" aria-label="Filtrar por modalidad">
        <button type="button" class="segmento" :class="{ activo: filtroModalidad === 'TODAS' }" @click="filtroModalidad = 'TODAS'">Todos</button>
        <button type="button" class="segmento" :class="{ activo: filtroModalidad === 'RETIRO' }" @click="filtroModalidad = 'RETIRO'">Retiro</button>
        <button type="button" class="segmento" :class="{ activo: filtroModalidad === 'DELIVERY' }" @click="filtroModalidad = 'DELIVERY'">Delivery</button>
      </div>
      <select v-if="sucursales.length > 1 && store.sucursalId == null" v-model.number="filtroSucursal" aria-label="Filtrar por sucursal" style="width: auto">
        <option :value="0">Todas las sucursales</option>
        <option v-for="s in sucursales" :key="s.id" :value="s.id">{{ s.nombre }}</option>
      </select>
    </div>

    <div class="pestanas" role="tablist" style="margin: 16px 0 20px">
      <button type="button" role="tab" class="pestana" :class="{ activa: tab === 'tablero' }" @click="tab = 'tablero'">Tablero <span class="contador">{{ activos }}</span></button>
      <button type="button" role="tab" class="pestana" :class="{ activa: tab === 'historial' }" @click="tab = 'historial'">Entregados y cancelados <span class="contador">{{ historial.length }}</span></button>
    </div>

    <!-- ===== Tablero ===== -->
    <div v-if="tab === 'tablero'" class="tablero">
      <section v-for="col in COLUMNAS" :key="col.clave" class="columna">
        <header class="col-cab">
          <Insignia :tono="col.tono">{{ col.titulo }}</Insignia>
          <span class="texto-suave numeros">{{ enColumna(col.clave).length }}</span>
        </header>

        <template v-if="cargando"><div v-for="n in 2" :key="n" class="tarjeta"><div class="tarjeta-cuerpo pila-sm"><span class="esqueleto"></span><span class="esqueleto" style="width: 60%"></span></div></div></template>
        <p v-else-if="!enColumna(col.clave).length" class="col-vacia texto-tenue">Sin pedidos</p>

        <article v-for="p in enColumna(col.clave)" :key="p.id" class="tarjeta pedido" :class="{ tarde: tarde(p) }">
          <button type="button" class="pedido-cuerpo" @click="detalle = p">
            <div class="fila entre">
              <strong>#{{ p.id }}</strong>
              <span class="reloj numeros" :class="{ rojo: tarde(p) }"><AppIcon name="clock" :size="14" /> {{ duracion(minutosEnCurso(p)) }}</span>
            </div>
            <div class="negrita truncar">{{ clienteDe(p) }}</div>
            <div class="fila texto-chico texto-suave" style="gap: 6px">
              <AppIcon :name="p.modalidad === 'DELIVERY' ? 'truck' : 'store'" :size="14" />
              {{ p.modalidad === 'DELIVERY' ? 'Delivery' : 'Retiro en local' }}
              <span v-if="sucursales.length > 1" class="texto-tenue">· {{ sucursalDe(p) }}</span>
            </div>
            <div v-if="p.modalidad === 'DELIVERY' && p.direccionEntrega" class="texto-chico texto-suave direccion"><AppIcon name="pin" :size="14" /> {{ p.direccionEntrega }}</div>
            <div class="numeros negrita">{{ bs(totalDe(p)) }}</div>
          </button>
          <div class="pedido-acciones">
            <button type="button" class="btn btn-primario btn-sm crece" :disabled="moviendo === p.id" @click="cambiarEstado(p, col.siguiente)">
              {{ col.accion }} <AppIcon name="arrowRight" :size="14" />
            </button>
            <button type="button" class="btn btn-fantasma btn-sm btn-icono" :aria-label="`Cancelar pedido ${p.id}`" title="Cancelar pedido" @click="cancelar(p)"><AppIcon name="x" :size="16" /></button>
          </div>
        </article>
      </section>
    </div>

    <!-- ===== Historial ===== -->
    <div v-else class="tarjeta">
      <EstadoVacio v-if="!historial.length && !cargando" icono="clipboard" titulo="Sin pedidos cerrados" texto="Los pedidos entregados o cancelados aparecen acá." />
      <div v-else class="tabla-contenedor">
        <table class="tabla">
          <thead><tr><th>N.º</th><th>Cliente</th><th>Modalidad</th><th>Ingreso</th><th class="num">Tiempo</th><th>Estado</th><th class="num">Total</th></tr></thead>
          <tbody>
            <tr v-for="p in historial" :key="p.id" class="clic" @click="detalle = p">
              <td><strong>#{{ p.id }}</strong></td>
              <td>{{ clienteDe(p) }}</td>
              <td>{{ p.modalidad === 'DELIVERY' ? 'Delivery' : 'Retiro' }}</td>
              <td class="texto-suave">{{ fechaHora(p.fechaCreacion) }}</td>
              <td class="num" :class="{ rojo: p.tiempoServicioMinutos > META_MIN }">{{ p.estado === 'ENTREGADO' ? duracion(p.tiempoServicioMinutos) : '—' }}</td>
              <td><Insignia :tono="tonoEstado(p.estado)">{{ p.estado }}</Insignia></td>
              <td class="num">{{ bs(totalDe(p)) }}</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>

    <!-- ===== Detalle ===== -->
    <AppModal v-model="modalDetalle" :titulo="detalle ? `Pedido #${detalle.id}` : ''">
      <div v-if="detalle" class="pila">
        <div class="fila entre">
          <Insignia :tono="tonoEstado(detalle.estado)">{{ detalle.estado }}</Insignia>
          <strong class="numeros">{{ bs(totalDe(detalle)) }}</strong>
        </div>
        <dl class="datos">
          <dt>Cliente</dt><dd>{{ clienteDe(detalle) }}</dd>
          <dt>Sucursal</dt><dd>{{ sucursalDe(detalle) || '—' }}</dd>
          <dt>Modalidad</dt><dd>{{ detalle.modalidad === 'DELIVERY' ? 'Delivery' : 'Retiro en local' }}</dd>
          <template v-if="detalle.modalidad === 'DELIVERY'"><dt>Dirección</dt><dd>{{ detalle.direccionEntrega || '—' }}</dd></template>
          <dt>Venta</dt><dd>#{{ detalle.ventaId }}</dd>
          <dt>Tiempo de servicio</dt>
          <dd :class="{ rojo: minutosDe(detalle) > META_MIN }">{{ duracion(minutosDe(detalle)) }} <span class="texto-tenue">(meta {{ META_MIN }} min)</span></dd>
        </dl>

        <ol class="linea-tiempo" aria-label="Etapas del pedido">
          <li v-for="e in etapas" :key="e.texto" :class="{ hecho: e.hecho }">
            <span class="hito"><AppIcon v-if="e.hecho" name="check" :size="12" /></span>
            <div>
              <strong>{{ e.texto }}</strong>
              <div class="texto-chico texto-tenue">{{ e.fecha ? fechaHora(e.fecha) + ' · ' + haceCuanto(e.fecha) : 'Pendiente' }}<template v-if="e.desde"> · +{{ e.desde }}</template></div>
            </div>
          </li>
        </ol>
      </div>
      <template #pie>
        <button v-if="detalle && puedeEliminar" type="button" class="btn btn-peligro" style="margin-right: auto" @click="eliminar(detalle)"><AppIcon name="trash" :size="16" /> Eliminar</button>
        <button v-if="detalle && !['ENTREGADO', 'CANCELADO'].includes(detalle.estado)" type="button" class="btn btn-secundario" @click="cancelar(detalle)">Cancelar pedido</button>
        <button v-if="detalle && COLUMNAS.find((c) => c.clave === detalle.estado)" type="button" class="btn btn-primario" :disabled="moviendo === detalle.id" @click="cambiarEstado(detalle, COLUMNAS.find((c) => c.clave === detalle.estado).siguiente)">
          {{ COLUMNAS.find((c) => c.clave === detalle.estado).accion }}
        </button>
      </template>
    </AppModal>
  </div>
</template>

<style scoped>
.filtros { display: flex; gap: 12px; flex-wrap: wrap; align-items: center; }
.buscador { width: min(300px, 100%); }
.rojo { color: var(--peligro); font-weight: 700; }

.tablero { display: grid; grid-template-columns: repeat(3, minmax(250px, 1fr)); gap: 18px; align-items: start; overflow-x: auto; padding-bottom: 8px; }
.columna { background: var(--superficie-2); border-radius: var(--r-md); padding: 12px; display: grid; gap: 12px; min-height: 160px; align-content: start; }
.col-cab { display: flex; align-items: center; justify-content: space-between; padding: 2px 4px; }
.col-vacia { text-align: center; padding: 28px 0; font-size: 14px; }

.pedido { overflow: hidden; }
.pedido.tarde { border-color: #e7b3a9; box-shadow: 0 0 0 1px #e7b3a9; }
.pedido-cuerpo { display: grid; gap: 6px; width: 100%; text-align: left; background: none; border: none; padding: 14px 14px 10px; cursor: pointer; font: inherit; color: inherit; }
.pedido-cuerpo:hover { background: #fcf9f3; }
.reloj { display: inline-flex; align-items: center; gap: 4px; font-size: 13px; color: var(--texto-2); font-weight: 600; }
.direccion { display: flex; gap: 6px; align-items: flex-start; }
.pedido-acciones { display: flex; gap: 6px; padding: 0 12px 12px; }

.clic { cursor: pointer; }
.datos { display: grid; grid-template-columns: max-content 1fr; gap: 8px 18px; margin: 0; }
.datos dt { color: var(--texto-3); font-size: 13px; }
.datos dd { margin: 0; font-weight: 600; }

.linea-tiempo { list-style: none; margin: 0; padding: 0; display: grid; gap: 14px; }
.linea-tiempo li { display: flex; gap: 12px; align-items: flex-start; position: relative; color: var(--texto-3); }
.linea-tiempo li:not(:last-child)::after { content: ""; position: absolute; left: 9px; top: 22px; bottom: -14px; width: 2px; background: var(--borde); }
.linea-tiempo li.hecho { color: var(--texto); }
.hito { flex: none; width: 20px; height: 20px; border-radius: 50%; border: 2px solid var(--borde-fuerte); background: var(--superficie); display: grid; place-items: center; color: #fff; }
.linea-tiempo li.hecho .hito { background: var(--ok); border-color: var(--ok); }
</style>
