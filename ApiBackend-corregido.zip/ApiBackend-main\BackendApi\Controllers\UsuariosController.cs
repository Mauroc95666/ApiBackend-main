using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using BackendApi.Models;
using BackendApi.Services;

namespace BackendApi.Controllers;

// Req. 3: gestión de usuarios (solo administradores). Los roles definen qué puede hacer cada uno.
[ApiController]
[Route("api/[controller]")]
[Authorize(Policy = "Admin")]
public class UsuariosController : ControllerBase
{
    private readonly ApplicationDbContext _context;
    private readonly AuditoriaService _auditoria;

    public UsuariosController(ApplicationDbContext context, AuditoriaService auditoria)
    {
        _context = context;
        _auditoria = auditoria;
    }

    // Nunca se devuelve el hash de la contraseña.
    private static object Proyectar(Usuario u) =>
        new { u.Id, u.EmprendimientoId, u.RolId, u.Nombre, u.Email, u.Activo };

    // Cuántos administradores activos hay, sin contar al usuario indicado.
    private async Task<int> OtrosAdminsActivos(int excluirId)
    {
        var activos = await _context.Usuarios.Include(u => u.Rol).Where(u => u.Activo && u.Id != excluirId).ToListAsync();
        return activos.Count(u => RolHelper.EsAdmin(u.Rol.Nombre));
    }

    [HttpGet]
    public async Task<IActionResult> ObtenerUsuarios()
    {
        var usuarios = await _context.Usuarios.AsNoTracking().ToListAsync();
        return Ok(usuarios.Select(Proyectar));
    }

    [HttpGet("{id}")]
    public async Task<IActionResult> ObtenerUsuarioPorId(int id)
    {
        var usuario = await _context.Usuarios.AsNoTracking().FirstOrDefaultAsync(u => u.Id == id);

        if (usuario == null)
            return NotFound(new { mensaje = $"Usuario con id {id} no encontrado" });

        return Ok(Proyectar(usuario));
    }

    [HttpPost]
    public async Task<IActionResult> CrearUsuario([FromBody] Usuario nuevoUsuario)
    {
        if (nuevoUsuario == null)
            return BadRequest(new { mensaje = "Los datos del usuario son requeridos" });

        if (string.IsNullOrWhiteSpace(nuevoUsuario.Nombre) || string.IsNullOrWhiteSpace(nuevoUsuario.Email) || !nuevoUsuario.Email.Contains('@'))
            return BadRequest(new { mensaje = "Nombre y un correo válido son requeridos" });

        var motivo = PasswordService.ValidarFortaleza(nuevoUsuario.PasswordHash);
        if (motivo != null)
            return BadRequest(new { mensaje = motivo });

        nuevoUsuario.Email = nuevoUsuario.Email.Trim();
        if (await _context.Usuarios.AnyAsync(u => u.Email.ToLower() == nuevoUsuario.Email.ToLower()))
            return Conflict(new { mensaje = "Ya existe un usuario con ese correo" });
        if (!await _context.Roles.AnyAsync(r => r.Id == nuevoUsuario.RolId))
            return BadRequest(new { mensaje = $"No existe el rol {nuevoUsuario.RolId}" });

        nuevoUsuario.Id = 0;
        nuevoUsuario.Rol = null!;
        nuevoUsuario.Emprendimiento = null!;
        nuevoUsuario.PasswordHash = PasswordService.Hashear(nuevoUsuario.PasswordHash);
        _context.Usuarios.Add(nuevoUsuario);
        await _context.SaveChangesAsync();
        await _auditoria.RegistrarAsync("CREAR", "Usuario", $"Usuario {nuevoUsuario.Email} (id {nuevoUsuario.Id}, rol {nuevoUsuario.RolId})");

        return CreatedAtAction(nameof(ObtenerUsuarioPorId), new { id = nuevoUsuario.Id }, Proyectar(nuevoUsuario));
    }

    [HttpPut("{id}")]
    public async Task<IActionResult> ActualizarUsuario(int id, [FromBody] Usuario usuarioActualizado)
    {
        var usuario = await _context.Usuarios.Include(u => u.Rol).FirstOrDefaultAsync(u => u.Id == id);

        if (usuario == null)
            return NotFound(new { mensaje = $"Usuario con id {id} no encontrado" });

        if (string.IsNullOrWhiteSpace(usuarioActualizado.Nombre) || string.IsNullOrWhiteSpace(usuarioActualizado.Email))
            return BadRequest(new { mensaje = "Nombre y correo son requeridos" });

        var email = usuarioActualizado.Email.Trim();
        if (await _context.Usuarios.AnyAsync(u => u.Id != id && u.Email.ToLower() == email.ToLower()))
            return Conflict(new { mensaje = "Ya existe un usuario con ese correo" });

        var nuevoRol = await _context.Roles.FindAsync(usuarioActualizado.RolId);
        if (nuevoRol == null)
            return BadRequest(new { mensaje = $"No existe el rol {usuarioActualizado.RolId}" });

        // No dejar el sistema sin administradores (ni auto-bloquearse).
        var seguiraAdmin = usuarioActualizado.Activo && RolHelper.EsAdmin(nuevoRol.Nombre);
        if (RolHelper.EsAdmin(usuario.Rol.Nombre) && usuario.Activo && !seguiraAdmin && await OtrosAdminsActivos(id) == 0)
            return Conflict(new { mensaje = "Debe quedar al menos un administrador activo" });

        usuario.Nombre = usuarioActualizado.Nombre.Trim();
        usuario.Email = email;
        // Contraseña vacía = no cambiarla.
        if (!string.IsNullOrWhiteSpace(usuarioActualizado.PasswordHash))
        {
            var motivo = PasswordService.ValidarFortaleza(usuarioActualizado.PasswordHash);
            if (motivo != null) return BadRequest(new { mensaje = motivo });
            usuario.PasswordHash = PasswordService.Hashear(usuarioActualizado.PasswordHash);
        }
        usuario.RolId = usuarioActualizado.RolId;
        usuario.Activo = usuarioActualizado.Activo;

        await _context.SaveChangesAsync();
        await _auditoria.RegistrarAsync("ACTUALIZAR", "Usuario", $"Usuario {usuario.Email} (id {id}, rol {usuario.RolId}, activo {usuario.Activo})");

        return Ok(new { mensaje = "Usuario actualizado correctamente", usuario = Proyectar(usuario) });
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> EliminarUsuario(int id)
    {
        var usuario = await _context.Usuarios.Include(u => u.Rol).FirstOrDefaultAsync(u => u.Id == id);

        if (usuario == null)
            return NotFound(new { mensaje = $"Usuario con id {id} no encontrado" });

        if (RolHelper.UsuarioId(User) == id)
            return Conflict(new { mensaje = "No podés eliminar tu propio usuario" });
        if (RolHelper.EsAdmin(usuario.Rol.Nombre) && usuario.Activo && await OtrosAdminsActivos(id) == 0)
            return Conflict(new { mensaje = "Debe quedar al menos un administrador activo" });

        _context.Usuarios.Remove(usuario);
        await _context.SaveChangesAsync();
        await _auditoria.RegistrarAsync("ELIMINAR", "Usuario", $"Usuario {usuario.Email} (id {id})");

        return Ok(new { mensaje = $"Usuario {id} eliminado correctamente" });
    }
}
