import { reactive } from 'vue';
import { guardarToken, leerToken, vencimientoToken, registrarAlVencerSesion } from '@/api/axios';
import { toast } from '@/ui/feedback';

// Store simple con reactive() (sin vuex/pinia). Guarda quién inició sesión y qué pantalla se muestra.
// La sesión se persiste en sessionStorage: sobrevive a recargar la página y se borra al cerrar la pestaña.
const CLAVE_SESION = 'kiataque_sesion';

function leerSesion() {
  try {
    return JSON.parse(sessionStorage.getItem(CLAVE_SESION));
  } catch {
    return null;
  }
}
function escribirSesion(s) {
  try {
    if (s) sessionStorage.setItem(CLAVE_SESION, JSON.stringify(s));
    else sessionStorage.removeItem(CLAVE_SESION);
  } catch {
    // sin almacenamiento: la sesión dura hasta recargar.
  }
}

// ---------- Roles ----------
// Mismo criterio que el backend (RolHelper.cs): se deduce por el nombre del rol.
export function rolEsAdmin(nombreRol) {
  const n = (nombreRol || '').toLowerCase();
  return n.includes('admin') || n.includes('super') || n.includes('gerente');
}

function esInventario(n) {
  return n.includes('inventario') || n.includes('almac') || n.includes('bodega') || n.includes('stock');
}

// Módulos del panel que puede ver cada rol. '*' = todos.
export function accesoDeRol(nombreRol) {
  const n = (nombreRol || '').toLowerCase();
  if (!n || n === 'setuproot') return [];
  if (rolEsAdmin(n)) return '*';
  // Inventario se evalúa primero: "inventario" contiene la palabra "venta".
  if (esInventario(n)) return ['inicio', 'inventario', 'productos', 'categorias', 'proveedores', 'notificaciones'];
  if (n.includes('cajero') || n.includes('caja') || n.includes('vendedor') || n.includes('ventas')) {
    return ['inicio', 'ventas', 'pedidos', 'clientes', 'productos', 'notificaciones'];
  }
  return [];
}

export function rolEsStaff(nombreRol) {
  if (rolEsAdmin(nombreRol)) return false;
  return accesoDeRol(nombreRol).length > 0;
}

export function puedeVer(clave) {
  const a = accesoDeRol(store.rolNombre);
  return a === '*' || a.includes(clave);
}

// ---------- Store ----------
export const store = reactive({
  // pantalla: 'login' | 'tienda' | 'panel' | 'setup'
  pantalla: 'login',
  usuario: null,
  rolNombre: '',
  sucursalId: null, // sucursal del empleado (null = todas)
  esAdmin: false,

  // Recibe la respuesta de POST /auth/login y decide a dónde va cada rol.
  iniciarSesion({ token, usuario, rolNombre, sucursalId }) {
    guardarToken(token);
    this.usuario = usuario;
    this.rolNombre = rolNombre || '';
    this.sucursalId = sucursalId ?? null;
    this.esAdmin = rolEsAdmin(rolNombre);
    escribirSesion({ usuario, rolNombre: this.rolNombre, sucursalId: this.sucursalId });

    if (rolNombre === 'SetupRoot') this.pantalla = 'setup';
    else if (this.esAdmin || rolEsStaff(rolNombre)) this.pantalla = 'panel';
    else this.pantalla = 'tienda';
  },

  // Al cargar la página: recupera la sesión si el token todavía no venció.
  restaurar() {
    const token = leerToken();
    const s = leerSesion();
    const vence = token ? vencimientoToken(token) : null;
    if (token && s && vence && vence > Date.now()) {
      this.usuario = s.usuario;
      this.rolNombre = s.rolNombre;
      this.sucursalId = s.sucursalId ?? null;
      this.esAdmin = rolEsAdmin(s.rolNombre);
      if (s.rolNombre === 'SetupRoot') this.pantalla = 'setup';
      else if (this.esAdmin || rolEsStaff(s.rolNombre)) this.pantalla = 'panel';
      else this.pantalla = 'tienda';
      return;
    }
    guardarToken(null);
    escribirSesion(null);
    this.pantalla = location.hash.startsWith('#/tienda') ? 'tienda' : 'login';
  },

  entrarComoVisitante() {
    this.pantalla = 'tienda';
    location.hash = '#/tienda';
  },

  cerrarSesion() {
    guardarToken(null);
    escribirSesion(null);
    this.usuario = null;
    this.rolNombre = '';
    this.sucursalId = null;
    this.esAdmin = false;
    this.pantalla = 'login';
    location.hash = '';
  },
});

// Si la API responde 401 con una sesión abierta, volvemos al inicio de sesión avisando por qué.
registrarAlVencerSesion(() => {
  if (store.pantalla === 'login') return;
  store.cerrarSesion();
  toast.aviso('Tu sesión venció. Iniciá sesión de nuevo.');
});
