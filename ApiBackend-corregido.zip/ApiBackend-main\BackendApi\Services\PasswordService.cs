using System.Security.Cryptography;

namespace BackendApi.Services;

// Hash PBKDF2-SHA256 con formato "v1.iteraciones.salt.hash" (base64).
// Los usuarios viejos con contraseña en texto plano se detectan por no tener
// ese prefijo y se re-hashean en su primer login exitoso.
public static class PasswordService
{
    private const string Prefijo = "v1";
    private const int Iteraciones = 100_000;
    private const int TamSalt = 16;
    private const int TamHash = 32;

    public static string Hashear(string clave)
    {
        var salt = RandomNumberGenerator.GetBytes(TamSalt);
        var hash = Rfc2898DeriveBytes.Pbkdf2(clave, salt, Iteraciones, HashAlgorithmName.SHA256, TamHash);
        return $"{Prefijo}.{Iteraciones}.{Convert.ToBase64String(salt)}.{Convert.ToBase64String(hash)}";
    }

    // Política mínima de contraseñas (req. 8). Devuelve el motivo del rechazo o null si es válida.
    public static string? ValidarFortaleza(string? clave)
    {
        if (string.IsNullOrEmpty(clave) || clave.Length < 8) return "La contraseña debe tener al menos 8 caracteres.";
        if (!clave.Any(char.IsUpper) || !clave.Any(char.IsLower) || !clave.Any(char.IsDigit))
            return "La contraseña debe incluir mayúscula, minúscula y número.";
        return null;
    }

    public static bool EstaHasheada(string almacenado) => almacenado.StartsWith(Prefijo + ".");

    public static bool Verificar(string clave, string almacenado)
    {
        if (!EstaHasheada(almacenado))
        {
            // Contraseña heredada en texto plano.
            return CryptographicOperations.FixedTimeEquals(
                System.Text.Encoding.UTF8.GetBytes(clave),
                System.Text.Encoding.UTF8.GetBytes(almacenado));
        }

        var partes = almacenado.Split('.');
        if (partes.Length != 4 || !int.TryParse(partes[1], out var iter)) return false;

        var salt = Convert.FromBase64String(partes[2]);
        var esperado = Convert.FromBase64String(partes[3]);
        var calculado = Rfc2898DeriveBytes.Pbkdf2(clave, salt, iter, HashAlgorithmName.SHA256, esperado.Length);
        return CryptographicOperations.FixedTimeEquals(calculado, esperado);
    }
}
