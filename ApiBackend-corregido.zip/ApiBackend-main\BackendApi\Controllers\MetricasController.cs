using BackendApi.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace BackendApi.Controllers;

// Req. 7: tiempos de respuesta medidos (p50/p95/p99 por ruta) frente a las metas del documento.
[ApiController]
[Route("api/[controller]")]
[Authorize(Policy = "Admin")]
public class MetricasController : ControllerBase
{
    private readonly MetricasService _metricas;

    public MetricasController(MetricasService metricas) => _metricas = metricas;

    [HttpGet]
    public IActionResult Obtener() => Ok(_metricas.Resumen());
}
