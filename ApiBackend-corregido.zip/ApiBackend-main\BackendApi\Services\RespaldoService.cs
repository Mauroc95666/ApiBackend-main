using BackendApi.Models;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;

namespace BackendApi.Services;

// Req. 10: respaldo de la base con BACKUP DATABASE + verificación (RESTORE VERIFYONLY).
// La restauración NO se expone por la API (es destructiva): se hace con scripts/restaurar.ps1.
public class RespaldoService
{
    private readonly IConfiguration _config;
    private readonly ApplicationDbContext _context;

    public RespaldoService(IConfiguration config, ApplicationDbContext context)
    {
        _config = config;
        _context = context;
    }

    public record Resultado(string Archivo, string Carpeta, bool Verificado, DateTime FechaUtc);

    string NombreBase()
    {
        var b = new SqlConnectionStringBuilder(_config.GetConnectionString("ConexionDB"));
        return b.InitialCatalog;
    }

    // Carpeta configurada o, si no hay, la carpeta de respaldos por defecto de la instancia
    // (la cuenta de SQL Server siempre tiene permiso de escritura ahí).
    async Task<string> CarpetaAsync()
    {
        var carpeta = _config["Backup:Carpeta"];
        if (!string.IsNullOrWhiteSpace(carpeta)) return carpeta;
        var cn = _context.Database.GetDbConnection();
        await _context.Database.OpenConnectionAsync();
        try
        {
            using var cmd = cn.CreateCommand();
            cmd.CommandText = "SELECT CAST(SERVERPROPERTY('InstanceDefaultBackupPath') AS nvarchar(512))";
            var r = await cmd.ExecuteScalarAsync();
            return r as string ?? "/var/opt/mssql/data";
        }
        finally { await _context.Database.CloseConnectionAsync(); }
    }

    public async Task<Resultado> RespaldarAsync(CancellationToken ct = default)
    {
        var db = NombreBase();
        var carpeta = (await CarpetaAsync()).TrimEnd('\\', '/');
        var sep = carpeta.Contains('\\') ? "\\" : "/";
        var ahora = DateTime.UtcNow;
        var archivo = $"{db}_{ahora:yyyyMMdd_HHmmss}.bak";
        var ruta = carpeta + sep + archivo;

        // Los nombres de base de datos no se pueden parametrizar: viene de la cadena de conexión
        // (configuración del servidor), nunca de la petición, y se entrecomilla con QUOTENAME.
        var sql = "DECLARE @db sysname = @pdb; DECLARE @q nvarchar(max) = " +
                  "N'BACKUP DATABASE ' + QUOTENAME(@db) + N' TO DISK = @ruta WITH INIT, CHECKSUM, STATS = 10'; " +
                  "EXEC sp_executesql @q, N'@ruta nvarchar(512)', @ruta = @pruta;";
        await _context.Database.ExecuteSqlRawAsync(sql, new[]
        {
            new SqlParameter("@pdb", db),
            new SqlParameter("@pruta", ruta),
        });

        var verificado = true;
        try
        {
            await _context.Database.ExecuteSqlRawAsync(
                "RESTORE VERIFYONLY FROM DISK = @pruta WITH CHECKSUM", new SqlParameter("@pruta", ruta));
        }
        catch { verificado = false; }

        return new Resultado(archivo, carpeta, verificado, ahora);
    }

    // Historial de respaldos de esta base (SQL Server lo guarda en msdb).
    public async Task<List<object>> HistorialAsync(int max = 30)
    {
        var lista = new List<object>();
        var cn = _context.Database.GetDbConnection();
        await _context.Database.OpenConnectionAsync();
        try
        {
            using var cmd = cn.CreateCommand();
            cmd.CommandText = @"SELECT TOP (@n) bs.backup_finish_date, bs.backup_size, bmf.physical_device_name
                                FROM msdb.dbo.backupset bs
                                JOIN msdb.dbo.backupmediafamily bmf ON bmf.media_set_id = bs.media_set_id
                                WHERE bs.database_name = @db AND bs.type = 'D'
                                ORDER BY bs.backup_finish_date DESC";
            cmd.Parameters.Add(new SqlParameter("@n", max));
            cmd.Parameters.Add(new SqlParameter("@db", NombreBase()));
            using var rd = await cmd.ExecuteReaderAsync();
            while (await rd.ReadAsync())
                lista.Add(new { fecha = rd.GetDateTime(0), tamanoBytes = (long)rd.GetDecimal(1), archivo = rd.GetString(2) });
        }
        finally { await _context.Database.CloseConnectionAsync(); }
        return lista;
    }
}

// Respaldo automático diario. Configurable: Backup:Automatico (true/false) y Backup:HoraUtc (0-23).
public class RespaldoDiarioHostedService : BackgroundService
{
    private readonly IServiceScopeFactory _scopes;
    private readonly IConfiguration _config;
    private readonly ILogger<RespaldoDiarioHostedService> _log;

    public RespaldoDiarioHostedService(IServiceScopeFactory scopes, IConfiguration config, ILogger<RespaldoDiarioHostedService> log)
    {
        _scopes = scopes;
        _config = config;
        _log = log;
    }

    protected override async Task ExecuteAsync(CancellationToken ct)
    {
        if (!_config.GetValue("Backup:Automatico", true)) return;
        var hora = Math.Clamp(_config.GetValue("Backup:HoraUtc", 6), 0, 23);

        while (!ct.IsCancellationRequested)
        {
            var ahora = DateTime.UtcNow;
            var proxima = ahora.Date.AddHours(hora);
            if (proxima <= ahora) proxima = proxima.AddDays(1);
            try { await Task.Delay(proxima - ahora, ct); }
            catch (OperationCanceledException) { return; }

            try
            {
                using var scope = _scopes.CreateScope();
                var r = await scope.ServiceProvider.GetRequiredService<RespaldoService>().RespaldarAsync(ct);
                _log.LogInformation("Respaldo automático {Archivo} (verificado: {Ok})", r.Archivo, r.Verificado);
            }
            catch (Exception ex)
            {
                _log.LogError(ex, "Falló el respaldo automático");
            }
        }
    }
}
