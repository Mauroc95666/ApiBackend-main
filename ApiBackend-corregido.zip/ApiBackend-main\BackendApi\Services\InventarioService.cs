using BackendApi.Models;
using Microsoft.EntityFrameworkCore;

namespace BackendApi.Services;

// Req. 1: entradas y salidas de inventario. El stock y el movimiento se guardan juntos
// (transacción) y la salida nunca deja el stock en negativo, aunque dos cajeros vendan a la vez.
public class InventarioService
{
    private readonly ApplicationDbContext _context;

    public InventarioService(ApplicationDbContext context) => _context = context;

    public record Resultado(bool Ok, int Codigo, string Mensaje, int? StockActual = null, MovimientoInventario? Movimiento = null);

    public async Task<Resultado> AplicarMovimientoAsync(int inventarioId, string tipo, int cantidad, string? motivo, int usuarioId, int? sucursalRestringida)
    {
        tipo = (tipo ?? "").Trim().ToUpperInvariant();
        if (tipo != "ENTRADA" && tipo != "SALIDA")
            return new Resultado(false, 400, "El tipo debe ser ENTRADA o SALIDA");
        if (cantidad <= 0)
            return new Resultado(false, 400, "La cantidad debe ser mayor a 0");

        var inv = await _context.Inventarios.AsNoTracking().Include(i => i.Producto)
            .FirstOrDefaultAsync(i => i.Id == inventarioId);
        if (inv == null || (sucursalRestringida.HasValue && inv.SucursalId != sucursalRestringida.Value))
            return new Resultado(false, 404, $"Inventario con id {inventarioId} no encontrado");

        await using var tx = await _context.Database.BeginTransactionAsync();

        // UPDATE atómico con condición: en una salida solo se aplica si alcanza el stock.
        var filas = tipo == "ENTRADA"
            ? await _context.Inventarios.Where(i => i.Id == inventarioId)
                .ExecuteUpdateAsync(s => s.SetProperty(i => i.StockActual, i => i.StockActual + cantidad))
            : await _context.Inventarios.Where(i => i.Id == inventarioId && i.StockActual >= cantidad)
                .ExecuteUpdateAsync(s => s.SetProperty(i => i.StockActual, i => i.StockActual - cantidad));

        if (filas == 0)
        {
            var disponible = await _context.Inventarios.Where(i => i.Id == inventarioId).Select(i => i.StockActual).FirstOrDefaultAsync();
            return new Resultado(false, 409, $"Stock insuficiente de '{inv.Producto.Nombre}' (disponible: {disponible})");
        }

        var mov = new MovimientoInventario
        {
            InventarioId = inventarioId,
            UsuarioId = usuarioId,
            Tipo = tipo,
            Cantidad = cantidad,
            Fecha = DateTime.UtcNow,
            Motivo = string.IsNullOrWhiteSpace(motivo) ? null : motivo.Trim(),
        };
        _context.MovimientoInventario.Add(mov);

        var nuevo = await _context.Inventarios.Where(i => i.Id == inventarioId).Select(i => i.StockActual).FirstAsync();

        // Req. 4: alerta de stock bajo para quienes controlan el inventario.
        if (tipo == "SALIDA" && inv.StockMinimo.HasValue && nuevo <= inv.StockMinimo.Value)
        {
            var mensaje = $"Stock bajo de '{inv.Producto.Nombre}': quedan {nuevo} (mínimo {inv.StockMinimo})";
            var destinatarios = (await _context.Usuarios.Include(u => u.Rol).Where(u => u.Activo).ToListAsync())
                .Where(u => RolHelper.PuedeInventario(u.Rol.Nombre)).Select(u => u.Id);
            foreach (var d in destinatarios)
                _context.Notificaciones.Add(new Notificacion { UsuarioId = d, Mensaje = mensaje, Leido = false, Fecha = DateTime.UtcNow });
        }

        await _context.SaveChangesAsync();
        await tx.CommitAsync();
        return new Resultado(true, 201, $"{tipo} registrada", nuevo, mov);
    }
}
