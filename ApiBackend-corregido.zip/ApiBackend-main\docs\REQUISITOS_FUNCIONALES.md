# Requisitos funcionales: qué se implementó y cómo comprobarlo

Cada requisito indica dónde está el código y cómo verlo funcionando. Las rutas son de `BackendApi/` salvo que
se indique otra cosa.

| # | Requisito | Dónde |
|---|-----------|-------|
| 1 | Inventario: entradas y salidas | `Services/InventarioService.cs`, `Controllers/InventariosController.cs`, `MovimientosInventarioController.cs` |
| 2 | Sucursal y modalidad (retiro / delivery) | `Controllers/VentasController.cs`, `Models/Pedido.cs`, `FrontendVue/src/components/TiendaCliente.vue` |
| 3 | Usuarios, roles y permisos | `Services/RolHelper.cs`, `Program.cs` (políticas), `Controllers/UsuariosController.cs` |
| 4 | Reportes, promociones, reseñas, notificaciones | `ReportesController`, `PromocionesController`, `ResenasController`, `NotificacionesController` |
| 5 | Hash, JWT, UNIQUE, CHECK, FK | `Services/PasswordService.cs`, `Services/TokenService.cs`, `db/02_requisitos.sql` |
| 6 | Primer administrador con super-usuario oculto | `Controllers/AuthController.cs`, `Controllers/SetupController.cs` |
| 7 | Rendimiento | `Program.cs` (caché, compresión, métricas), `Services/MetricasService.cs`, índices en `db/02_requisitos.sql` |
| 8 | Seguridad | `Program.cs` (CORS, HTTPS/HSTS, límite de intentos, cabeceras), políticas por rol |
| 9 | Multi-sucursal y Ley 164 | claim `sucursalId` + `RolHelper.SucursalRestringida`, `ClientesController` (consentimiento, acceso, anonimizado), `AuditoriaService` |
| 10 | Respaldo y recuperación | `Services/RespaldoService.cs`, `scripts/respaldar.ps1`, `scripts/restaurar.ps1` |
| 11 | Tiempo de servicio por pedido | `Models/Pedido.cs`, `PedidosController`, `ReportesController.TiemposServicio` |

## 1. Inventario: entradas y salidas

- `POST /api/inventarios/{id}/movimiento` con `{ tipo: "ENTRADA" | "SALIDA", cantidad, motivo }`.
- El stock se actualiza con un `UPDATE` condicional, así una salida nunca deja el stock en negativo, aunque dos
  cajeros vendan al mismo tiempo. Stock y movimiento se guardan en una sola transacción.
- Cada venta descuenta stock de la sucursal y deja su movimiento de `SALIDA`.
- El historial (`/api/movimientosinventario`) no se edita ni se borra; un error se corrige con un movimiento
  contrario. Quien lo hizo sale del token, no del cuerpo de la petición.
- Alerta de stock bajo: al bajar del `StockMinimo` se crea una notificación para el personal de inventario y los
  administradores. `GET /api/inventarios/stock-bajo` lista los productos en alerta.

## 2. Sucursal y modalidad de entrega

- La tienda manda `sucursalId`, `modalidad` (`RETIRO` o `DELIVERY`) y `direccionEntrega`.
- `POST /api/ventas` crea venta, detalle, **pedido**, descuento de stock y movimientos en una sola transacción.
- En `DELIVERY` la dirección es obligatoria (si no viene, se usa la del cliente).
- Los precios y el total los calcula el servidor con los datos de la base, no los que mande el navegador.

## 3. Usuarios, roles y permisos

| Rol (por nombre) | Puede |
|---|---|
| Administrador / Superadmin / Gerente | Todo: usuarios, roles, empleados, reportes, sistema, respaldos |
| Cajero / Vendedor | Ventas, pedidos, clientes; ver productos y notificaciones |
| Inventario | Inventario, movimientos, productos, categorías, proveedores |
| Cliente | Solo la tienda pública |

- Políticas: `Admin`, `Ventas`, `Inventario`, `Staff`, `SetupRoot` (en `Program.cs`).
- Contraseñas nuevas: mínimo 8 caracteres con mayúscula, minúscula y número.
- Siempre debe quedar al menos un administrador activo; nadie puede borrarse a sí mismo.
- Crear, modificar o eliminar usuarios queda en la tabla `Auditoria`.

## 4. Reportes, promociones, reseñas y notificaciones

- **Reportes** (solo administrador): `GET /api/reportes/ventas`, `/productos-top`, `/tiempos-servicio`, con
  `desde`, `hasta` y `sucursalId`. En el panel: *Reportes*.
- **Promociones**: `GET /api/promociones/vigentes` es público; el resto lo gestiona el administrador
  (descuento 0–100 y fechas coherentes).
- **Reseñas**: las lee cualquiera; solo reseña quien compró el producto (reseña verificada), una por cliente y
  producto, con calificación de 1 a 5. El administrador modera.
- **Notificaciones**: cada usuario ve las suyas (`GET /api/notificaciones`), las marca como leídas y las borra.

## 5. Seguridad y modelado de datos

- **Hash**: PBKDF2-SHA256, 100 000 iteraciones y sal aleatoria. Las claves en texto plano heredadas se migran
  solas en el primer login.
- **JWT**: firma HMAC-SHA256, emisor y audiencia validados, vence a las 8 h. La clave sale de `Jwt__Key`.
- **UNIQUE** (`db/02_requisitos.sql`): correo de usuario, nombre de rol, de permiso y de método de pago,
  categoría por emprendimiento, producto por sucursal en inventario, un empleado por usuario.
- **CHECK**: precios y stocks no negativos, cantidades mayores a 0, tipo de movimiento, estado y modalidad
  del pedido, calificación entre 1 y 5, descuento entre 0 y 100, fechas de promoción coherentes.
- **FK** que faltaban: `Producto → Categoria / Proveedor / Emprendimiento` y `Proveedor → Emprendimiento`.
- Los errores de la base se traducen a un `409` claro (valor duplicado o regla de integridad) en vez de un `500`.

## 6. Primer administrador con el super-usuario oculto

El script ya no siembra ningún usuario con clave conocida.

1. Definí en el servidor `Setup__Usuario` y `Setup__Clave` (en Docker: `SETUP_USUARIO` / `SETUP_CLAVE` del `.env`).
2. Iniciá sesión en la pantalla normal con esas credenciales. No está en la base ni aparece en `/api/usuarios`.
3. Se abre la pantalla **"Crear el primer administrador"**. Ese token solo sirve para
   `POST /api/setup/primer-admin`; todo lo demás responde 403.
4. En cuanto existe un administrador activo, el super-usuario deja de poder entrar y el endpoint responde 409.

Los accesos del super-usuario quedan en la auditoría. Si la base ya tiene el usuario de ejemplo
`superadmin@kiataque.bo` con la clave `Admin123`, el backend lo avisa en el log al arrancar: cambiá esa clave o
eliminá el usuario.

## 7. Rendimiento

- Catálogo público en caché de 30 s (se invalida al editar productos o promociones), compresión de respuestas,
  `AsNoTracking` en las lecturas e índices en `Venta(Fecha)`, `Pedido(Estado)`, `MovimientoInventario(Fecha)`,
  `Producto(Nombre)` y `Notificacion(UsuarioId, Leido)`.
- **Medición**: cada respuesta de `/api` lleva la cabecera `X-Response-Time-ms`. `GET /api/metricas` (o el panel
  *Sistema*) muestra p50 / p95 / p99 por ruta y compara contra las metas: catálogo < 2 s, venta < 3 s,
  API p95 < 500 ms. El respaldo se excluye de la meta global porque es una tarea de mantenimiento.
- Los números salen de las últimas 1000 llamadas por ruta, en memoria, y se reinician con el servidor.
  Para validar con carga real conviene usar una herramienta externa (k6, JMeter) sobre el entorno de producción.

## 8. Seguridad

- **Autorización por rol** en cada endpoint (por defecto todo exige sesión).
- **CORS restringido** a `Cors:Origins`, solo con los métodos y cabeceras que usa la API.
- **HTTPS**: fuera de desarrollo se activa la redirección a HTTPS y HSTS (`Https:Forzar`, activo por defecto).
  Detrás de nginx o un balanceador definí `Proxy__Confiar=true` para leer la IP y el esquema reales.
  El certificado TLS lo pone el servidor web o el proveedor de hosting.
- **Límite de intentos**: 8 logins por minuto por IP y 60 peticiones por minuto en los endpoints públicos que
  escriben (venta, cliente, reseña).
- Cabeceras `X-Content-Type-Options`, `X-Frame-Options`, `Referrer-Policy` y `Permissions-Policy`.
- Los errores internos no exponen detalles al cliente (quedan en el log del servidor).

## 9. Escalabilidad multi-sucursal y Ley 164

**Multi-sucursal**
- Un usuario queda ligado a su sucursal con un registro en *Empleados / sucursal*. Al iniciar sesión, el token
  lleva `sucursalId`.
- El personal que no es administrador solo ve y opera ventas, pedidos, inventario y movimientos de su sucursal.
  El administrador ve todas, con filtro opcional por sucursal.
- Agregar una sucursal es dar de alta un registro: inventario, ventas y pedidos ya van separados por `SucursalId`.

**Medidas técnicas relacionadas con la Ley 164 (Ley General de Telecomunicaciones, Tecnologías de Información y
Comunicación) y la protección de datos personales**
- **Consentimiento**: la tienda exige aceptar el tratamiento de datos personales para registrar la compra; la
  fecha de aceptación la fija el servidor (`Cliente.ConsentimientoFecha`).
- **Acceso**: `GET /api/clientes/{id}/datos` (administrador) entrega todo lo guardado de una persona.
- **Cancelación**: `POST /api/clientes/{id}/anonimizar` borra nombre, documento, teléfono, correo, dirección y
  comentarios de reseñas. Las ventas se conservan, sin datos identificables, por ser registros contables.
- **Seguridad y confidencialidad**: contraseñas con hash, nunca se devuelven; acceso por rol; HTTPS.
- **Trazabilidad**: la tabla `Auditoria` registra accesos, cambios de usuarios, anonimizaciones, respaldos y
  eliminaciones, con usuario y fecha.

> Esto cubre las medidas **técnicas**. El texto de la política de privacidad, los plazos de conservación y el
> cumplimiento de la normativa lo debe validar quien asesore legalmente a la panadería.

## 10. Backup y recuperación

Ver [RESPALDO_Y_RECUPERACION.md](RESPALDO_Y_RECUPERACION.md).

## 11. Tiempo de servicio por pedido

- Cada pedido guarda `FechaCreacion`, `FechaPreparacion`, `FechaListo` y `FechaEntregado` (UTC). Las pone el
  servidor al cambiar de estado, nunca el cliente.
- El pedido solo avanza paso a paso (`PENDIENTE → EN PREPARACION → LISTO → ENTREGADO`) y se puede cancelar
  antes de entregarse. Un pedido entregado o cancelado no cambia más.
- `GET /api/pedidos` devuelve `tiempoServicioMinutos` (ingreso → entrega). En el panel, la lista de pedidos
  muestra el tiempo de cada uno y marca en rojo los que pasan de la meta (30 min).
- `GET /api/reportes/tiempos-servicio`: promedio, mínimo, máximo y percentil 90, por modalidad y por
  sucursal; porcentaje que cumple la meta; espera de los pedidos en curso.

## Cómo probar todo

El script `scripts/prueba_api.ps1` recorre estos requisitos contra una base de pruebas (79 comprobaciones).
No lo ejecutes contra la base real: crea usuarios, ventas y respaldos.

## Presentación automática

`scripts\presentar.ps1` prepara una demo limpia (base `DB_Panaderia2_demo`, API en :5209, frontend en :5174), abre
Chrome y recorre los 11 requisitos solo, con un rótulo en pantalla que anuncia cada uno. No toca la base real.

```powershell
.\scripts\presentar.ps1               # presentación normal (unos 10 minutos)
.\scripts\presentar.ps1 -Pausa 1.5    # más lenta, para hablar con calma
.\scripts\presentar.ps1 -Rapido       # ensayo veloz
.\scripts\presentar.ps1 -Oculto -Rapido   # verificación sin ventana
```

Durante la presentación no muevas el mouse ni escribas sobre la ventana de Chrome que abre el script.
