using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using BackendApi.Models;

namespace BackendApi.Controllers;

[ApiController]
[Route("api/[controller]")]
public class SucursalesController : ControllerBase
{
    private readonly ApplicationDbContext _context;

    public SucursalesController(ApplicationDbContext context)
    {
        _context = context;
    }

    [AllowAnonymous]
    [HttpGet]
    public async Task<IActionResult> ObtenerSucursales()
    {
        var sucursales = await _context.Sucursales.ToListAsync();
        return Ok(sucursales);
    }

    [Authorize(Policy = "Staff")]
    [HttpGet("{id}")]
    public async Task<IActionResult> ObtenerSucursalPorId(int id)
    {
        var sucursal = await _context.Sucursales.FindAsync(id);

        if (sucursal == null)
            return NotFound(new { mensaje = $"Sucursal con id {id} no encontrada" });

        return Ok(sucursal);
    }

    [Authorize(Policy = "Admin")]
    [HttpPost]
    public async Task<IActionResult> CrearSucursal([FromBody] Sucursal nuevaSucursal)
    {
        if (nuevaSucursal == null)
            return BadRequest(new { mensaje = "Los datos de la sucursal son requeridos" });

        _context.Sucursales.Add(nuevaSucursal);
        await _context.SaveChangesAsync();

        return CreatedAtAction(nameof(ObtenerSucursalPorId), new { id = nuevaSucursal.Id }, nuevaSucursal);
    }

    [Authorize(Policy = "Admin")]
    [HttpPut("{id}")]
    public async Task<IActionResult> ActualizarSucursal(int id, [FromBody] Sucursal sucursalActualizada)
    {
        var sucursal = await _context.Sucursales.FindAsync(id);

        if (sucursal == null)
            return NotFound(new { mensaje = $"Sucursal con id {id} no encontrada" });

        sucursal.Nombre = sucursalActualizada.Nombre;
        sucursal.Direccion = sucursalActualizada.Direccion;
        sucursal.CiudadId = sucursalActualizada.CiudadId;
        sucursal.Telefono = sucursalActualizada.Telefono;

        await _context.SaveChangesAsync();

        return Ok(new { mensaje = "Sucursal actualizada correctamente", sucursal });
    }

    [Authorize(Policy = "Admin")]
    [HttpDelete("{id}")]
    public async Task<IActionResult> EliminarSucursal(int id)
    {
        var sucursal = await _context.Sucursales.FindAsync(id);

        if (sucursal == null)
            return NotFound(new { mensaje = $"Sucursal con id {id} no encontrada" });

        _context.Sucursales.Remove(sucursal);
        await _context.SaveChangesAsync();

        return Ok(new { mensaje = $"Sucursal {id} eliminada correctamente" });
    }
}