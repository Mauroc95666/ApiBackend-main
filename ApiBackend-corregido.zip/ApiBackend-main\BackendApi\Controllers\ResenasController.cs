using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.EntityFrameworkCore;
using BackendApi.Models;

namespace BackendApi.Controllers;

// Req. 4: reseñas de productos. Cualquiera puede leerlas; solo opina quien compró el producto.
[ApiController]
[Route("api/[controller]")]
[Authorize(Policy = "Admin")]
public class ResenasController : ControllerBase
{
    private readonly ApplicationDbContext _context;

    public ResenasController(ApplicationDbContext context)
    {
        _context = context;
    }

    [AllowAnonymous]
    [HttpGet]
    public async Task<IActionResult> ObtenerResenas([FromQuery] int? productoId)
    {
        var q = _context.Resenas.AsNoTracking().AsQueryable();
        if (productoId.HasValue) q = q.Where(r => r.ProductoId == productoId.Value);
        return Ok(await q.OrderByDescending(r => r.Fecha).Take(500).ToListAsync());
    }

    // Calificación promedio y cantidad de reseñas de cada producto (para el catálogo).
    [AllowAnonymous]
    [HttpGet("resumen")]
    public async Task<IActionResult> Resumen()
    {
        var resumen = await _context.Resenas.AsNoTracking().Where(r => r.Calificacion != null)
            .GroupBy(r => r.ProductoId)
            .Select(g => new { productoId = g.Key, promedio = Math.Round(g.Average(r => (double)r.Calificacion!), 1), cantidad = g.Count() })
            .ToListAsync();
        return Ok(resumen);
    }

    [AllowAnonymous]
    [HttpGet("{id}")]
    public async Task<IActionResult> ObtenerResenaPorId(int id)
    {
        var resena = await _context.Resenas.AsNoTracking().FirstOrDefaultAsync(r => r.Id == id);

        if (resena == null)
            return NotFound(new { mensaje = $"Reseña con id {id} no encontrada" });

        return Ok(resena);
    }

    [AllowAnonymous]
    [EnableRateLimiting("publico")]
    [HttpPost]
    public async Task<IActionResult> CrearResena([FromBody] Resena nuevaResena)
    {
        if (nuevaResena == null)
            return BadRequest(new { mensaje = "Los datos de la reseña son requeridos" });
        if (nuevaResena.Calificacion is null or < 1 or > 5)
            return BadRequest(new { mensaje = "La calificación debe estar entre 1 y 5" });
        if (nuevaResena.Comentario is { Length: > 500 })
            return BadRequest(new { mensaje = "El comentario no puede superar los 500 caracteres" });

        // Reseña verificada: el cliente tiene que haber comprado ese producto.
        var compro = await _context.DetalleVenta.AnyAsync(d => d.ProductoId == nuevaResena.ProductoId && d.Venta.ClienteId == nuevaResena.ClienteId);
        if (!compro)
            return BadRequest(new { mensaje = "Solo se puede reseñar un producto que el cliente compró" });
        if (await _context.Resenas.AnyAsync(r => r.ProductoId == nuevaResena.ProductoId && r.ClienteId == nuevaResena.ClienteId))
            return Conflict(new { mensaje = "Ya dejaste una reseña para este producto" });

        nuevaResena.Id = 0;
        nuevaResena.Producto = null!;
        nuevaResena.Cliente = null!;
        nuevaResena.Fecha = DateTime.UtcNow;
        _context.Resenas.Add(nuevaResena);
        await _context.SaveChangesAsync();

        return CreatedAtAction(nameof(ObtenerResenaPorId), new { id = nuevaResena.Id }, nuevaResena);
    }

    [HttpPut("{id}")]
    public async Task<IActionResult> ActualizarResena(int id, [FromBody] Resena resenaActualizada)
    {
        var resena = await _context.Resenas.FindAsync(id);

        if (resena == null)
            return NotFound(new { mensaje = $"Reseña con id {id} no encontrada" });
        if (resenaActualizada.Calificacion is null or < 1 or > 5)
            return BadRequest(new { mensaje = "La calificación debe estar entre 1 y 5" });

        resena.Calificacion = resenaActualizada.Calificacion;
        resena.Comentario = resenaActualizada.Comentario;

        await _context.SaveChangesAsync();

        return Ok(new { mensaje = "Reseña actualizada correctamente", resena });
    }

    // Moderación: el administrador puede quitar una reseña.
    [HttpDelete("{id}")]
    public async Task<IActionResult> EliminarResena(int id)
    {
        var resena = await _context.Resenas.FindAsync(id);

        if (resena == null)
            return NotFound(new { mensaje = $"Reseña con id {id} no encontrada" });

        _context.Resenas.Remove(resena);
        await _context.SaveChangesAsync();

        return Ok(new { mensaje = $"Reseña {id} eliminada correctamente" });
    }
}
