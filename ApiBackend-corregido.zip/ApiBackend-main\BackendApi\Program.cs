using System.Diagnostics;
using System.Security.Claims;
using System.Threading.RateLimiting;
using System.Security.Cryptography;
using System.Text;
using BackendApi.Controllers;
using BackendApi.Models;
using BackendApi.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.HttpOverrides;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;

var builder = WebApplication.CreateBuilder(args);

var corsPolicyName = "AllowFrontendVue";

// CORS: orígenes permitidos desde configuración (Cors:Origins). Por defecto, los de desarrollo.
var origenes = builder.Configuration.GetSection("Cors:Origins").Get<string[]>()
    ?? new[] { "http://localhost:5173", "http://localhost:8080" };
builder.Services.AddCors(options =>
{
    options.AddPolicy(name: corsPolicyName, policy =>
    {
        // Req. 8: solo los orígenes configurados, con los métodos y cabeceras que la API realmente usa.
        policy.WithOrigins(origenes)
              .WithHeaders("Content-Type", "Authorization")
              .WithMethods("GET", "POST", "PUT", "PATCH", "DELETE");
    });
});

// 1. Agregar servicios al contenedor
// SuppressImplicitRequiredAttributeForNonNullableReferenceTypes = true evita que
// .NET marque como obligatorias las propiedades de navegación, así el frontend
// puede crear registros mandando solo los ids sin recibir error 400.
builder.Services.AddControllers(options =>
{
    options.SuppressImplicitRequiredAttributeForNonNullableReferenceTypes = true;
});

// 2. Registrar el DbContext para la base de datos
builder.Services.AddDbContextPool<ApplicationDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("ConexionDB")));

// 3. Autenticación JWT. La clave sale de Jwt:Key (variable de entorno Jwt__Key).
// Si no está configurada se genera una aleatoria: sirve para desarrollo, pero los tokens
// dejan de valer al reiniciar la API.
var jwtKey = builder.Configuration["Jwt:Key"];
byte[] claveBytes;
if (string.IsNullOrWhiteSpace(jwtKey))
{
    if (!builder.Environment.IsDevelopment())
        throw new InvalidOperationException("Falta configurar Jwt:Key (variable de entorno Jwt__Key).");
    claveBytes = RandomNumberGenerator.GetBytes(32);
}
else
{
    claveBytes = Encoding.UTF8.GetBytes(jwtKey);
    if (claveBytes.Length < 32)
        throw new InvalidOperationException("Jwt:Key debe tener al menos 32 caracteres.");
}
var claveFirma = new SymmetricSecurityKey(claveBytes);
builder.Services.AddSingleton(claveFirma);

builder.Services
    .AddAuthentication(Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(o =>
    {
        o.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidIssuer = TokenService.Emisor,
            ValidateAudience = true,
            ValidAudience = TokenService.Audiencia,
            ValidateLifetime = true,
            ValidateIssuerSigningKey = true,
            IssuerSigningKey = claveFirma,
            ClockSkew = TimeSpan.FromMinutes(1),
        };
    });

builder.Services.AddAuthorization(o =>
{
    // Por defecto todo endpoint exige sesión; lo público se marca con [AllowAnonymous].
    o.FallbackPolicy = new AuthorizationPolicyBuilder().RequireAuthenticatedUser().Build();

    // Req. 3 y 8: autorización por rol.
    AuthorizationPolicy PorRol(Func<string?, bool> permitido) => new AuthorizationPolicyBuilder()
        .RequireAuthenticatedUser()
        .RequireAssertion(ctx => permitido(ctx.User.FindFirstValue(ClaimTypes.Role)))
        .Build();

    o.AddPolicy("Admin", PorRol(RolHelper.EsAdmin));
    o.AddPolicy("Ventas", PorRol(RolHelper.PuedeVentas));
    o.AddPolicy("Inventario", PorRol(RolHelper.PuedeInventario));
    o.AddPolicy("Staff", PorRol(RolHelper.EsStaff));
    // Req. 6: el super-usuario oculto solo sirve para crear el primer administrador.
    o.AddPolicy("SetupRoot", PorRol(r => r == RolHelper.RolSetup));
});

// Req. 8: límite de intentos para frenar fuerza bruta y abuso de los endpoints públicos.
builder.Services.AddRateLimiter(o =>
{
    o.RejectionStatusCode = StatusCodes.Status429TooManyRequests;
    RateLimitPartition<string> PorIp(HttpContext ctx, int limite) =>
        RateLimitPartition.GetFixedWindowLimiter(
            ctx.Connection.RemoteIpAddress?.ToString() ?? "desconocida",
            _ => new FixedWindowRateLimiterOptions { PermitLimit = limite, Window = TimeSpan.FromMinutes(1), QueueLimit = 0 });
    o.AddPolicy("login", ctx => PorIp(ctx, builder.Configuration.GetValue("RateLimit:LoginPorMinuto", 8)));
    o.AddPolicy("publico", ctx => PorIp(ctx, builder.Configuration.GetValue("RateLimit:PublicoPorMinuto", 60)));
});

// Req. 7: compresión de respuestas y caché del catálogo público.
builder.Services.AddResponseCompression(o => o.EnableForHttps = true);
builder.Services.AddOutputCache(o =>
{
    o.AddPolicy("catalogo", p => p.Expire(TimeSpan.FromSeconds(30)).Tag("catalogo"));
});

builder.Services.AddHttpContextAccessor();
builder.Services.AddSingleton<MetricasService>();
builder.Services.AddScoped<AuditoriaService>();
builder.Services.AddScoped<RespaldoService>();
builder.Services.AddScoped<InventarioService>();
builder.Services.AddSingleton<TokenService>();
builder.Services.AddHostedService<RespaldoDiarioHostedService>();

if (builder.Configuration.GetValue("Proxy:Confiar", false))
{
    // Detrás de nginx/un balanceador: respeta X-Forwarded-For/Proto (IP real y esquema https).
    builder.Services.Configure<ForwardedHeadersOptions>(o =>
    {
        o.ForwardedHeaders = ForwardedHeaders.XForwardedFor | ForwardedHeaders.XForwardedProto;
        o.KnownNetworks.Clear();
        o.KnownProxies.Clear();
    });
}

// 4. Configurar Swagger para documentación de la API
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// 5. Swagger solo en desarrollo
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

// Avisos de arranque sobre las cuentas (req. 6): sin administrador, o con la clave de ejemplo heredada.
using (var scope = app.Services.CreateScope())
{
    try
    {
        var db = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();
        if (!await SetupController.ExisteAdminAsync(db))
            app.Logger.LogWarning("No hay ningún administrador. Ingresá con el super-usuario (Setup__Usuario / Setup__Clave) para crear el primero.");
        var legado = await db.Usuarios.FirstOrDefaultAsync(u => u.Email == "superadmin@kiataque.bo");
        if (legado != null && PasswordService.Verificar("Admin123", legado.PasswordHash))
            app.Logger.LogWarning("El usuario superadmin@kiataque.bo todavía usa la contraseña de ejemplo 'Admin123'. Cambiala o eliminá el usuario.");
    }
    catch (Exception ex)
    {
        app.Logger.LogWarning("No se pudo verificar el estado de las cuentas al arrancar: {Mensaje}", ex.Message);
    }
}

if (builder.Configuration.GetValue("Proxy:Confiar", false))
    app.UseForwardedHeaders();

// Req. 8: HTTPS obligatorio fuera de desarrollo (configurable con Https:Forzar).
if (!app.Environment.IsDevelopment() && app.Configuration.GetValue("Https:Forzar", true))
{
    app.UseHsts();
    app.UseHttpsRedirection();
}

// Cabeceras de seguridad básicas.
app.Use(async (ctx, next) =>
{
    ctx.Response.Headers["X-Content-Type-Options"] = "nosniff";
    ctx.Response.Headers["X-Frame-Options"] = "DENY";
    ctx.Response.Headers["Referrer-Policy"] = "no-referrer";
    ctx.Response.Headers["Permissions-Policy"] = "geolocation=(), camera=(), microphone=()";
    await next();
});

// Req. 7: mide cada petición /api (cabecera X-Response-Time-ms y estadísticas en /api/metricas).
app.Use(async (ctx, next) =>
{
    if (!ctx.Request.Path.StartsWithSegments("/api")) { await next(); return; }
    var sw = Stopwatch.StartNew();
    ctx.Response.OnStarting(() =>
    {
        ctx.Response.Headers["X-Response-Time-ms"] = sw.Elapsed.TotalMilliseconds.ToString("F1");
        return Task.CompletedTask;
    });
    try { await next(); }
    finally
    {
        sw.Stop();
        var ruta = System.Text.RegularExpressions.Regex.Replace(ctx.Request.Path.Value ?? "", @"/\d+", "/{id}");
        ctx.RequestServices.GetRequiredService<MetricasService>()
            .Registrar($"{ctx.Request.Method} {ruta}", sw.Elapsed.TotalMilliseconds, ctx.Response.StatusCode);
    }
});

// Errores: nunca se devuelve el detalle interno al cliente; las violaciones de UNIQUE/CHECK/FK
// (req. 5) se traducen a un 409 entendible.
app.Use(async (ctx, next) =>
{
    try { await next(); }
    catch (Exception ex) when (!ctx.Response.HasStarted)
    {
        var sql = ex as Microsoft.Data.SqlClient.SqlException
                  ?? ex.InnerException as Microsoft.Data.SqlClient.SqlException;
        ctx.Response.ContentType = "application/json";
        if (sql is { Number: 2601 or 2627 })
        {
            ctx.Response.StatusCode = 409;
            await ctx.Response.WriteAsJsonAsync(new { mensaje = "Ya existe un registro con esos datos (valor duplicado)." });
        }
        else if (sql is { Number: 547 })
        {
            ctx.Response.StatusCode = 409;
            await ctx.Response.WriteAsJsonAsync(new { mensaje = "La operación viola una regla de integridad (dato fuera de rango o registro relacionado)." });
        }
        else
        {
            app.Logger.LogError(ex, "Error no controlado en {Metodo} {Ruta}", ctx.Request.Method, ctx.Request.Path);
            ctx.Response.StatusCode = 500;
            await ctx.Response.WriteAsJsonAsync(new { mensaje = "Ocurrió un error interno. Intentá de nuevo." });
        }
    }
});

app.UseResponseCompression();

// 6. Servir el frontend de Vue (archivos estáticos de wwwroot)
app.UseDefaultFiles();   // sirve index.html en la raíz "/"
app.UseStaticFiles();    // sirve los assets (js, css) de wwwroot

app.UseCors(corsPolicyName);
app.UseRateLimiter();
app.UseAuthentication();
app.UseAuthorization();
app.UseOutputCache();
app.MapControllers();

// 7. Cualquier ruta que no sea /api ni un archivo la maneja Vue (SPA)
app.MapFallbackToFile("index.html").AllowAnonymous();

app.Run();
