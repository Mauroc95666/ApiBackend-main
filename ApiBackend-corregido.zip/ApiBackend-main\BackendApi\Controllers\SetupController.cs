using BackendApi.Models;
using BackendApi.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace BackendApi.Controllers;

public class PrimerAdminDto
{
    public string Nombre { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string Password { get; set; } = string.Empty;
}

// Req. 6: creación del primer administrador con el super-usuario oculto.
// Solo accesible con el token "SetupRoot" y solo mientras no exista ningún administrador.
[ApiController]
[Route("api/setup")]
[Authorize(Policy = "SetupRoot")]
public class SetupController : ControllerBase
{
    private readonly ApplicationDbContext _context;
    private readonly AuditoriaService _auditoria;

    public SetupController(ApplicationDbContext context, AuditoriaService auditoria)
    {
        _context = context;
        _auditoria = auditoria;
    }

    public static Task<bool> ExisteAdminAsync(ApplicationDbContext context) =>
        context.Usuarios
            .Where(u => u.Activo)
            .AnyAsync(u => u.Rol.Nombre.ToLower().Contains("admin")
                        || u.Rol.Nombre.ToLower().Contains("super")
                        || u.Rol.Nombre.ToLower().Contains("gerente"));

    [HttpPost("primer-admin")]
    public async Task<IActionResult> CrearPrimerAdmin([FromBody] PrimerAdminDto dto)
    {
        if (await ExisteAdminAsync(_context))
            return Conflict(new { mensaje = "Ya existe un administrador. Este paso ya no está disponible." });

        if (string.IsNullOrWhiteSpace(dto.Nombre) || string.IsNullOrWhiteSpace(dto.Email) || !dto.Email.Contains('@'))
            return BadRequest(new { mensaje = "Nombre y un correo válido son requeridos." });
        var motivo = PasswordService.ValidarFortaleza(dto.Password);
        if (motivo != null) return BadRequest(new { mensaje = motivo });

        var email = dto.Email.Trim();
        if (await _context.Usuarios.AnyAsync(u => u.Email.ToLower() == email.ToLower()))
            return Conflict(new { mensaje = "Ese correo ya está registrado." });

        var emprendimientoId = await _context.Emprendimientos.OrderBy(e => e.Id).Select(e => e.Id).FirstOrDefaultAsync();
        if (emprendimientoId == 0)
            return BadRequest(new { mensaje = "No hay ningún emprendimiento cargado en la base." });

        var rol = await _context.Roles.FirstOrDefaultAsync(r => r.Nombre == "Administrador");
        if (rol == null)
        {
            rol = new Rol { Nombre = "Administrador", Descripcion = "Gestiona usuarios, roles, reportes y configuración." };
            _context.Roles.Add(rol);
            await _context.SaveChangesAsync();
        }

        var admin = new Usuario
        {
            EmprendimientoId = emprendimientoId,
            RolId = rol.Id,
            Nombre = dto.Nombre.Trim(),
            Email = email,
            PasswordHash = PasswordService.Hashear(dto.Password),
            Activo = true,
        };
        _context.Usuarios.Add(admin);
        await _context.SaveChangesAsync();
        await _auditoria.RegistrarAsync("CREAR_PRIMER_ADMIN", "Usuario", $"Administrador {admin.Email} (id {admin.Id})");

        return Created($"api/usuarios/{admin.Id}", new { mensaje = "Administrador creado. Ya podés iniciar sesión con esa cuenta.", admin.Id, admin.Email });
    }
}
