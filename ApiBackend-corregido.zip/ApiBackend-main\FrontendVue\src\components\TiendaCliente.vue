<script setup>
import { ref, computed, watch, onMounted, onBeforeUnmount } from 'vue';
import api from '@/api/axios';
import { store, rolEsStaff } from '@/store';
import { bs, mensajeError } from '@/utils/format';
import AppIcon from '@/ui/AppIcon.vue';
import Campo from '@/ui/Campo.vue';
import ImagenProducto from '@/ui/ImagenProducto.vue';

const productos = ref([]);
const categorias = ref([]);
const sucursales = ref([]);
const metodos = ref([]);
const resumenResenas = ref({}); // productoId -> { promedio, cantidad }
const cargando = ref(true);
const errorCarga = ref('');

const busqueda = ref('');
const categoriaSel = ref(0);

// ----- Carrito (se conserva si el cliente recarga la página) -----
const CLAVE_CARRITO = 'kiataque_carrito';
function leerCarrito() {
  try {
    const c = JSON.parse(sessionStorage.getItem(CLAVE_CARRITO));
    return Array.isArray(c) ? c : [];
  } catch {
    return [];
  }
}
const carrito = ref(leerCarrito());
watch(carrito, (c) => { try { sessionStorage.setItem(CLAVE_CARRITO, JSON.stringify(c)); } catch { /* sin almacenamiento */ } }, { deep: true });

const cajon = ref(false);
const paso = ref('carrito'); // carrito | datos | listo
const enviando = ref(false);
const pedidoListo = ref(null);
const errorEnvio = ref('');

const datos = ref({ nombre: '', telefono: '', email: '', direccion: '', sucursalId: null, modalidad: 'RETIRO', metodoPagoId: null, acepta: false });
const errores = ref({});

async function cargarTodo() {
  cargando.value = true;
  errorCarga.value = '';
  try {
    const [p, c, s, m, r] = await Promise.all([
      api.get('/productos'),
      api.get('/categorias').catch(() => ({ data: [] })),
      api.get('/sucursales').catch(() => ({ data: [] })),
      api.get('/metodospago').catch(() => ({ data: [] })),
      api.get('/resenas/resumen').catch(() => ({ data: [] })),
    ]);
    productos.value = p.data || [];
    categorias.value = c.data || [];
    sucursales.value = s.data || [];
    metodos.value = m.data || [];
    resumenResenas.value = Object.fromEntries((r.data || []).map((x) => [x.productoId, x]));
    datos.value.sucursalId = sucursales.value[0]?.id ?? null;
    datos.value.metodoPagoId = metodos.value[0]?.id ?? null;
    // Se descartan del carrito productos que ya no existen o cambiaron de precio.
    carrito.value = carrito.value
      .map((i) => {
        const p = productos.value.find((x) => x.id === i.id);
        return p ? { ...i, nombre: p.nombre, precio: Number(p.precio), imagenUrl: p.imagenUrl } : null;
      })
      .filter(Boolean);
  } catch (e) {
    errorCarga.value = mensajeError(e, 'No pudimos cargar los productos.');
  } finally {
    cargando.value = false;
  }
}

const nombreCategoria = (id) => categorias.value.find((c) => c.id === id)?.nombre || 'General';
const filtrados = computed(() => {
  const t = busqueda.value.trim().toLowerCase();
  return productos.value.filter((p) => (categoriaSel.value === 0 || p.categoriaId === categoriaSel.value) && (!t || (p.nombre || '').toLowerCase().includes(t)));
});
const categoriasConProductos = computed(() => categorias.value.filter((c) => productos.value.some((p) => p.categoriaId === c.id)));

const cantidadDe = (p) => carrito.value.find((i) => i.id === p.id)?.cantidad || 0;
function agregar(p) {
  const item = carrito.value.find((i) => i.id === p.id);
  if (item) item.cantidad = Math.min(99, item.cantidad + 1);
  else carrito.value.push({ id: p.id, nombre: p.nombre, precio: Number(p.precio) || 0, cantidad: 1, imagenUrl: p.imagenUrl });
}
function cambiar(item, delta) {
  item.cantidad = Math.min(99, item.cantidad + delta);
  if (item.cantidad <= 0) carrito.value = carrito.value.filter((i) => i !== item);
}
const total = computed(() => carrito.value.reduce((s, i) => s + i.precio * i.cantidad, 0));
const unidades = computed(() => carrito.value.reduce((s, i) => s + i.cantidad, 0));

function abrirCarrito() {
  cajon.value = true;
  if (paso.value === 'listo') paso.value = 'carrito';
  document.body.style.overflow = 'hidden';
}
function cerrarCarrito() {
  cajon.value = false;
  document.body.style.overflow = '';
}
function irADatos() {
  if (!carrito.value.length) return;
  // Solo se pre-llena para clientes con sesión; el personal que carga un pedido escribe el nombre del cliente.
  if (store.usuario && !store.esAdmin && !rolEsStaff(store.rolNombre) && !datos.value.nombre) datos.value.nombre = store.usuario.nombre || '';
  paso.value = 'datos';
}

const sucursalElegida = computed(() => sucursales.value.find((s) => s.id === datos.value.sucursalId));
const metodoElegido = computed(() => metodos.value.find((m) => m.id === datos.value.metodoPagoId));

function validar() {
  const d = datos.value;
  const e = {};
  if (!d.nombre.trim()) e.nombre = 'Escribí tu nombre.';
  if (d.telefono.trim() && d.telefono.replace(/\D/g, '').length < 7) e.telefono = 'Revisá el teléfono.';
  if (d.email.trim() && !/^\S+@\S+\.\S+$/.test(d.email.trim())) e.email = 'Revisá el correo.';
  if (d.modalidad === 'DELIVERY' && !d.direccion.trim()) e.direccion = 'Escribí la dirección donde te lo llevamos.';
  if (!d.sucursalId) e.sucursalId = 'Elegí una sucursal.';
  if (!d.metodoPagoId) e.metodoPagoId = 'Elegí cómo vas a pagar.';
  if (!d.acepta) e.acepta = 'Tenés que aceptar el tratamiento de tus datos para registrar el pedido.';
  errores.value = e;
  return !Object.keys(e).length;
}

async function confirmarPedido() {
  errorEnvio.value = '';
  if (!validar()) return;
  const d = datos.value;
  enviando.value = true;
  try {
    // 1) Cliente, guardado con el consentimiento del titular (Ley 164).
    const { data: cliente } = await api.post('/clientes', {
      emprendimientoId: sucursalElegida.value?.emprendimientoId ?? 1,
      nombre: d.nombre.trim(),
      telefono: d.telefono.trim() || null,
      email: d.email.trim() || null,
      direccion: d.direccion.trim() || null,
      consentimientoFecha: new Date().toISOString(),
    });
    // 2) Venta + pedido en una sola operación; el servidor calcula precios y total.
    const { data: venta } = await api.post('/ventas', {
      sucursalId: Number(d.sucursalId),
      clienteId: Number(cliente.id),
      metodoPagoId: Number(d.metodoPagoId),
      modalidad: d.modalidad,
      direccionEntrega: d.modalidad === 'DELIVERY' ? d.direccion.trim() : null,
      detalles: carrito.value.map((i) => ({ productoId: i.id, cantidad: i.cantidad })),
    });
    pedidoListo.value = {
      numero: venta.pedidoId ?? venta.id,
      total: venta.total,
      modalidad: d.modalidad,
      sucursal: sucursalElegida.value?.nombre,
      direccion: d.direccion.trim(),
      pago: metodoElegido.value?.nombre,
      nombre: d.nombre.trim(),
    };
    carrito.value = [];
    paso.value = 'listo';
  } catch (e) {
    errorEnvio.value = mensajeError(e, 'No pudimos registrar tu pedido. Intentá de nuevo.');
  } finally {
    enviando.value = false;
  }
}

function nuevoPedido() {
  pedidoListo.value = null;
  datos.value.acepta = false;
  paso.value = 'carrito';
  cerrarCarrito();
}

function alTeclear(e) {
  if (e.key === 'Escape' && cajon.value) cerrarCarrito();
}
onMounted(() => {
  cargarTodo();
  document.addEventListener('keydown', alTeclear);
});
onBeforeUnmount(() => {
  document.removeEventListener('keydown', alTeclear);
  document.body.style.overflow = '';
});

function salir() {
  location.hash = '';
  store.cerrarSesion();
}
</script>

<template>
  <div class="tienda">
    <header class="cab">
      <div class="cab-in">
        <a href="#/tienda" class="marca" aria-label="Panadería Kiataque, inicio" @click.prevent="categoriaSel = 0; busqueda = ''">
          <span class="marca-logo"><AppIcon name="loaf" :size="22" /></span>
          <strong>Kiataque</strong>
        </a>
        <div class="entrada-icono buscar">
          <AppIcon name="search" :size="17" class="icono-izq" />
          <input v-model="busqueda" type="search" placeholder="Buscar pan, empanadas, bebidas..." aria-label="Buscar productos" />
        </div>
        <nav class="cab-acc">
          <button v-if="store.usuario && (store.esAdmin || rolEsStaff(store.rolNombre))" type="button" class="btn btn-fantasma btn-sm oculto-movil" @click="store.pantalla = 'panel'">Volver al panel</button>
          <button type="button" class="btn btn-fantasma btn-sm oculto-movil" @click="salir">{{ store.usuario ? 'Cerrar sesión' : 'Soy del personal' }}</button>
          <button type="button" class="btn btn-primario carrito-btn" :aria-label="`Abrir el carrito, ${unidades} productos`" @click="abrirCarrito">
            <AppIcon name="cart" :size="19" /> <span class="oculto-movil">Mi pedido</span>
            <span v-if="unidades" class="cuenta">{{ unidades }}</span>
          </button>
        </nav>
      </div>
    </header>

    <section class="portada">
      <div class="portada-in">
        <p class="pre">Horneado cada día</p>
        <h1>Pan fresco, directo a tu mesa</h1>
        <p class="sub">Elegí lo que querés y retiralo en la panadería o pedí que te lo llevemos.</p>
      </div>
    </section>

    <main class="contenido">
      <div v-if="categoriasConProductos.length" class="chips" role="group" aria-label="Categorías">
        <button type="button" class="chip" :class="{ activo: categoriaSel === 0 }" @click="categoriaSel = 0">Todo</button>
        <button v-for="c in categoriasConProductos" :key="c.id" type="button" class="chip" :class="{ activo: categoriaSel === c.id }" @click="categoriaSel = c.id">{{ c.nombre }}</button>
      </div>

      <div v-if="errorCarga" class="aviso-linea error" role="alert" style="margin-top: 20px">
        <AppIcon name="alert" :size="18" /> <span class="crece">{{ errorCarga }}</span>
        <button type="button" class="btn btn-secundario btn-sm" @click="cargarTodo">Reintentar</button>
      </div>

      <div v-if="cargando" class="grilla"><div v-for="n in 8" :key="n" class="tarjeta"><span class="esqueleto" style="height: 170px"></span><div class="tarjeta-cuerpo pila-sm"><span class="esqueleto"></span><span class="esqueleto" style="width: 40%"></span></div></div></div>

      <div v-else-if="!filtrados.length && !errorCarga" class="vacio">
        <div class="vacio-icono"><AppIcon name="search" :size="26" /></div>
        <h3>{{ productos.length ? 'No encontramos ese producto' : 'Pronto vamos a cargar el catálogo' }}</h3>
        <p>{{ productos.length ? 'Probá con otra palabra o categoría.' : 'Todavía no hay productos disponibles.' }}</p>
        <button v-if="productos.length" type="button" class="btn btn-secundario" @click="busqueda = ''; categoriaSel = 0">Ver todo</button>
      </div>

      <div v-else class="grilla">
        <article v-for="p in filtrados" :key="p.id" class="tarjeta prod">
          <div class="prod-foto"><ImagenProducto :url="p.imagenUrl" :nombre="p.nombre" /></div>
          <div class="prod-datos">
            <span class="texto-chico texto-tenue">{{ nombreCategoria(p.categoriaId) }}</span>
            <h3>{{ p.nombre }}</h3>
            <div v-if="resumenResenas[p.id]" class="estrellas" :aria-label="`Calificación ${resumenResenas[p.id].promedio} de 5`">
              <AppIcon name="star" :size="14" /> <strong>{{ resumenResenas[p.id].promedio }}</strong> <span class="texto-tenue">({{ resumenResenas[p.id].cantidad }})</span>
            </div>
            <div class="fila entre" style="margin-top: auto">
              <strong class="precio numeros">{{ bs(p.precio) }}</strong>
              <div v-if="cantidadDe(p)" class="paso" role="group" :aria-label="`Cantidad de ${p.nombre}`">
                <button type="button" class="btn btn-secundario btn-icono btn-sm" aria-label="Quitar uno" @click="cambiar(carrito.find((i) => i.id === p.id), -1)"><AppIcon name="minus" :size="14" /></button>
                <span class="numeros negrita">{{ cantidadDe(p) }}</span>
                <button type="button" class="btn btn-primario btn-icono btn-sm" aria-label="Agregar otro" @click="agregar(p)"><AppIcon name="plus" :size="14" /></button>
              </div>
              <button v-else type="button" class="btn btn-primario btn-sm" @click="agregar(p)"><AppIcon name="plus" :size="15" /> Agregar</button>
            </div>
          </div>
        </article>
      </div>
    </main>

    <footer class="pie">
      <div class="pie-in">
        <strong>Panadería Kiataque</strong>
        <span v-for="s in sucursales" :key="s.id" class="texto-suave"><AppIcon name="pin" :size="14" /> {{ s.nombre }} · {{ s.direccion }}<template v-if="s.telefono"> · {{ s.telefono }}</template></span>
      </div>
    </footer>

    <!-- Barra de pedido (móvil) -->
    <button v-if="unidades && !cajon" type="button" class="barra-movil" @click="abrirCarrito">
      <span><AppIcon name="cart" :size="18" /> Ver mi pedido ({{ unidades }})</span><strong class="numeros">{{ bs(total) }}</strong>
    </button>

    <!-- Cajón del pedido -->
    <div v-if="cajon" class="velo" @click="cerrarCarrito"></div>
    <aside v-if="cajon" class="cajon" role="dialog" aria-modal="true" aria-label="Tu pedido">
      <header class="cajon-cab">
        <button v-if="paso === 'datos'" type="button" class="btn btn-fantasma btn-icono" aria-label="Volver al carrito" @click="paso = 'carrito'"><AppIcon name="chevronLeft" :size="20" /></button>
        <h2>{{ paso === 'carrito' ? 'Tu pedido' : paso === 'datos' ? 'Tus datos' : '¡Pedido recibido!' }}</h2>
        <button type="button" class="btn btn-fantasma btn-icono" aria-label="Cerrar" @click="cerrarCarrito"><AppIcon name="x" :size="20" /></button>
      </header>

      <!-- Paso 1: carrito -->
      <template v-if="paso === 'carrito'">
        <div class="cajon-cuerpo">
          <div v-if="!carrito.length" class="vacio">
            <div class="vacio-icono"><AppIcon name="cart" :size="26" /></div>
            <h3>Tu pedido está vacío</h3>
            <p>Agregá productos desde el catálogo.</p>
            <button type="button" class="btn btn-secundario" @click="cerrarCarrito">Ver productos</button>
          </div>
          <ul v-else class="items">
            <li v-for="i in carrito" :key="i.id">
              <div class="item-foto"><ImagenProducto :url="i.imagenUrl" :nombre="i.nombre" /></div>
              <div class="crece">
                <div class="negrita">{{ i.nombre }}</div>
                <div class="texto-chico texto-suave numeros">{{ bs(i.precio) }} c/u</div>
                <div class="paso" style="margin-top: 6px">
                  <button type="button" class="btn btn-secundario btn-icono btn-sm" :aria-label="`Quitar uno de ${i.nombre}`" @click="cambiar(i, -1)"><AppIcon name="minus" :size="14" /></button>
                  <span class="numeros negrita">{{ i.cantidad }}</span>
                  <button type="button" class="btn btn-secundario btn-icono btn-sm" :aria-label="`Agregar uno de ${i.nombre}`" @click="cambiar(i, 1)"><AppIcon name="plus" :size="14" /></button>
                </div>
              </div>
              <strong class="numeros">{{ bs(i.precio * i.cantidad) }}</strong>
            </li>
          </ul>
        </div>
        <footer v-if="carrito.length" class="cajon-pie">
          <div class="fila entre"><span class="texto-suave">Total</span><strong class="total numeros">{{ bs(total) }}</strong></div>
          <button type="button" class="btn btn-primario btn-lg btn-bloque" @click="irADatos">Continuar <AppIcon name="arrowRight" :size="18" /></button>
        </footer>
      </template>

      <!-- Paso 2: datos -->
      <template v-else-if="paso === 'datos'">
        <form id="form-pedido" class="cajon-cuerpo formulario" novalidate @submit.prevent="confirmarPedido">
          <div v-if="errorEnvio" class="aviso-linea error" role="alert"><AppIcon name="alert" :size="18" /> <span>{{ errorEnvio }}</span></div>

          <fieldset class="modalidad">
            <legend class="etiqueta-campo">¿Cómo lo querés?</legend>
            <label class="opcion" :class="{ activa: datos.modalidad === 'RETIRO' }">
              <input v-model="datos.modalidad" type="radio" value="RETIRO" class="solo-lectores" />
              <AppIcon name="store" :size="22" /> <strong>Retiro en local</strong><span class="texto-chico texto-suave">Pasás a buscarlo</span>
            </label>
            <label class="opcion" :class="{ activa: datos.modalidad === 'DELIVERY' }">
              <input v-model="datos.modalidad" type="radio" value="DELIVERY" class="solo-lectores" />
              <AppIcon name="truck" :size="22" /> <strong>Delivery</strong><span class="texto-chico texto-suave">Te lo llevamos</span>
            </label>
          </fieldset>

          <Campo label="Sucursal" requerido :error="errores.sucursalId" v-slot="{ id }">
            <select :id="id" v-model="datos.sucursalId">
              <option v-for="s in sucursales" :key="s.id" :value="s.id">{{ s.nombre }}</option>
            </select>
            <span v-if="sucursalElegida" class="ayuda"><AppIcon name="pin" :size="12" /> {{ sucursalElegida.direccion }}</span>
          </Campo>
          <Campo label="Tu nombre" requerido :error="errores.nombre" v-slot="{ id, invalido }"><input :id="id" v-model="datos.nombre" autocomplete="name" maxlength="120" :aria-invalid="invalido" /></Campo>
          <Campo label="Teléfono" :error="errores.telefono" ayuda="Para avisarte cuando esté listo." v-slot="{ id, invalido }"><input :id="id" v-model="datos.telefono" type="tel" autocomplete="tel" inputmode="tel" maxlength="30" :aria-invalid="invalido" /></Campo>
          <Campo label="Correo (opcional)" :error="errores.email" v-slot="{ id, invalido }"><input :id="id" v-model="datos.email" type="email" autocomplete="email" maxlength="150" :aria-invalid="invalido" /></Campo>
          <Campo v-if="datos.modalidad === 'DELIVERY'" label="Dirección de entrega" requerido :error="errores.direccion" v-slot="{ id, invalido }">
            <input :id="id" v-model="datos.direccion" autocomplete="street-address" maxlength="300" placeholder="Calle, número, zona y referencia" :aria-invalid="invalido" />
          </Campo>
          <Campo label="Forma de pago" requerido :error="errores.metodoPagoId" v-slot="{ id }">
            <select :id="id" v-model="datos.metodoPagoId"><option v-for="m in metodos" :key="m.id" :value="m.id">{{ m.nombre }}</option></select>
            <span class="ayuda">El pago se hace al {{ datos.modalidad === 'DELIVERY' ? 'recibir el pedido' : 'retirarlo' }}.</span>
          </Campo>

          <div>
            <label class="opcion-check">
              <input v-model="datos.acepta" type="checkbox" :aria-invalid="!!errores.acepta" />
              <span>Acepto que la panadería guarde mis datos personales (nombre, contacto y dirección) solo para gestionar mi pedido. Puedo pedir que los consulten o los borren cuando quiera.</span>
            </label>
            <span v-if="errores.acepta" class="error-campo" role="alert">{{ errores.acepta }}</span>
          </div>
        </form>
        <footer class="cajon-pie">
          <div class="fila entre"><span class="texto-suave">{{ unidades }} {{ unidades === 1 ? 'producto' : 'productos' }}</span><strong class="total numeros">{{ bs(total) }}</strong></div>
          <button type="submit" form="form-pedido" class="btn btn-primario btn-lg btn-bloque" :disabled="enviando">
            <AppIcon v-if="enviando" name="refresh" :size="18" class="girando" /> {{ enviando ? 'Enviando pedido...' : 'Confirmar pedido' }}
          </button>
        </footer>
      </template>

      <!-- Paso 3: listo -->
      <div v-else class="cajon-cuerpo listo">
        <div class="listo-icono"><AppIcon name="check" :size="34" /></div>
        <h3>Gracias, {{ pedidoListo.nombre.split(' ')[0] }}</h3>
        <p class="texto-suave">Recibimos tu pedido <strong>#{{ pedidoListo.numero }}</strong>. Guardá este número por si necesitás consultarlo.</p>
        <dl class="resumen">
          <dt>Total a pagar</dt><dd class="numeros">{{ bs(pedidoListo.total) }} <span class="texto-tenue">({{ pedidoListo.pago }})</span></dd>
          <dt>{{ pedidoListo.modalidad === 'DELIVERY' ? 'Entrega en' : 'Retiro en' }}</dt>
          <dd>{{ pedidoListo.modalidad === 'DELIVERY' ? pedidoListo.direccion : pedidoListo.sucursal }}</dd>
        </dl>
        <button type="button" class="btn btn-primario btn-lg btn-bloque" @click="nuevoPedido">Seguir comprando</button>
      </div>
    </aside>
  </div>
</template>

<style scoped>
.tienda { min-height: 100vh; display: flex; flex-direction: column; background: var(--fondo); }

.cab { position: sticky; top: 0; z-index: 40; background: rgba(255, 255, 255, 0.92); backdrop-filter: blur(10px); border-bottom: 1px solid var(--borde); }
.cab-in { max-width: 1180px; margin: 0 auto; padding: 12px 20px; display: flex; align-items: center; gap: 18px; }
.marca { display: flex; align-items: center; gap: 10px; color: var(--texto); font-size: 18px; text-decoration: none; }
.marca:hover { text-decoration: none; }
.marca-logo { width: 38px; height: 38px; border-radius: 11px; background: var(--marca); color: #fff; display: grid; place-items: center; }
.buscar { flex: 1; max-width: 460px; }
.cab-acc { margin-left: auto; display: flex; align-items: center; gap: 8px; }
.carrito-btn { position: relative; }
.cuenta { background: #fff; color: var(--marca); border-radius: 10px; min-width: 22px; height: 22px; padding: 0 6px; display: grid; place-items: center; font-size: 12px; font-weight: 800; }

.portada { background: radial-gradient(circle at 15% 20%, rgba(217, 138, 43, 0.3), transparent 50%), var(--espresso); color: #f6ead9; }
.portada-in { max-width: 1180px; margin: 0 auto; padding: 44px 20px 48px; }
.portada .pre { font-size: 13px; letter-spacing: 0.14em; text-transform: uppercase; color: #e9a64a; font-weight: 700; }
.portada h1 { color: #fff; font-size: clamp(26px, 4.5vw, 40px); margin: 8px 0; max-width: 620px; }
.portada .sub { color: #dcc8ad; max-width: 520px; }

.contenido { max-width: 1180px; margin: 0 auto; padding: 26px 20px 60px; width: 100%; flex: 1; }
.grilla { display: grid; grid-template-columns: repeat(auto-fill, minmax(230px, 1fr)); gap: 20px; margin-top: 22px; }
.prod { overflow: hidden; display: flex; flex-direction: column; transition: box-shadow 0.15s, transform 0.15s; }
.prod:hover { box-shadow: var(--sombra-2); transform: translateY(-2px); }
.prod-foto { aspect-ratio: 4 / 3; background: var(--superficie-2); font-size: 3rem; }
.prod-datos { padding: 14px 16px 16px; display: flex; flex-direction: column; gap: 4px; flex: 1; }
.prod-datos h3 { font-size: 16px; }
.precio { font-size: 18px; color: var(--marca); }
.estrellas { display: flex; align-items: center; gap: 4px; font-size: 13px; color: #b9791a; }
.estrellas svg { fill: currentColor; }
.paso { display: flex; align-items: center; gap: 8px; }
.paso span { min-width: 20px; text-align: center; }

.pie { background: var(--espresso); color: #dcc8ad; margin-top: auto; }
.pie-in { max-width: 1180px; margin: 0 auto; padding: 26px 20px; display: grid; gap: 6px; font-size: 14px; }
.pie-in strong { color: #fff; }
.pie-in .texto-suave { color: #c9b69b; display: flex; gap: 6px; align-items: center; }

.barra-movil {
  display: none; position: fixed; left: 12px; right: 12px; bottom: 12px; z-index: 45; padding: 14px 18px;
  background: var(--marca); color: #fff; border: none; border-radius: 14px; box-shadow: var(--sombra-3);
  justify-content: space-between; align-items: center; font: inherit; font-weight: 600; cursor: pointer;
}
.barra-movil span { display: flex; gap: 8px; align-items: center; }

.velo { position: fixed; inset: 0; background: rgba(34, 20, 12, 0.5); z-index: 90; }
.cajon { position: fixed; top: 0; right: 0; bottom: 0; width: min(440px, 100vw); z-index: 100; background: var(--superficie); display: flex; flex-direction: column; box-shadow: var(--sombra-3); animation: entra 0.2s ease-out; }
@keyframes entra { from { transform: translateX(40px); opacity: 0; } to { transform: none; opacity: 1; } }
.cajon-cab { display: flex; align-items: center; gap: 8px; padding: 14px 16px; border-bottom: 1px solid var(--borde); }
.cajon-cab h2 { flex: 1; font-size: 18px; }
.cajon-cuerpo { flex: 1; overflow-y: auto; padding: 18px 20px; }
.cajon-pie { padding: 16px 20px 20px; border-top: 1px solid var(--borde); display: grid; gap: 12px; background: var(--superficie-2); }
.total { font-size: 24px; }

.items { list-style: none; margin: 0; padding: 0; display: grid; gap: 18px; }
.items li { display: grid; grid-template-columns: 56px 1fr auto; gap: 12px; align-items: start; }
.item-foto { width: 56px; height: 56px; border-radius: 10px; overflow: hidden; font-size: 1.3rem; }

.modalidad { border: none; padding: 0; margin: 0; display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
.modalidad legend { margin-bottom: 8px; padding: 0; }
.opcion { display: grid; gap: 2px; justify-items: start; padding: 12px; border: 1.5px solid var(--borde-fuerte); border-radius: var(--r-md); cursor: pointer; background: var(--superficie); }
.opcion:hover { border-color: var(--marca); }
.opcion.activa { border-color: var(--marca); background: var(--marca-suave); box-shadow: 0 0 0 1px var(--marca); }
.opcion:has(input:focus-visible) { box-shadow: var(--foco); }

.listo { text-align: center; display: grid; gap: 14px; align-content: start; padding-top: 40px; }
.listo-icono { width: 72px; height: 72px; border-radius: 50%; background: var(--ok-suave); color: var(--ok); display: grid; place-items: center; margin: 0 auto; }
.resumen { display: grid; grid-template-columns: max-content 1fr; gap: 8px 16px; text-align: left; background: var(--superficie-2); border-radius: var(--r-md); padding: 16px; margin: 6px 0 10px; }
.resumen dt { color: var(--texto-3); font-size: 13px; }
.resumen dd { margin: 0; font-weight: 700; }

@media (max-width: 720px) {
  .cab-in { padding: 10px 14px; gap: 10px; }
  .buscar { max-width: none; }
  .marca strong { display: none; }
  .portada-in { padding: 30px 16px 34px; }
  .contenido { padding: 20px 14px 90px; }
  .grilla { grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 12px; }
  .prod-datos { padding: 10px 12px 12px; }
  .prod-datos .fila { flex-wrap: wrap; gap: 8px; }
  .barra-movil { display: flex; }
  .carrito-btn { display: none; }
}
</style>
