using System.Collections.Concurrent;

namespace BackendApi.Services;

// Req. 7: mide el tiempo de respuesta por ruta y calcula p50/p95/p99 con las últimas 1000 muestras.
public class MetricasService
{
    private const int Muestras = 1000;
    private readonly ConcurrentDictionary<string, Cola> _rutas = new();

    private sealed class Cola
    {
        public readonly double[] Datos = new double[Muestras];
        public int Posicion;
        public long Total;
        public int Errores;
        public readonly object Candado = new();
    }

    public void Registrar(string ruta, double ms, int status)
    {
        var c = _rutas.GetOrAdd(ruta, _ => new Cola());
        lock (c.Candado)
        {
            c.Datos[c.Posicion % Muestras] = ms;
            c.Posicion++;
            c.Total++;
            if (status >= 500) c.Errores++;
        }
    }

    static double Percentil(double[] ordenado, double p) =>
        ordenado.Length == 0 ? 0 : ordenado[Math.Min(ordenado.Length - 1, (int)Math.Ceiling(p * ordenado.Length) - 1)];

    public object Resumen()
    {
        var filas = _rutas.Select(kv =>
        {
            double[] copia;
            long total; int errores;
            lock (kv.Value.Candado)
            {
                var n = Math.Min(kv.Value.Posicion, Muestras);
                copia = kv.Value.Datos.Take(n).OrderBy(x => x).ToArray();
                total = kv.Value.Total;
                errores = kv.Value.Errores;
            }
            return new
            {
                ruta = kv.Key,
                solicitudes = total,
                errores5xx = errores,
                promedioMs = copia.Length == 0 ? 0 : Math.Round(copia.Average(), 1),
                p50Ms = Math.Round(Percentil(copia, 0.50), 1),
                p95Ms = Math.Round(Percentil(copia, 0.95), 1),
                p99Ms = Math.Round(Percentil(copia, 0.99), 1),
                maxMs = copia.Length == 0 ? 0 : Math.Round(copia.Max(), 1),
            };
        }).OrderByDescending(x => x.solicitudes).ToList();

        double Max95(Func<string, bool> filtro) =>
            filas.Where(f => filtro(f.ruta)).Select(f => f.p95Ms).DefaultIfEmpty(0).Max();

        // Metas del documento de requisitos.
        var catalogoMax = Max95(r => r.StartsWith("GET /api/productos", StringComparison.OrdinalIgnoreCase));
        var ventaMax = Max95(r => r.StartsWith("POST /api/ventas", StringComparison.OrdinalIgnoreCase));
        // El respaldo es una tarea de mantenimiento (segundos por diseño), no una llamada de uso normal.
        var p95Global = filas.Where(f => !f.ruta.Contains("/api/respaldos", StringComparison.OrdinalIgnoreCase))
            .Select(f => f.p95Ms).DefaultIfEmpty(0).Max();

        return new
        {
            metas = new
            {
                catalogoMenorA2s = new { objetivoMs = 2000, p95Ms = catalogoMax, cumple = catalogoMax < 2000 },
                ventaMenorA3s = new { objetivoMs = 3000, p95Ms = ventaMax, cumple = ventaMax < 3000 },
                apiP95MenorA500ms = new { objetivoMs = 500, p95Ms = p95Global, cumple = p95Global < 500 },
            },
            rutas = filas,
        };
    }
}
