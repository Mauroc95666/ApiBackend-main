using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using Microsoft.IdentityModel.Tokens;

namespace BackendApi.Services;

public class TokenService
{
    public const string Emisor = "kiataque-api";
    public const string Audiencia = "kiataque-app";

    private readonly SymmetricSecurityKey _clave;

    public TokenService(SymmetricSecurityKey clave) => _clave = clave;

    public string Crear(IEnumerable<Claim> claims, TimeSpan duracion)
    {
        var token = new JwtSecurityToken(
            issuer: Emisor,
            audience: Audiencia,
            claims: claims.Append(new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString("N"))),
            expires: DateTime.UtcNow.Add(duracion),
            signingCredentials: new SigningCredentials(_clave, SecurityAlgorithms.HmacSha256));
        return new JwtSecurityTokenHandler().WriteToken(token);
    }
}
