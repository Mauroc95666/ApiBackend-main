<script setup>
// Se monta una sola vez en App.vue: dibuja los avisos flotantes y el diálogo de confirmación.
import { toasts, quitarToast, dialogo, responderDialogo } from './feedback';
import AppModal from './AppModal.vue';
import AppIcon from './AppIcon.vue';

const iconos = { ok: 'checkCircle', error: 'alert', aviso: 'alert', info: 'info' };
</script>

<template>
  <div class="toasts" aria-live="polite" aria-atomic="false">
    <div v-for="t in toasts" :key="t.id" class="toast" :class="t.tipo" role="status">
      <AppIcon :name="iconos[t.tipo] || 'info'" :size="18" />
      <span class="toast-texto">{{ t.mensaje }}</span>
      <button type="button" aria-label="Cerrar aviso" @click="quitarToast(t.id)"><AppIcon name="x" :size="16" /></button>
    </div>
  </div>

  <AppModal :model-value="dialogo.abierto" :titulo="dialogo.titulo" tamano="sm" @cerrar="responderDialogo(false)">
    <p v-if="dialogo.mensaje" class="texto-suave">{{ dialogo.mensaje }}</p>
    <template #pie>
      <button type="button" class="btn btn-secundario" @click="responderDialogo(false)">{{ dialogo.textoCancelar }}</button>
      <button
        type="button"
        class="btn"
        :class="dialogo.peligro ? 'btn-peligro-solido' : 'btn-primario'"
        @click="responderDialogo(true)"
      >
        {{ dialogo.textoOk }}
      </button>
    </template>
  </AppModal>
</template>
