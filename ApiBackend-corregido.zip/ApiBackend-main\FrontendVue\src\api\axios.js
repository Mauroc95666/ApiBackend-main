import axios from 'axios';

// Instancia de axios que apunta a la API .NET.
// - En desarrollo local (npm run dev) usa http://localhost:5208/api.
// - En Docker se compila con VITE_API_URL=/api y nginx redirige /api al backend.
const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || 'http://localhost:5208/api',
  headers: { 'Content-Type': 'application/json' },
  timeout: 20000,
});

// El token (JWT) vive en sessionStorage: se borra al cerrar la pestaña.
const CLAVE_TOKEN = 'kiataque_token';

export function guardarToken(token) {
  try {
    if (token) sessionStorage.setItem(CLAVE_TOKEN, token);
    else sessionStorage.removeItem(CLAVE_TOKEN);
  } catch {
    // sessionStorage no disponible: la sesión dura solo mientras no se recargue.
  }
}

export function leerToken() {
  try {
    return sessionStorage.getItem(CLAVE_TOKEN);
  } catch {
    return null;
  }
}

// Lee el vencimiento (en ms) del JWT sin validar la firma; sirve solo para no restaurar sesiones vencidas.
export function vencimientoToken(token) {
  try {
    const carga = JSON.parse(atob(token.split('.')[1].replace(/-/g, '+').replace(/_/g, '/')));
    return carga.exp ? carga.exp * 1000 : null;
  } catch {
    return null;
  }
}

// El store se registra acá para evitar una importación circular.
let alVencerSesion = null;
export function registrarAlVencerSesion(fn) {
  alVencerSesion = fn;
}

api.interceptors.request.use((config) => {
  const token = leerToken();
  if (token) config.headers.Authorization = 'Bearer ' + token;
  return config;
});

api.interceptors.response.use(
  (r) => r,
  (error) => {
    // 401 con sesión abierta = el token venció o dejó de ser válido: se vuelve al inicio de sesión.
    const esLogin = (error?.config?.url || '').includes('/auth/login');
    if (error?.response?.status === 401 && leerToken() && !esLogin && alVencerSesion) alVencerSesion();
    return Promise.reject(error);
  }
);

export default api;
