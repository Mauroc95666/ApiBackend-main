using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using BackendApi.Models;

namespace BackendApi.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize(Policy = "Admin")]
public class ReportesController : ControllerBase
{
    private readonly ApplicationDbContext _context;

    public ReportesController(ApplicationDbContext context)
    {
        _context = context;
    }

    [HttpGet]
    public async Task<IActionResult> ObtenerReportes()
    {
        var reportes = await _context.Reportes.ToListAsync();
        return Ok(reportes);
    }

    // Rango de fechas de los reportes: por defecto los últimos 30 días. "hasta" incluye el día completo.
    private static (DateTime desde, DateTime hastaExcl) Rango(DateTime? desde, DateTime? hasta) =>
        ((desde ?? DateTime.UtcNow.Date.AddDays(-30)).Date, (hasta ?? DateTime.UtcNow.Date).Date.AddDays(1));

    // Req. 4: ventas por día, sucursal y método de pago.
    [HttpGet("ventas")]
    public async Task<IActionResult> ReporteVentas([FromQuery] DateTime? desde, [FromQuery] DateTime? hasta, [FromQuery] int? sucursalId)
    {
        var (d, h) = Rango(desde, hasta);
        var q = _context.Ventas.AsNoTracking().Where(v => v.Fecha >= d && v.Fecha < h);
        if (sucursalId.HasValue) q = q.Where(v => v.SucursalId == sucursalId.Value);

        var porDia = await q.GroupBy(v => v.Fecha.Date)
            .Select(g => new { fecha = g.Key, ventas = g.Count(), total = g.Sum(v => v.Total) })
            .OrderBy(x => x.fecha).ToListAsync();
        var porSucursal = await q.GroupBy(v => new { v.SucursalId, v.Sucursal.Nombre })
            .Select(g => new { sucursalId = g.Key.SucursalId, sucursal = g.Key.Nombre, ventas = g.Count(), total = g.Sum(v => v.Total) })
            .OrderByDescending(x => x.total).ToListAsync();
        var porMetodo = await q.GroupBy(v => v.MetodoPago.Nombre)
            .Select(g => new { metodo = g.Key, ventas = g.Count(), total = g.Sum(v => v.Total) })
            .OrderByDescending(x => x.total).ToListAsync();

        var cantidad = porDia.Sum(x => x.ventas);
        var total = porDia.Sum(x => x.total);
        return Ok(new
        {
            desde = d, hasta = h.AddDays(-1),
            resumen = new { ventas = cantidad, total, ticketPromedio = cantidad == 0 ? 0 : Math.Round(total / cantidad, 2) },
            porDia, porSucursal, porMetodo,
        });
    }

    // Req. 4: productos más vendidos.
    [HttpGet("productos-top")]
    public async Task<IActionResult> ProductosTop([FromQuery] DateTime? desde, [FromQuery] DateTime? hasta, [FromQuery] int? sucursalId, [FromQuery] int limite = 10)
    {
        var (d, h) = Rango(desde, hasta);
        var q = _context.DetalleVenta.AsNoTracking().Where(x => x.Venta.Fecha >= d && x.Venta.Fecha < h);
        if (sucursalId.HasValue) q = q.Where(x => x.Venta.SucursalId == sucursalId.Value);

        var top = await q.GroupBy(x => new { x.ProductoId, x.Producto.Nombre })
            .Select(g => new { productoId = g.Key.ProductoId, producto = g.Key.Nombre, unidades = g.Sum(x => x.Cantidad), ingresos = g.Sum(x => x.Subtotal ?? 0) })
            .OrderByDescending(x => x.unidades).Take(Math.Clamp(limite, 1, 100)).ToListAsync();
        return Ok(top);
    }

    // Req. 11: tiempo de servicio de los pedidos (ingreso → entrega), por modalidad y sucursal.
    [HttpGet("tiempos-servicio")]
    public async Task<IActionResult> TiemposServicio([FromQuery] DateTime? desde, [FromQuery] DateTime? hasta, [FromQuery] int? sucursalId, [FromQuery] int metaMinutos = 30)
    {
        var (d, h) = Rango(desde, hasta);
        var q = _context.Pedidos.AsNoTracking().Where(p => p.FechaCreacion >= d && p.FechaCreacion < h);
        if (sucursalId.HasValue) q = q.Where(p => p.Venta.SucursalId == sucursalId.Value);

        var filas = await q.Select(p => new
        {
            p.Id, p.Estado, p.Modalidad, p.Venta.SucursalId, sucursal = p.Venta.Sucursal.Nombre,
            p.FechaCreacion, p.FechaPreparacion, p.FechaListo, p.FechaEntregado,
        }).ToListAsync();

        static double Min(DateTime a, DateTime b) => Math.Round((b - a).TotalMinutes, 1);
        static object Estad(IEnumerable<double> v)
        {
            var l = v.OrderBy(x => x).ToList();
            if (l.Count == 0) return new { pedidos = 0, promedioMin = 0.0, minimoMin = 0.0, maximoMin = 0.0, p90Min = 0.0 };
            return new
            {
                pedidos = l.Count,
                promedioMin = Math.Round(l.Average(), 1),
                minimoMin = l[0],
                maximoMin = l[^1],
                p90Min = l[Math.Min(l.Count - 1, (int)Math.Ceiling(0.9 * l.Count) - 1)],
            };
        }

        var entregados = filas.Where(f => f.FechaEntregado.HasValue).ToList();
        var tiempos = entregados.Select(f => Min(f.FechaCreacion, f.FechaEntregado!.Value)).ToList();
        var enCurso = filas.Where(f => f.Estado != "ENTREGADO" && f.Estado != "CANCELADO").ToList();

        return Ok(new
        {
            desde = d, hasta = h.AddDays(-1), metaMinutos,
            general = Estad(tiempos),
            cumplenMeta = tiempos.Count == 0 ? 0 : Math.Round(100.0 * tiempos.Count(t => t <= metaMinutos) / tiempos.Count, 1),
            esperaHastaPreparar = Estad(entregados.Where(f => f.FechaPreparacion.HasValue).Select(f => Min(f.FechaCreacion, f.FechaPreparacion!.Value))),
            preparacion = Estad(entregados.Where(f => f.FechaPreparacion.HasValue && f.FechaListo.HasValue).Select(f => Min(f.FechaPreparacion!.Value, f.FechaListo!.Value))),
            porModalidad = entregados.GroupBy(f => f.Modalidad).Select(g => new { modalidad = g.Key, tiempo = Estad(g.Select(f => Min(f.FechaCreacion, f.FechaEntregado!.Value))) }),
            porSucursal = entregados.GroupBy(f => new { f.SucursalId, f.sucursal }).Select(g => new { g.Key.SucursalId, g.Key.sucursal, tiempo = Estad(g.Select(f => Min(f.FechaCreacion, f.FechaEntregado!.Value))) }),
            enCurso = new
            {
                pedidos = enCurso.Count,
                esperaPromedioMin = enCurso.Count == 0 ? 0 : Math.Round(enCurso.Average(f => (DateTime.UtcNow - f.FechaCreacion).TotalMinutes), 1),
                fueraDeMeta = enCurso.Count(f => (DateTime.UtcNow - f.FechaCreacion).TotalMinutes > metaMinutos),
            },
            cancelados = filas.Count(f => f.Estado == "CANCELADO"),
        });
    }

    [HttpGet("{id}")]
    public async Task<IActionResult> ObtenerReportePorId(int id)
    {
        var reporte = await _context.Reportes.FindAsync(id);

        if (reporte == null)
            return NotFound(new { mensaje = $"Reporte con id {id} no encontrado" });

        return Ok(reporte);
    }

    [HttpPost]
    public async Task<IActionResult> CrearReporte([FromBody] Reporte nuevoReporte)
    {
        if (nuevoReporte == null)
            return BadRequest(new { mensaje = "Los datos del reporte son requeridos" });

        _context.Reportes.Add(nuevoReporte);
        await _context.SaveChangesAsync();

        return CreatedAtAction(nameof(ObtenerReportePorId), new { id = nuevoReporte.Id }, nuevoReporte);
    }

    [HttpPut("{id}")]
    public async Task<IActionResult> ActualizarReporte(int id, [FromBody] Reporte reporteActualizado)
    {
        var reporte = await _context.Reportes.FindAsync(id);

        if (reporte == null)
            return NotFound(new { mensaje = $"Reporte con id {id} no encontrado" });

        reporte.EmprendimientoId = reporteActualizado.EmprendimientoId;
        reporte.Tipo = reporteActualizado.Tipo;
        reporte.FechaGeneracion = reporteActualizado.FechaGeneracion;
        reporte.Datos = reporteActualizado.Datos;

        await _context.SaveChangesAsync();

        return Ok(new { mensaje = "Reporte actualizado correctamente", reporte });
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> EliminarReporte(int id)
    {
        var reporte = await _context.Reportes.FindAsync(id);

        if (reporte == null)
            return NotFound(new { mensaje = $"Reporte con id {id} no encontrado" });

        _context.Reportes.Remove(reporte);
        await _context.SaveChangesAsync();

        return Ok(new { mensaje = $"Reporte {id} eliminado correctamente" });
    }
}