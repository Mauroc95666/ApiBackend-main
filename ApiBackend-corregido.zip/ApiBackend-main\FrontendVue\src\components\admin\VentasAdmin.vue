<script setup>
import { ref, computed, onMounted, watch } from 'vue';
import api from '@/api/axios';
import { store } from '@/store';
import { toast } from '@/ui/feedback';
import { bs, fechaHora, hoyLocal, mensajeError } from '@/utils/format';
import AppIcon from '@/ui/AppIcon.vue';
import AppModal from '@/ui/AppModal.vue';
import Campo from '@/ui/Campo.vue';
import EncabezadoPagina from '@/ui/EncabezadoPagina.vue';
import EstadoVacio from '@/ui/EstadoVacio.vue';
import ImagenProducto from '@/ui/ImagenProducto.vue';
import Insignia from '@/ui/Insignia.vue';

const productos = ref([]);
const categorias = ref([]);
const clientes = ref([]);
const metodos = ref([]);
const sucursales = ref([]);
const inventarios = ref([]);
const ventas = ref([]);
const cargando = ref(true);
const errorCarga = ref('');

const tab = ref('vender');
const busqueda = ref('');
const categoriaSel = ref(0);

// ----- Venta en armado -----
const carrito = ref([]);
const clienteId = ref(null);
const metodoId = ref(null);
const sucursalId = ref(store.sucursalId); // un empleado de sucursal queda fijo en la suya
const sucursalFija = store.sucursalId != null;
const fecha = ref(hoyLocal());
const mostrador = ref(true); // venta de mostrador: no genera pedido
const modalidad = ref('RETIRO');
const direccion = ref('');
const cobrando = ref(false);
const modalConfirmar = ref(false);

async function cargar() {
  cargando.value = true;
  errorCarga.value = '';
  try {
    const pedir = (url) => api.get(url).then((r) => r.data || []).catch(() => []);
    const [p, c, cl, m, s, inv, v] = await Promise.all(
      ['/productos', '/categorias', '/clientes', '/metodospago', '/sucursales', '/inventarios', '/ventas'].map(pedir)
    );
    productos.value = p;
    categorias.value = c;
    clientes.value = cl;
    metodos.value = m;
    sucursales.value = s;
    inventarios.value = inv;
    ventas.value = v;
    if (!sucursalId.value) sucursalId.value = s[0]?.id ?? null;
    if (!metodoId.value) metodoId.value = m[0]?.id ?? null;
    if (!clienteId.value) clienteId.value = cl.find((x) => /consumidor/i.test(x.nombre))?.id ?? cl[0]?.id ?? null;
  } catch (e) {
    errorCarga.value = mensajeError(e, 'No se pudieron cargar los datos de venta.');
  } finally {
    cargando.value = false;
  }
}

// Stock de la sucursal elegida: si el producto no tiene fila de inventario ahí, no se controla.
const stockDe = computed(() => {
  const mapa = {};
  inventarios.value.filter((i) => i.sucursalId === sucursalId.value).forEach((i) => (mapa[i.productoId] = i.stockActual));
  return mapa;
});
const disponible = (p) => (p.id in stockDe.value ? stockDe.value[p.id] : null);

const filtrados = computed(() => {
  const t = busqueda.value.trim().toLowerCase();
  return productos.value.filter((p) => (categoriaSel.value === 0 || p.categoriaId === categoriaSel.value) && (!t || (p.nombre || '').toLowerCase().includes(t)));
});

function enCarrito(p) {
  return carrito.value.find((i) => i.productoId === p.id)?.cantidad || 0;
}
function agregar(p) {
  const tope = disponible(p);
  const actual = enCarrito(p);
  if (tope !== null && actual >= tope) {
    toast.aviso(tope <= 0 ? `"${p.nombre}" está agotado en esta sucursal.` : `Solo quedan ${tope} de "${p.nombre}" en esta sucursal.`);
    return;
  }
  const item = carrito.value.find((i) => i.productoId === p.id);
  if (item) item.cantidad++;
  else carrito.value.push({ productoId: p.id, nombre: p.nombre, precio: Number(p.precio) || 0, cantidad: 1, imagenUrl: p.imagenUrl });
}
function cambiar(item, delta) {
  const p = productos.value.find((x) => x.id === item.productoId);
  const tope = p ? disponible(p) : null;
  if (delta > 0 && tope !== null && item.cantidad >= tope) {
    toast.aviso(`Solo quedan ${tope} de "${item.nombre}" en esta sucursal.`);
    return;
  }
  item.cantidad = Math.min(9999, item.cantidad + delta);
  if (item.cantidad <= 0) quitar(item);
}
function quitar(item) {
  carrito.value = carrito.value.filter((i) => i !== item);
}

const total = computed(() => carrito.value.reduce((s, i) => s + i.precio * i.cantidad, 0));
const unidades = computed(() => carrito.value.reduce((s, i) => s + i.cantidad, 0));

// Si cambia de sucursal, se revisa que el carrito siga cabiendo en su stock.
watch(sucursalId, () => {
  carrito.value = carrito.value.filter((i) => {
    const tope = stockDe.value[i.productoId];
    if (tope === undefined) return true;
    if (tope <= 0) return false;
    i.cantidad = Math.min(i.cantidad, tope);
    return true;
  });
});

const nombreCliente = computed(() => clientes.value.find((c) => c.id === clienteId.value)?.nombre || 'Sin cliente');
const nombreMetodo = computed(() => metodos.value.find((m) => m.id === metodoId.value)?.nombre || '');
const nombreSucursal = (id) => sucursales.value.find((s) => s.id === id)?.nombre || '—';

function pedirConfirmacion() {
  if (!carrito.value.length) return toast.aviso('Agregá al menos un producto.');
  if (!sucursalId.value) return toast.error('Elegí una sucursal. Si no hay ninguna, creá una primero.');
  if (!clienteId.value) return toast.error('Elegí un cliente.');
  if (!metodoId.value) return toast.error('Elegí un método de pago.');
  if (fecha.value > hoyLocal()) return toast.error('La fecha de la venta no puede ser futura.');
  if (!mostrador.value && modalidad.value === 'DELIVERY' && !direccion.value.trim()) return toast.error('Para delivery escribí la dirección de entrega.');
  modalConfirmar.value = true;
}

async function cobrar() {
  cobrando.value = true;
  try {
    const { data } = await api.post('/ventas', {
      sucursalId: Number(sucursalId.value),
      clienteId: Number(clienteId.value),
      metodoPagoId: Number(metodoId.value),
      // Se usan las 12:00 del día elegido para que la zona horaria no lo corra al día anterior.
      fecha: new Date(fecha.value + 'T12:00:00').toISOString(),
      mostrador: mostrador.value,
      modalidad: mostrador.value ? 'RETIRO' : modalidad.value,
      direccionEntrega: !mostrador.value && modalidad.value === 'DELIVERY' ? direccion.value.trim() : null,
      detalles: carrito.value.map((i) => ({ productoId: i.productoId, cantidad: i.cantidad })),
    });
    toast.ok(`Venta #${data.id} registrada por ${bs(data.total)}${data.pedidoId ? ` · Pedido #${data.pedidoId}` : ''}.`);
    carrito.value = [];
    fecha.value = hoyLocal();
    direccion.value = '';
    modalConfirmar.value = false;
    await cargar();
  } catch (e) {
    modalConfirmar.value = false;
    toast.error(mensajeError(e, 'No se pudo registrar la venta.'));
  } finally {
    cobrando.value = false;
  }
}

// ----- Cliente nuevo desde el mostrador -----
const modalCliente = ref(false);
const nuevoCliente = ref({ nombre: '', telefono: '' });
const errorCliente = ref('');
const guardandoCliente = ref(false);
function abrirCliente() {
  nuevoCliente.value = { nombre: '', telefono: '' };
  errorCliente.value = '';
  modalCliente.value = true;
}
async function guardarCliente() {
  if (!nuevoCliente.value.nombre.trim()) {
    errorCliente.value = 'Escribí el nombre del cliente.';
    return;
  }
  guardandoCliente.value = true;
  try {
    const { data } = await api.post('/clientes', {
      emprendimientoId: clientes.value[0]?.emprendimientoId ?? 1,
      nombre: nuevoCliente.value.nombre.trim(),
      telefono: nuevoCliente.value.telefono.trim() || null,
    });
    clientes.value.push(data);
    clienteId.value = data.id;
    modalCliente.value = false;
    toast.ok('Cliente agregado.');
  } catch (e) {
    errorCliente.value = mensajeError(e, 'No se pudo guardar el cliente.');
  } finally {
    guardandoCliente.value = false;
  }
}

// ----- Historial -----
const nombreClienteDe = (id) => clientes.value.find((c) => c.id === id)?.nombre || `Cliente #${id}`;
const nombreMetodoDe = (id) => metodos.value.find((m) => m.id === id)?.nombre || '—';
const totalHistorial = computed(() => ventas.value.reduce((s, v) => s + Number(v.total || 0), 0));

onMounted(cargar);
</script>

<template>
  <div>
    <EncabezadoPagina titulo="Punto de venta" subtitulo="Registrá ventas de mostrador o pedidos para retirar y enviar" />

    <div v-if="errorCarga" class="aviso-linea error" role="alert" style="margin-bottom: 16px">
      <AppIcon name="alert" :size="18" /> <span class="crece">{{ errorCarga }}</span>
      <button type="button" class="btn btn-secundario btn-sm" @click="cargar">Reintentar</button>
    </div>

    <div class="pestanas" role="tablist" style="margin-bottom: 20px">
      <button type="button" role="tab" class="pestana" :class="{ activa: tab === 'vender' }" :aria-selected="tab === 'vender'" @click="tab = 'vender'">Vender</button>
      <button type="button" role="tab" class="pestana" :class="{ activa: tab === 'historial' }" :aria-selected="tab === 'historial'" @click="tab = 'historial'">
        Historial <span class="contador">{{ ventas.length }}</span>
      </button>
    </div>

    <!-- ===== Vender ===== -->
    <div v-if="tab === 'vender'" class="pos">
      <section class="pos-catalogo">
        <div class="fila fila-envolver" style="margin-bottom: 14px">
          <div class="entrada-icono crece" style="min-width: 220px">
            <AppIcon name="search" :size="17" class="icono-izq" />
            <input v-model="busqueda" type="search" placeholder="Buscar producto..." aria-label="Buscar producto" />
          </div>
        </div>
        <div class="chips" style="margin-bottom: 16px">
          <button type="button" class="chip" :class="{ activo: categoriaSel === 0 }" @click="categoriaSel = 0">Todo</button>
          <button v-for="c in categorias" :key="c.id" type="button" class="chip" :class="{ activo: categoriaSel === c.id }" @click="categoriaSel = c.id">{{ c.nombre }}</button>
        </div>

        <div v-if="cargando" class="rejilla"><div v-for="n in 8" :key="n" class="tarjeta"><span class="esqueleto" style="height: 120px"></span></div></div>
        <EstadoVacio v-else-if="!filtrados.length" icono="package" titulo="No hay productos" texto="Probá con otra búsqueda o categoría." />
        <div v-else class="rejilla">
          <button
            v-for="p in filtrados"
            :key="p.id"
            type="button"
            class="prod tarjeta"
            :disabled="disponible(p) !== null && disponible(p) <= 0"
            :aria-label="`Agregar ${p.nombre}, ${bs(p.precio)}`"
            @click="agregar(p)"
          >
            <div class="prod-foto">
              <ImagenProducto :url="p.imagenUrl" :nombre="p.nombre" />
              <span v-if="enCarrito(p)" class="prod-cant">{{ enCarrito(p) }}</span>
            </div>
            <div class="prod-datos">
              <span class="prod-nombre">{{ p.nombre }}</span>
              <span class="prod-precio numeros">{{ bs(p.precio) }}</span>
              <span v-if="disponible(p) !== null" class="texto-chico" :class="disponible(p) <= 0 ? 'agotado' : 'texto-tenue'">
                {{ disponible(p) <= 0 ? 'Agotado' : `${disponible(p)} disponibles` }}
              </span>
            </div>
          </button>
        </div>
      </section>

      <aside class="tarjeta pos-venta">
        <div class="tarjeta-cabecera">
          <h3>Venta actual</h3>
          <button v-if="carrito.length" type="button" class="btn btn-fantasma btn-sm" @click="carrito = []">Vaciar</button>
        </div>

        <div class="pos-lineas">
          <p v-if="!carrito.length" class="texto-suave vacio-carrito"><AppIcon name="cart" :size="22" /><br />Tocá un producto para agregarlo.</p>
          <div v-for="i in carrito" :key="i.productoId" class="linea">
            <div class="linea-mini"><ImagenProducto :url="i.imagenUrl" :nombre="i.nombre" /></div>
            <div class="crece">
              <div class="truncar negrita">{{ i.nombre }}</div>
              <div class="texto-chico texto-tenue numeros">{{ bs(i.precio) }} c/u</div>
            </div>
            <div class="paso">
              <button type="button" class="btn btn-secundario btn-icono btn-sm" :aria-label="`Quitar una unidad de ${i.nombre}`" @click="cambiar(i, -1)"><AppIcon name="minus" :size="14" /></button>
              <span class="numeros" aria-live="polite">{{ i.cantidad }}</span>
              <button type="button" class="btn btn-secundario btn-icono btn-sm" :aria-label="`Agregar una unidad de ${i.nombre}`" @click="cambiar(i, 1)"><AppIcon name="plus" :size="14" /></button>
            </div>
            <strong class="subtotal numeros">{{ bs(i.precio * i.cantidad) }}</strong>
          </div>
        </div>

        <div class="pos-datos formulario">
          <Campo label="Sucursal" v-slot="{ id }">
            <select :id="id" v-model="sucursalId" :disabled="sucursalFija">
              <option v-for="s in sucursales" :key="s.id" :value="s.id">{{ s.nombre }}</option>
            </select>
          </Campo>
          <Campo label="Cliente" v-slot="{ id }">
            <div class="fila" style="gap: 8px">
              <select :id="id" v-model="clienteId">
                <option v-for="c in clientes" :key="c.id" :value="c.id">{{ c.nombre }}</option>
              </select>
              <button type="button" class="btn btn-secundario btn-icono" aria-label="Agregar cliente nuevo" @click="abrirCliente"><AppIcon name="plus" :size="18" /></button>
            </div>
          </Campo>
          <Campo label="Método de pago" v-slot="{ id }">
            <select :id="id" v-model="metodoId"><option v-for="m in metodos" :key="m.id" :value="m.id">{{ m.nombre }}</option></select>
          </Campo>
          <label class="opcion-check">
            <input v-model="mostrador" type="checkbox" />
            <span><strong>Venta de mostrador</strong><br /><span class="texto-tenue texto-chico">Se entrega ahora; no genera pedido en la cola.</span></span>
          </label>
          <template v-if="!mostrador">
            <div class="segmentos" role="group" aria-label="Modalidad de entrega">
              <button type="button" class="segmento" :class="{ activo: modalidad === 'RETIRO' }" @click="modalidad = 'RETIRO'">Retiro en local</button>
              <button type="button" class="segmento" :class="{ activo: modalidad === 'DELIVERY' }" @click="modalidad = 'DELIVERY'">Delivery</button>
            </div>
            <Campo v-if="modalidad === 'DELIVERY'" label="Dirección de entrega" requerido v-slot="{ id }"><input :id="id" v-model="direccion" maxlength="300" autocomplete="street-address" /></Campo>
          </template>
          <Campo label="Fecha de la venta" ayuda="Podés cargar ventas de días anteriores." v-slot="{ id }"><input :id="id" v-model="fecha" type="date" :max="hoyLocal()" /></Campo>
        </div>

        <div class="pos-total">
          <div class="fila entre"><span class="texto-suave">{{ unidades }} {{ unidades === 1 ? 'unidad' : 'unidades' }}</span><span class="texto-suave">Total</span></div>
          <div class="total-valor numeros">{{ bs(total) }}</div>
          <button type="button" class="btn btn-primario btn-lg btn-bloque" :disabled="!carrito.length || cobrando" @click="pedirConfirmacion">
            <AppIcon name="check" :size="18" /> Cobrar
          </button>
        </div>
      </aside>
    </div>

    <!-- ===== Historial ===== -->
    <div v-else class="tarjeta">
      <div class="tarjeta-cabecera"><h3>Ventas registradas</h3><span class="texto-suave texto-chico">{{ ventas.length }} ventas · {{ bs(totalHistorial) }}</span></div>
      <EstadoVacio v-if="!ventas.length && !cargando" icono="receipt" titulo="Todavía no hay ventas" texto="Las ventas que registres van a aparecer acá." />
      <div v-else class="tabla-contenedor">
        <table class="tabla">
          <thead><tr><th>N.º</th><th>Fecha</th><th>Cliente</th><th class="oculto-movil">Sucursal</th><th class="oculto-movil">Pago</th><th class="num">Total</th></tr></thead>
          <tbody>
            <tr v-if="cargando"><td v-for="n in 6" :key="n"><span class="esqueleto"></span></td></tr>
            <tr v-for="v in ventas" :key="v.id">
              <td><strong>#{{ v.id }}</strong></td>
              <td>{{ fechaHora(v.fecha) }}</td>
              <td>{{ nombreClienteDe(v.clienteId) }}</td>
              <td class="oculto-movil">{{ nombreSucursal(v.sucursalId) }}</td>
              <td class="oculto-movil"><Insignia tono="marca" sin-punto>{{ nombreMetodoDe(v.metodoPagoId) }}</Insignia></td>
              <td class="num"><strong>{{ bs(v.total) }}</strong></td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>

    <!-- Confirmar cobro -->
    <AppModal v-model="modalConfirmar" titulo="Confirmar venta" tamano="sm">
      <div class="pila-sm">
        <div class="fila entre"><span class="texto-suave">Cliente</span><strong>{{ nombreCliente }}</strong></div>
        <div class="fila entre"><span class="texto-suave">Sucursal</span><strong>{{ nombreSucursal(sucursalId) }}</strong></div>
        <div class="fila entre"><span class="texto-suave">Pago</span><strong>{{ nombreMetodo }}</strong></div>
        <div class="fila entre"><span class="texto-suave">Entrega</span><strong>{{ mostrador ? 'Mostrador' : modalidad === 'DELIVERY' ? 'Delivery' : 'Retiro en local' }}</strong></div>
        <hr class="sep" />
        <div class="fila entre"><span>{{ unidades }} {{ unidades === 1 ? 'unidad' : 'unidades' }}</span><strong class="total-valor numeros">{{ bs(total) }}</strong></div>
      </div>
      <template #pie>
        <button type="button" class="btn btn-secundario" @click="modalConfirmar = false">Volver</button>
        <button type="button" class="btn btn-primario" :disabled="cobrando" @click="cobrar">{{ cobrando ? 'Registrando...' : 'Confirmar cobro' }}</button>
      </template>
    </AppModal>

    <!-- Cliente nuevo -->
    <AppModal v-model="modalCliente" titulo="Cliente nuevo" tamano="sm">
      <form id="form-cliente" class="formulario" novalidate @submit.prevent="guardarCliente">
        <div v-if="errorCliente" class="aviso-linea error" role="alert">{{ errorCliente }}</div>
        <Campo label="Nombre" requerido v-slot="{ id }"><input :id="id" v-model="nuevoCliente.nombre" maxlength="120" autocomplete="off" /></Campo>
        <Campo label="Teléfono" v-slot="{ id }"><input :id="id" v-model="nuevoCliente.telefono" maxlength="30" inputmode="tel" autocomplete="off" /></Campo>
      </form>
      <template #pie>
        <button type="button" class="btn btn-secundario" @click="modalCliente = false">Cancelar</button>
        <button type="submit" form="form-cliente" class="btn btn-primario" :disabled="guardandoCliente">Guardar</button>
      </template>
    </AppModal>
  </div>
</template>

<style scoped>
.pos { display: grid; grid-template-columns: minmax(0, 1fr) 380px; gap: 22px; align-items: start; }
@media (max-width: 1100px) { .pos { grid-template-columns: 1fr; } }

.rejilla { display: grid; grid-template-columns: repeat(auto-fill, minmax(150px, 1fr)); gap: 14px; }
.prod { padding: 0; text-align: left; cursor: pointer; overflow: hidden; display: flex; flex-direction: column; font: inherit; color: inherit; transition: box-shadow 0.15s, transform 0.1s; }
.prod:hover:not(:disabled) { box-shadow: var(--sombra-2); transform: translateY(-2px); }
.prod:active:not(:disabled) { transform: scale(0.98); }
.prod:disabled { opacity: 0.55; cursor: not-allowed; }
.prod-foto { position: relative; aspect-ratio: 1 / 0.8; background: var(--superficie-2); }
.prod-cant {
  position: absolute; top: 8px; right: 8px; min-width: 26px; height: 26px; padding: 0 7px; border-radius: 13px;
  background: var(--marca); color: #fff; font-weight: 800; font-size: 13px; display: grid; place-items: center; box-shadow: var(--sombra-1);
}
.prod-datos { display: grid; gap: 2px; padding: 10px 12px 12px; }
.prod-nombre { font-weight: 600; font-size: 14px; line-height: 1.3; }
.prod-precio { color: var(--marca); font-weight: 800; }
.agotado { color: var(--peligro); font-weight: 700; }

.pos-venta { position: sticky; top: 84px; display: flex; flex-direction: column; max-height: calc(100vh - 104px); }
@media (max-width: 1100px) { .pos-venta { position: static; max-height: none; } }
.pos-lineas { padding: 6px 16px; overflow-y: auto; min-height: 90px; max-height: 260px; }
.vacio-carrito { text-align: center; padding: 20px 0; }
.linea { display: grid; grid-template-columns: 40px minmax(0, 1fr) auto auto; gap: 10px; align-items: center; padding: 9px 0; border-bottom: 1px solid var(--borde); }
.linea:last-child { border-bottom: none; }
.linea-mini { width: 40px; height: 40px; border-radius: 8px; overflow: hidden; font-size: 1rem; }
.paso { display: flex; align-items: center; gap: 6px; }
.paso span { min-width: 22px; text-align: center; font-weight: 700; }
.subtotal { min-width: 70px; text-align: right; font-size: 14px; }
.pos-datos { padding: 14px 16px; border-top: 1px solid var(--borde); gap: 12px; overflow-y: auto; }
.pos-total { padding: 14px 16px 16px; border-top: 1px solid var(--borde); background: var(--superficie-2); border-radius: 0 0 var(--r-md) var(--r-md); display: grid; gap: 4px; }
.total-valor { font-size: 28px; font-weight: 800; letter-spacing: -0.02em; margin-bottom: 8px; }
</style>
