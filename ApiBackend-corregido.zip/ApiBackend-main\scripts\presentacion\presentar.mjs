// Presentación automática de los 11 requisitos funcionales en Chrome.
// Abre Chrome, maneja la interfaz sola y muestra un rótulo con el requisito que se está probando.
//
// Uso (desde la raíz del proyecto):   .\scripts\presentar.ps1
//   Opciones de este script:  --rapido   (pausas cortas, para ensayar)
//                             --oculto   (sin ventana, para verificar que todo funciona)
//                             --pausa=1.5   (multiplicador de las pausas)
import { chromium } from 'playwright-core';
import { execSync } from 'node:child_process';

const args = process.argv.slice(2);
const RAPIDO = args.includes('--rapido');
const OCULTO = args.includes('--oculto');
const pausaArg = args.find((a) => a.startsWith('--pausa='));
const PAUSA = pausaArg ? Number(pausaArg.split('=')[1]) : RAPIDO ? 0.15 : 1;

const UI = process.env.KIA_UI || 'http://127.0.0.1:5174';
const API = process.env.KIA_API || 'http://127.0.0.1:5209/api';
const SETUP_USUARIO = process.env.KIA_SETUP_USUARIO || 'instalador@kiataque.local';
const SETUP_CLAVE = process.env.KIA_SETUP_CLAVE || 'Instal-Demo-2026!';
const BASE_DATOS = process.env.KIA_BD || 'DB_Panaderia2_demo';
const SERVIDOR_SQL = process.env.KIA_SQL || '.\\SQLEXPRESS';

const ADMIN = { nombre: 'Admin Demo', email: 'admin@kiataque.bo', clave: 'Admin-Demo-2026' };
const CAJA = { nombre: 'Carla Cajera', email: 'caja@kiataque.bo', clave: 'Caja-Demo-2026' };
const INV = { nombre: 'Ivan Inventario', email: 'inv@kiataque.bo', clave: 'Inv-Demo-2026' };

const dormir = (ms) => new Promise((r) => setTimeout(r, ms));
const esperar = (ms) => dormir(ms * PAUSA);

// ---------------------------------------------------------------- API (para preparar datos y mostrar evidencia)
async function api(metodo, ruta, cuerpo, token, extra = {}) {
  const r = await fetch(API + ruta, {
    method: metodo,
    headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: 'Bearer ' + token } : {}), ...extra },
    body: cuerpo ? JSON.stringify(cuerpo) : undefined,
  });
  let datos = null;
  try { datos = await r.json(); } catch { /* sin cuerpo */ }
  return { codigo: r.status, datos, cabeceras: r.headers };
}
const login = async (u) => (await api('POST', '/auth/login', { email: u.email, password: u.clave })).datos?.token;

// ---------------------------------------------------------------- Rótulos y paneles de evidencia en pantalla
async function instalarRotulo(ctx) {
  await ctx.addInitScript(() => {
    const crear = () => {
      if (document.getElementById('kia-cap')) return;
      const d = document.createElement('div');
      d.id = 'kia-cap';
      d.style.cssText = 'position:fixed;left:50%;transform:translateX(-50%);bottom:16px;pointer-events:none;z-index:2147483647;background:rgba(20,12,7,.95);color:#fff;font:600 17px "Segoe UI",sans-serif;padding:13px 20px;border-radius:14px;box-shadow:0 8px 30px rgba(0,0,0,.45);max-width:min(640px,48vw);border-left:6px solid #d98a2b;display:none;line-height:1.35';
      document.documentElement.appendChild(d);
      const t = sessionStorage.getItem('kia_cap');
      if (t) { d.innerHTML = t; d.style.display = 'block'; }
    };
    if (document.readyState !== 'loading') crear(); else document.addEventListener('DOMContentLoaded', crear);
  });
}
async function rotulo(page, n, titulo, detalle = '') {
  const html = `<div style="font-size:12px;color:#e9a64a;letter-spacing:.12em;margin-bottom:2px">REQUISITO ${n}</div>${titulo}${detalle ? `<div style="font:400 14px 'Segoe UI';color:#dcc8ad;margin-top:4px">${detalle}</div>` : ''}`;
  await page.evaluate((h) => {
    sessionStorage.setItem('kia_cap', h);
    const d = document.getElementById('kia-cap');
    if (d) { d.innerHTML = h; d.style.display = 'block'; }
  }, html);
}
async function nota(page, texto) { // texto breve sin cambiar de requisito
  await page.evaluate((t) => {
    const d = document.getElementById('kia-cap');
    if (!d) return;
    let n = d.querySelector('.nota');
    if (!n) { n = document.createElement('div'); n.className = 'nota'; n.style.cssText = "font:400 14px 'Segoe UI';color:#a8e0b4;margin-top:5px"; d.appendChild(n); }
    n.textContent = t;
  }, texto);
}
const esc = (s) => String(s).replace(/[&<>]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]));
async function evidencia(page, titulo, html, ms = 5500) {
  await page.evaluate(([t, h]) => {
    const o = document.createElement('div');
    o.id = 'kia-ev';
    o.style.cssText = 'position:fixed;inset:0;background:rgba(20,12,7,.8);z-index:2147483646;display:flex;align-items:center;justify-content:center;padding:30px';
    o.innerHTML = `<div style="background:#fff;border-radius:16px;max-width:940px;width:100%;max-height:84vh;overflow:auto;padding:24px 28px;font:14px 'Segoe UI',sans-serif;color:#2b1d14"><div style="font:700 21px 'Segoe UI';margin-bottom:14px">${t}</div>${h}</div>`;
    document.body.appendChild(o);
  }, [titulo, html]);
  await esperar(ms);
  await page.evaluate(() => document.getElementById('kia-ev')?.remove());
}
const tabla = (cabeceras, filas) =>
  `<table style="border-collapse:collapse;width:100%"><thead><tr>${cabeceras.map((c) => `<th style="text-align:left;padding:7px 10px;background:#f6efe3;border-bottom:1px solid #e8dfd0">${esc(c)}</th>`).join('')}</tr></thead><tbody>${filas
    .map((f) => `<tr>${f.map((c) => `<td style="padding:7px 10px;border-bottom:1px solid #e8dfd0">${c}</td>`).join('')}</tr>`)
    .join('')}</tbody></table>`;
const json = (o) => `<pre style="background:#2b1d14;color:#f6ead9;padding:14px;border-radius:10px;font:13px Consolas,monospace;white-space:pre-wrap;margin:0">${esc(JSON.stringify(o, null, 2))}</pre>`;
const ok = (b, t) => `<span style="color:${b ? '#2b7342' : '#b3392a'};font-weight:700">${esc(t)}</span>`;

// ---------------------------------------------------------------- Acciones de interfaz
async function escribir(loc, texto) {
  await loc.click();
  await loc.fill('');
  if (RAPIDO) await loc.fill(texto);
  else await loc.pressSequentially(texto, { delay: 35 });
}
async function irA(page, modulo) {
  await page.evaluate((m) => { location.hash = '#/' + m; }, modulo);
  await esperar(900);
}
async function toastVisible(page, texto, ms = 6000) {
  await page.locator('.toast', { hasText: texto }).first().waitFor({ timeout: ms });
}
async function iniciarSesionUI(page, usuario) {
  await page.goto(UI);
  await escribir(page.locator('input[type=email]'), usuario.email);
  await escribir(page.locator('input[autocomplete=current-password]'), usuario.clave);
  await esperar(400);
  await page.getByRole('button', { name: 'Ingresar' }).click();
}
async function cerrarSesionUI(page) {
  await page.locator('.usuario-btn').click();
  await page.getByRole('button', { name: 'Cerrar sesión' }).click();
  await esperar(500);
}
async function modalGuardar(page) {
  await page.getByRole('dialog').getByRole('button', { name: 'Guardar' }).click();
}

// ---------------------------------------------------------------- Ejecución
const resultados = [];
async function paso(n, titulo, fn, page) {
  const t0 = Date.now();
  try {
    await fn();
    resultados.push({ n, titulo, ok: true });
    console.log(`  [ OK ] Requisito ${n}: ${titulo}  (${((Date.now() - t0) / 1000).toFixed(1)} s)`);
  } catch (e) {
    resultados.push({ n, titulo, ok: false, error: String(e.message || e).split('\n')[0] });
    console.log(`  [FALLA] Requisito ${n}: ${titulo}\n          ${String(e.message || e).split('\n')[0]}`);
    try { await page.screenshot({ path: `falla-req${n}.png` }); } catch { /* */ }
    try { await page.evaluate(() => { document.getElementById('kia-ev')?.remove(); }); } catch { /* */ }
  }
}

const navegador = await chromium.launch({
  channel: 'chrome',
  headless: OCULTO,
  args: OCULTO ? [] : ['--start-maximized'],
});
const ctx = await navegador.newContext(OCULTO ? { viewport: { width: 1440, height: 860 } } : { viewport: null });
await instalarRotulo(ctx);
const page = await ctx.newPage();
page.setDefaultTimeout(12000);

console.log('Presentación de los 11 requisitos funcionales' + (RAPIDO ? ' (modo rápido)' : ''));
let tokenAdmin = null, tokenCaja = null, tokenInv = null;

// ============ Requisito 6: primer administrador con el super-usuario oculto ============
await paso(6, 'Primer administrador con el super-usuario oculto', async () => {
  await page.goto(UI);
  await rotulo(page, 6, 'Primer administrador con el super-usuario oculto', 'No hay ningún usuario en el sistema: no existe una cuenta con clave conocida.');
  await esperar(2500);
  await escribir(page.locator('input[type=email]'), SETUP_USUARIO);
  await escribir(page.locator('input[autocomplete=current-password]'), SETUP_CLAVE);
  await page.getByRole('button', { name: 'Ingresar' }).click();
  await page.getByRole('heading', { name: 'Crear el primer administrador' }).waitFor();
  await rotulo(page, 6, 'El super-usuario solo puede crear el primer administrador', 'Está en el servidor, no en la base: no aparece en la lista de usuarios.');
  await esperar(2200);
  const campos = page.locator('form input');
  await escribir(campos.nth(0), ADMIN.nombre);
  await escribir(campos.nth(1), ADMIN.email);
  await escribir(campos.nth(2), 'debil');
  await escribir(campos.nth(3), 'debil');
  await page.getByRole('button', { name: 'Crear administrador' }).click();
  await page.getByText('no cumple los requisitos').waitFor();
  await nota(page, 'Contraseña débil rechazada');
  await esperar(2200);
  await escribir(campos.nth(2), ADMIN.clave);
  await escribir(campos.nth(3), ADMIN.clave);
  await page.getByRole('button', { name: 'Crear administrador' }).click();
  await page.getByText('Administrador creado').waitFor();
  await nota(page, 'Primer administrador creado');
  await esperar(2000);
  await page.getByRole('button', { name: 'Ir al inicio de sesión' }).click();
  await rotulo(page, 6, 'Con un administrador creado, el super-usuario deja de funcionar');
  await escribir(page.locator('input[type=email]'), SETUP_USUARIO);
  await escribir(page.locator('input[autocomplete=current-password]'), SETUP_CLAVE);
  await page.getByRole('button', { name: 'Ingresar' }).click();
  await page.getByText('Correo o contraseña incorrectos').waitFor();
  await esperar(2500);
}, page);

tokenAdmin = await login(ADMIN);
if (!tokenAdmin) { console.log('No se pudo crear/entrar con el administrador; se detiene.'); await navegador.close(); process.exit(1); }

// Datos base que no son el foco de la presentación: inventario de la Sucursal Centro
const productos = (await api('GET', '/productos')).datos || [];
const sucursales0 = (await api('GET', '/sucursales')).datos || [];
const centro = sucursales0[0]?.id;
const prodPorNombre = (n) => productos.find((p) => p.nombre === n)?.id;
for (const p of productos) await api('POST', '/inventarios', { productoId: p.id, sucursalId: centro, stockActual: 60, stockMinimo: 10 }, tokenAdmin);

// ============ Requisito 5: hash, JWT, UNIQUE, CHECK, FK ============
await paso(5, 'Hash, JWT, UNIQUE, CHECK y FKs', async () => {
  await iniciarSesionUI(page, ADMIN);
  await page.getByText('Ventas de hoy').waitFor();
  await rotulo(page, 5, 'Seguridad del modelado de datos', 'Contraseñas con hash, sesión con JWT y reglas en la base de datos.');
  const usuarios = (await api('GET', '/usuarios', null, tokenAdmin)).datos;
  const payload = JSON.parse(Buffer.from(tokenAdmin.split('.')[1], 'base64url').toString());
  let restricciones = '(sqlcmd no disponible)';
  try {
    restricciones = execSync(`sqlcmd -S "${SERVIDOR_SQL}" -E -C -d ${BASE_DATOS} -h -1 -W -Q "SET NOCOUNT ON; SELECT CAST((SELECT COUNT(*) FROM sys.indexes WHERE name LIKE 'UX_%') AS varchar)+' UNIQUE · '+CAST((SELECT COUNT(*) FROM sys.check_constraints WHERE name LIKE 'CK_%') AS varchar)+' CHECK · '+CAST((SELECT COUNT(*) FROM sys.foreign_keys) AS varchar)+' claves foráneas'"`, { encoding: 'utf8' }).split('\n')[0].trim();
  } catch { /* sin sqlcmd */ }
  await evidencia(page, 'Contraseñas con hash · sesión JWT · reglas en la base', `
    <p><b>La API nunca devuelve el hash.</b> Campos que devuelve de un usuario: <code>${esc(Object.keys(usuarios[0]).join(', '))}</code></p>
    <p style="margin-top:10px"><b>Token de sesión (JWT)</b> — contenido firmado: emisor <code>${esc(payload.iss)}</code>, vence ${esc(new Date(payload.exp * 1000).toLocaleString())}, rol <code>${esc(payload['http://schemas.microsoft.com/ws/2008/06/identity/claims/role'])}</code></p>
    <p style="margin-top:10px"><b>En la base de datos:</b> ${esc(restricciones)}</p>
    <p style="margin-top:10px">Las contraseñas se guardan con PBKDF2-SHA256, 100 000 iteraciones y sal aleatoria.</p>`, 9000);
}, page);

// ============ Requisito 3: usuarios, roles y permisos ============
await paso(3, 'Usuarios, roles y permisos', async () => {
  await irA(page, 'usuarios');
  await rotulo(page, 3, 'Usuarios, roles y permisos', 'El administrador crea al personal y le asigna un rol.');
  await page.getByRole('button', { name: 'Nuevo' }).click();
  const dlg = page.getByRole('dialog');
  await escribir(dlg.getByLabel('Nombre'), CAJA.nombre);
  await escribir(dlg.getByLabel('Correo'), CAJA.email);
  await escribir(dlg.getByLabel('Contraseña'), 'debil');
  await dlg.getByLabel('Rol').selectOption({ label: 'Cajero' });
  await modalGuardar(page);
  await dlg.getByText('Mínimo 8 caracteres').waitFor();
  await nota(page, 'Contraseña débil rechazada');
  await esperar(1800);
  await escribir(dlg.getByLabel('Contraseña'), CAJA.clave);
  await modalGuardar(page);
  await toastVisible(page, 'Se creó');
  await esperar(1200);
  // correo repetido
  await page.getByRole('button', { name: 'Nuevo' }).click();
  await escribir(dlg.getByLabel('Nombre'), 'Otra Persona');
  await escribir(dlg.getByLabel('Correo'), CAJA.email.toUpperCase());
  await escribir(dlg.getByLabel('Contraseña'), 'Otra-Clave-2026');
  await dlg.getByLabel('Rol').selectOption({ label: 'Cajero' });
  await modalGuardar(page);
  await toastVisible(page, 'Ya existe un usuario con ese correo');
  await nota(page, 'Correo repetido rechazado (UNIQUE, sin importar mayúsculas)');
  await esperar(2000);
  await page.getByRole('dialog').getByRole('button', { name: 'Cancelar' }).click();
  // usuario de inventario
  await page.getByRole('button', { name: 'Nuevo' }).click();
  await escribir(dlg.getByLabel('Nombre'), INV.nombre);
  await escribir(dlg.getByLabel('Correo'), INV.email);
  await escribir(dlg.getByLabel('Contraseña'), INV.clave);
  await dlg.getByLabel('Rol').selectOption({ label: 'Inventario' });
  await modalGuardar(page);
  await toastVisible(page, 'Se creó');
  await esperar(1200);
  tokenCaja = await login(CAJA);
  tokenInv = await login(INV);
  const acciones = [
    ['Ver usuarios', 'GET', '/usuarios'], ['Ver pedidos', 'GET', '/pedidos'], ['Ver inventario', 'GET', '/inventarios'],
    ['Ver movimientos de inventario', 'GET', '/movimientosinventario'], ['Ver reportes', 'GET', '/reportes/ventas'],
    ['Crear un respaldo', 'POST', '/respaldos'], ['Ver métricas de rendimiento', 'GET', '/metricas'],
  ];
  const filas = [];
  for (const [t, m, r] of acciones) {
    const celda = async (tok) => { const x = await api(m, r, null, tok); return ok(x.codigo < 300, x.codigo < 300 ? 'permitido' : 'prohibido (' + x.codigo + ')'); };
    filas.push([t, await celda(tokenAdmin), await celda(tokenCaja), await celda(tokenInv)]);
  }
  await evidencia(page, 'Qué puede hacer cada rol (respuestas reales de la API)', tabla(['Acción', 'Administrador', 'Cajero', 'Inventario'], filas), 9000);
}, page);

// ============ Requisito 9: multi-sucursal y Ley 164 ============
await paso(9, 'Multi-sucursal y Ley 164', async () => {
  await irA(page, 'sucursales');
  await rotulo(page, 9, 'Escalabilidad multi-sucursal', 'Agregar una sucursal es crear un registro.');
  await page.getByRole('button', { name: 'Nuevo' }).click();
  const dlg = page.getByRole('dialog');
  await escribir(dlg.getByLabel('Nombre'), 'Sucursal Norte');
  await escribir(dlg.getByLabel('Dirección'), 'Av. Banzer km 5');
  await escribir(dlg.getByLabel('Teléfono'), '70022222');
  await dlg.getByLabel('Ciudad').selectOption({ index: 1 });
  await modalGuardar(page);
  await toastVisible(page, 'Se creó');
  await esperar(1200);
  await irA(page, 'empleados');
  await page.getByRole('button', { name: 'Nuevo' }).click();
  await dlg.getByLabel('Usuario').selectOption({ label: `${CAJA.nombre} (${CAJA.email})` });
  await dlg.getByLabel('Sucursal').selectOption({ label: 'Sucursal Norte' });
  await escribir(dlg.getByLabel('Cargo'), 'Cajera');
  await escribir(dlg.getByLabel('Salario'), '2500');
  await modalGuardar(page);
  await toastVisible(page, 'Se creó');
  await nota(page, 'La cajera queda asignada a la Sucursal Norte');
  await esperar(1800);
  const norte = ((await api('GET', '/sucursales')).datos || []).find((s) => s.nombre === 'Sucursal Norte')?.id;
  for (const n of ['Pan de batalla', 'Cuñapé', 'Empanada de queso']) await api('POST', '/inventarios', { productoId: prodPorNombre(n), sucursalId: norte, stockActual: 40, stockMinimo: 8 }, tokenAdmin);
  // Ley 164
  await rotulo(page, 9, 'Ley 164: datos personales', 'Consentimiento, derecho de acceso y derecho de supresión.');
  const sinConsent = await api('POST', '/clientes', { emprendimientoId: 1, nombre: 'Marcos Rojas', telefono: '77700000', email: 'marcos@mail.com', direccion: 'Calle Sucre 45' });
  const cliente = (await api('POST', '/clientes', { emprendimientoId: 1, nombre: 'Marcos Rojas', telefono: '77700000', email: 'marcos@mail.com', direccion: 'Calle Sucre 45', consentimientoFecha: new Date().toISOString() })).datos;
  const antes = (await api('GET', `/clientes/${cliente.id}/datos`, null, tokenAdmin)).datos;
  await api('POST', `/clientes/${cliente.id}/anonimizar`, null, tokenAdmin);
  const despues = (await api('GET', `/clientes/${cliente.id}`, null, tokenAdmin)).datos;
  await evidencia(page, 'Ley 164 · consentimiento, acceso y supresión de datos personales', `
    <p><b>1. Consentimiento:</b> sin aceptar el tratamiento de datos, el sistema <b>no guarda</b> los datos de un visitante → ${ok(sinConsent.codigo === 400, 'HTTP ' + sinConsent.codigo + ': ' + (sinConsent.datos?.mensaje || ''))}</p>
    <p style="margin-top:10px"><b>2. Derecho de acceso</b> (el administrador obtiene todo lo guardado de la persona):</p>${json({ nombre: antes.cliente.nombre, telefono: antes.cliente.telefono, email: antes.cliente.email, direccion: antes.cliente.direccion, aceptoElTratamientoDeDatos: antes.cliente.consentimientoFecha })}
    <p style="margin-top:10px"><b>3. Derecho de supresión</b> (se borran los datos personales y las ventas se conservan sin datos identificables):</p>${json({ nombre: despues.nombre, telefono: despues.telefono, email: despues.email, direccion: despues.direccion, anonimizado: despues.anonimizado })}`, 12000);
  // cajera: solo ve su sucursal
  await cerrarSesionUI(page);
  await rotulo(page, 9, 'Una cajera de la Sucursal Norte solo ve su sucursal');
  await iniciarSesionUI(page, CAJA);
  await page.getByText('Ventas de hoy').waitFor();
  await nota(page, 'Menú reducido y datos solo de su sucursal');
  await esperar(3500);
  const vender = await api('POST', '/ventas', { sucursalId: centro, clienteId: cliente.id, metodoPagoId: 1, mostrador: true, detalles: [{ productoId: prodPorNombre('Cuñapé'), cantidad: 1 }] }, tokenCaja);
  await evidencia(page, 'La cajera intenta vender en la Sucursal Centro', `<p>${ok(vender.codigo === 403, 'HTTP ' + vender.codigo + ' · prohibido')} — solo puede operar en la sucursal a la que está asignada.</p>`, 4500);
  await page.evaluate(() => { location.hash = '#/usuarios'; });
  await esperar(1500);
  await nota(page, 'Si escribe la dirección de Usuarios a mano, no entra');
  await esperar(2500);
  await cerrarSesionUI(page);
  await iniciarSesionUI(page, ADMIN);
  await page.getByText('Ventas de hoy').waitFor();
}, page);

// ============ Requisito 1: inventario ============
await paso(1, 'Inventario: entradas y salidas', async () => {
  await irA(page, 'inventario');
  await rotulo(page, 1, 'Control de inventario: entradas y salidas', 'Cada movimiento actualiza el stock y queda en el historial.');
  await esperar(2200);
  await page.getByRole('button', { name: 'Salida', exact: true }).click();
  const dlg = page.getByRole('dialog');
  await escribir(dlg.getByLabel('Cantidad'), '999');
  await dlg.getByRole('button', { name: 'Registrar' }).click();
  await dlg.getByText('No hay suficiente stock').waitFor();
  await nota(page, 'Una salida mayor al stock se rechaza: nunca queda en negativo');
  await esperar(2800);
  await escribir(dlg.getByLabel('Cantidad'), '5');
  await dlg.getByRole('button', { name: 'Merma' }).click();
  await dlg.getByRole('button', { name: 'Registrar' }).click();
  await toastVisible(page, 'Salida registrada');
  await esperar(1800);
  await page.getByRole('button', { name: 'Entrada', exact: true }).click();
  await escribir(dlg.getByLabel('Cantidad'), '20');
  await dlg.getByRole('button', { name: 'Compra a proveedor' }).click();
  await dlg.getByRole('button', { name: 'Registrar' }).click();
  await toastVisible(page, 'Entrada registrada');
  await esperar(1500);
  // historial del primer ítem
  await page.getByRole('button', { name: 'Ver historial' }).first().click();
  await page.getByRole('dialog').getByText('Merma').waitFor();
  await nota(page, 'Historial: el movimiento no se puede borrar ni editar (es auditoría)');
  await esperar(3500);
  await page.keyboard.press('Escape');
  // alerta de stock bajo
  const inv = ((await api('GET', '/inventarios', null, tokenAdmin)).datos || []).find((i) => i.productoId === prodPorNombre('Pan integral') && i.sucursalId === centro);
  await api('POST', `/inventarios/${inv.id}/movimiento`, { tipo: 'SALIDA', cantidad: inv.stockActual - 3, motivo: 'Merma por horno apagado' }, tokenAdmin);
  await page.getByRole('button', { name: 'Actualizar' }).or(page.getByRole('button', { name: 'Exportar' })).first().waitFor();
  await page.reload();
  await page.getByText('Ítems en inventario').waitFor();
  await rotulo(page, 1, 'Alerta de stock bajo', 'Pan integral quedó por debajo de su mínimo: aparece como "Crítico" y avisa por notificación.');
  await esperar(3500);
}, page);

// ============ Requisito 2: sucursal y modalidad de entrega ============
await paso(2, 'Elegir sucursal y modalidad (retiro o delivery)', async () => {
  await page.getByRole('link', { name: 'Ver la tienda' }).click();
  await page.getByRole('button', { name: 'Agregar' }).first().waitFor();
  await rotulo(page, 2, 'Pedido de un cliente: sucursal y modalidad', 'La tienda pública permite elegir retiro en local o delivery.');
  await esperar(2200);
  await page.getByRole('button', { name: 'Agregar' }).nth(1).click();
  await esperar(500);
  await page.getByRole('button', { name: 'Agregar' }).nth(1).click();
  await page.getByRole('button', { name: /Abrir el carrito/ }).click();
  await esperar(1500);
  await page.getByRole('button', { name: 'Continuar' }).click();
  await page.getByRole('button', { name: 'Confirmar pedido' }).click();
  await page.getByText('Escribí tu nombre').waitFor();
  await nota(page, 'Validación: faltan datos y el consentimiento (Ley 164)');
  await esperar(2500);
  await page.getByText('Delivery', { exact: true }).click();
  const form = page.locator('#form-pedido');
  await form.getByLabel('Sucursal').selectOption({ label: 'Sucursal Norte' });
  await escribir(form.getByLabel('Tu nombre'), 'Marcela Quiroga');
  await escribir(form.getByLabel('Teléfono'), '72211345');
  await escribir(form.getByLabel('Dirección de entrega'), 'Calle Los Pinos 123, zona Equipetrol');
  await form.getByRole('checkbox').check();
  await esperar(1200);
  await page.getByRole('button', { name: 'Confirmar pedido' }).click();
  await page.getByText('¡Pedido recibido!').waitFor();
  await nota(page, 'Pedido registrado: venta, pedido y descuento de stock en una sola operación');
  await esperar(3500);
  await page.getByRole('button', { name: 'Seguir comprando' }).click();
  await page.getByRole('button', { name: 'Volver al panel' }).click();
}, page);

// ============ Requisito 11: tiempo de servicio ============
await paso(11, 'Tiempo de servicio de cada pedido', async () => {
  // un pedido más antiguo para mostrar el reloj en rojo
  const cli = (await api('POST', '/clientes', { emprendimientoId: 1, nombre: 'Ana Pérez', telefono: '71234567', direccion: 'Calle Beni 220', consentimientoFecha: new Date().toISOString() })).datos;
  const v = await api('POST', '/ventas', { sucursalId: centro, clienteId: cli.id, metodoPagoId: 1, modalidad: 'DELIVERY', detalles: [{ productoId: prodPorNombre('Cuñapé'), cantidad: 3 }] });
  try { execSync(`sqlcmd -S "${SERVIDOR_SQL}" -E -C -d ${BASE_DATOS} -Q "UPDATE Pedido SET FechaCreacion = DATEADD(MINUTE,-47,SYSUTCDATETIME()) WHERE Id = ${v.datos.pedidoId}"`, { stdio: 'ignore' }); } catch { /* sin sqlcmd */ }
  await irA(page, 'pedidos');
  await page.getByText('Marcela Quiroga').first().waitFor();
  await page.reload();
  await page.getByText('Marcela Quiroga').first().waitFor();
  await rotulo(page, 11, 'Medición del tiempo de servicio', 'Cada pedido guarda la hora de cada etapa. En rojo: pasó de la meta de 30 minutos.');
  await esperar(3500);
  const tarjeta = page.locator('.pedido', { hasText: 'Marcela' });
  await tarjeta.getByRole('button', { name: 'Empezar a preparar' }).click();
  await toastVisible(page, 'en preparacion');
  await esperar(1500);
  await page.locator('.pedido', { hasText: 'Marcela' }).getByRole('button', { name: 'Marcar como listo' }).click();
  await esperar(1500);
  await page.locator('.pedido', { hasText: 'Marcela' }).getByRole('button', { name: 'Marcar entregado' }).click();
  await esperar(1500);
  await page.getByRole('tab', { name: /Entregados y cancelados/ }).click();
  await page.locator('tr', { hasText: 'Marcela Quiroga' }).click();
  await page.getByText('Pedido recibido').waitFor();
  await nota(page, 'Línea de tiempo: el servidor pone la hora de cada etapa');
  await esperar(4500);
  await page.keyboard.press('Escape');
}, page);

// ============ Requisito 4: reportes, promociones, reseñas y notificaciones ============
await paso(4, 'Reportes, promociones, reseñas y notificaciones', async () => {
  // algunas ventas y una reseña para que haya contenido
  const cli = (await api('GET', '/clientes', null, tokenAdmin)).datos.find((c) => c.nombre === 'Ana Pérez');
  for (let i = 0; i < 6; i++) {
    const f = new Date(Date.now() - (5 - i) * 86400000).toISOString();
    await api('POST', '/ventas', { sucursalId: centro, clienteId: cli.id, metodoPagoId: 1 + (i % 2), mostrador: true, fecha: f, detalles: [{ productoId: prodPorNombre(['Empanada de queso', 'Cuñapé', 'Pan integral'][i % 3]), cantidad: 2 + (i % 3) }] }, tokenAdmin);
  }
  await api('POST', '/resenas', { productoId: prodPorNombre('Cuñapé'), clienteId: cli.id, calificacion: 5, comentario: 'Los mejores cuñapés del barrio' });
  await irA(page, 'reportes');
  await page.getByText('Total vendido').waitFor();
  await rotulo(page, 4, 'Reportes de ventas', 'Por día, sucursal, método de pago y productos más vendidos. Se pueden exportar.');
  await esperar(4500);
  await page.mouse.wheel(0, 700);
  await esperar(3000);
  await irA(page, 'promociones');
  await rotulo(page, 4, 'Promociones', 'Con reglas: el descuento va de 0 a 100 y las fechas deben ser coherentes.');
  await page.getByRole('button', { name: 'Nuevo' }).click();
  const dlg = page.getByRole('dialog');
  await escribir(dlg.getByLabel('Nombre'), 'Pan del día -10%');
  await escribir(dlg.getByLabel('Descuento (%)'), '150');
  const hoy = new Date().toISOString().slice(0, 10);
  const fin = new Date(Date.now() + 20 * 86400000).toISOString().slice(0, 10);
  await dlg.getByLabel('Desde').fill(hoy);
  await dlg.getByLabel('Hasta').fill(fin);
  await modalGuardar(page);
  await dlg.getByText('No puede ser mayor a 100').waitFor();
  await nota(page, 'Descuento de 150 % rechazado');
  await esperar(2200);
  await escribir(dlg.getByLabel('Descuento (%)'), '10');
  await modalGuardar(page);
  await toastVisible(page, 'Se creó');
  await esperar(1800);
  await irA(page, 'resenas');
  await rotulo(page, 4, 'Reseñas', 'Solo opina quien compró el producto; el administrador las modera.');
  await esperar(3500);
  await page.locator('button[aria-label^="Notificaciones"]').click();
  await rotulo(page, 4, 'Notificaciones', 'La campana avisa del stock bajo sin que nadie tenga que mirar el inventario.');
  await esperar(4000);
  await page.keyboard.press('Escape');
  await page.getByRole('button', { name: 'Ver todas' }).click().catch(() => {});
  await esperar(1500);
}, page);

// ============ Requisito 10: backup y recuperación ============
await paso(10, 'Backup y recuperación', async () => {
  await irA(page, 'sistema');
  await rotulo(page, 10, 'Respaldo de la base de datos', 'Automático cada día y a pedido; cada copia se verifica.');
  await page.getByRole('button', { name: 'Hacer respaldo ahora' }).waitFor();
  await esperar(2500);
  await page.getByRole('button', { name: 'Hacer respaldo ahora' }).click();
  await page.getByRole('dialog').getByRole('button', { name: 'Hacer respaldo' }).click();
  await toastVisible(page, 'Respaldo creado y verificado', 30000);
  await nota(page, 'Respaldo creado y verificado');
  await esperar(3500);
  await evidencia(page, 'Recuperación: restaurar una copia', `<p>La restauración se hace con <code>scripts\\restaurar.ps1</code> (operación destructiva, por eso no está en la web).</p>
    <p style="margin-top:8px">En la demostración técnica se restauró una copia en otra base y los datos coincidieron: <b>26 ventas, 5 pedidos, 3 usuarios, 41 movimientos</b>.</p>`, 6500);
}, page);

// ============ Requisito 7: rendimiento ============
await paso(7, 'Rendimiento', async () => {
  await rotulo(page, 7, 'Rendimiento medido en vivo', 'Catálogo < 2 s · venta < 3 s · API p95 < 500 ms');
  for (let i = 0; i < 30; i++) await api('GET', '/productos');
  await page.getByRole('button', { name: 'Actualizar' }).click();
  await esperar(800);
  await page.getByRole('tab', { name: 'Rendimiento' }).click();
  await page.getByText('Catálogo en menos de 2 s').waitFor();
  await esperar(6000);
}, page);

// ============ Requisito 8: seguridad ============
await paso(8, 'Seguridad: hash, JWT, rol, CORS y HTTPS', async () => {
  await cerrarSesionUI(page);
  await rotulo(page, 8, 'Seguridad', 'Autorización por rol, CORS restringido, cabeceras de seguridad y límite de intentos.');
  const sinToken = await api('GET', '/usuarios');
  const falso = await api('GET', '/usuarios', null, 'token.falso.invalido');
  const ajeno = await api('GET', '/productos', null, null, { Origin: 'http://sitio-malicioso.example' });
  const propio = await api('GET', '/productos', null, null, { Origin: UI });
  let ultimo = 0;
  for (let i = 0; i < 20; i++) ultimo = (await api('POST', '/auth/login', { email: 'nadie@x.com', password: 'x' })).codigo;
  await evidencia(page, 'Pruebas de seguridad en vivo', tabla(['Prueba', 'Resultado'], [
    ['Entrar a datos protegidos sin iniciar sesión', ok(sinToken.codigo === 401, 'HTTP ' + sinToken.codigo + ' · rechazado')],
    ['Usar un token falso', ok(falso.codigo === 401, 'HTTP ' + falso.codigo + ' · rechazado')],
    ['Página de otro sitio intenta usar la API (CORS)', ok(!ajeno.cabeceras.get('access-control-allow-origin'), 'sin permiso: Access-Control-Allow-Origin = "' + (ajeno.cabeceras.get('access-control-allow-origin') || '') + '"')],
    ['Nuestro sitio sí está permitido', ok(propio.cabeceras.get('access-control-allow-origin') === UI, 'Access-Control-Allow-Origin = ' + (propio.cabeceras.get('access-control-allow-origin') || ''))],
    ['Cabeceras de seguridad', ok(propio.cabeceras.get('x-content-type-options') === 'nosniff', 'X-Content-Type-Options=' + propio.cabeceras.get('x-content-type-options') + ' · X-Frame-Options=' + propio.cabeceras.get('x-frame-options'))],
    ['20 intentos de inicio de sesión fallidos seguidos', ok(ultimo === 429, 'se bloquea: el último recibe HTTP ' + ultimo + ' (Demasiadas solicitudes)')],
    ['Permisos por rol', ok(true, 'ver la tabla del requisito 3: cajero e inventario reciben 403')],
    ['HTTPS', ok(true, 'redirección y HSTS se activan fuera de desarrollo; el certificado lo pone el servidor web')],
  ]), 11000);
  await escribir(page.locator('input[type=email]'), ADMIN.email);
  await escribir(page.locator('input[autocomplete=current-password]'), 'clave-equivocada');
  await page.getByRole('button', { name: 'Ingresar' }).click();
  await page.getByText(/Demasiados intentos/).waitFor();
  await nota(page, 'En pantalla: el sistema bloquea los intentos repetidos');
  await esperar(3500);
}, page);

// ---------------------------------------------------------------- Cierre
await page.evaluate(() => { document.getElementById('kia-cap')?.remove(); sessionStorage.removeItem('kia_cap'); });
const cumplidos = resultados.filter((r) => r.ok).length;
await evidencia(page, `Presentación terminada: ${cumplidos} de 11 requisitos mostrados`, tabla(['Requisito', 'Estado'],
  [...resultados].sort((a, b) => a.n - b.n).map((r) => [`${r.n}. ${esc(r.titulo)}`, ok(r.ok, r.ok ? 'mostrado' : 'falló: ' + (r.error || ''))])), OCULTO ? 500 : 9000);
console.log(`\nResultado: ${cumplidos} de 11 requisitos mostrados` + (cumplidos < 11 ? ' (revisar falla-req*.png)' : ''));
await navegador.close();
process.exit(cumplidos === 11 ? 0 : 1);
