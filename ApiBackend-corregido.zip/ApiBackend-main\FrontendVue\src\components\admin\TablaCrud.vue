<script setup>
// CRUD genérico: lista con búsqueda, orden y paginación + formulario en modal con validación.
// Se configura con los campos (ver src/modulos.js).
import { ref, computed, onMounted, watch } from 'vue';
import api from '@/api/axios';
import { toast, confirmar } from '@/ui/feedback';
import { bs, fechaCorta, mensajeError, descargarCsv } from '@/utils/format';
import AppIcon from '@/ui/AppIcon.vue';
import AppModal from '@/ui/AppModal.vue';
import Campo from '@/ui/Campo.vue';
import EncabezadoPagina from '@/ui/EncabezadoPagina.vue';
import EstadoVacio from '@/ui/EstadoVacio.vue';
import Insignia from '@/ui/Insignia.vue';

const props = defineProps({
  titulo: String,
  subtitulo: String,
  endpoint: String, // ej: '/sucursales'
  campos: { type: Array, default: () => [] },
  nuevoModelo: Function, // devuelve un objeto con los valores iniciales
  sinCrear: Boolean, // oculta "Nuevo" (ej: reseñas, que las escriben los clientes)
  nombreItem: { type: String, default: 'registro' },
});

const items = ref([]);
const cargando = ref(true);
const errorCarga = ref('');

// ----- Lista: búsqueda, orden y paginación -----
const busqueda = ref('');
const orden = ref({ campo: null, asc: true });
const pagina = ref(1);
const porPagina = ref(10);

const columnas = computed(() => props.campos.filter((c) => !c.ocultarEnTabla));
const camposForm = computed(() => props.campos.filter((c) => !c.ocultarEnForm));

function textoCelda(item, c) {
  const v = item[c.campo];
  if (c.tipo === 'select') return c.opciones?.find((o) => o.valor === v)?.texto ?? (v ?? '—');
  if (c.tipo === 'checkbox') return v ? 'Sí' : 'No';
  if (c.tipo === 'money') return bs(v);
  if (c.tipo === 'date') return v ? fechaCorta(String(v).slice(0, 10) + 'T12:00:00') : '—';
  if (c.tipo === 'number' && c.campo.toLowerCase().includes('descuento')) return v + ' %';
  return v === null || v === undefined || v === '' ? '—' : v;
}

const filtrados = computed(() => {
  const t = busqueda.value.trim().toLowerCase();
  let lista = items.value;
  if (t) lista = lista.filter((it) => props.campos.some((c) => c.tipo !== 'password' && String(textoCelda(it, c)).toLowerCase().includes(t)));
  if (orden.value.campo) {
    const c = props.campos.find((x) => x.campo === orden.value.campo);
    const dir = orden.value.asc ? 1 : -1;
    lista = [...lista].sort((a, b) => {
      const va = c.tipo === 'select' || c.tipo === 'checkbox' ? String(textoCelda(a, c)) : a[c.campo];
      const vb = c.tipo === 'select' || c.tipo === 'checkbox' ? String(textoCelda(b, c)) : b[c.campo];
      if (va == null) return 1;
      if (vb == null) return -1;
      return (typeof va === 'number' && typeof vb === 'number' ? va - vb : String(va).localeCompare(String(vb), 'es', { numeric: true })) * dir;
    });
  }
  return lista;
});

const totalPaginas = computed(() => Math.max(1, Math.ceil(filtrados.value.length / porPagina.value)));
const visibles = computed(() => filtrados.value.slice((pagina.value - 1) * porPagina.value, pagina.value * porPagina.value));
watch([busqueda, porPagina], () => (pagina.value = 1));
watch(totalPaginas, (t) => { if (pagina.value > t) pagina.value = t; });

function ordenarPor(c) {
  if (c.tipo === 'password') return;
  orden.value = orden.value.campo === c.campo ? { campo: c.campo, asc: !orden.value.asc } : { campo: c.campo, asc: true };
}
function iconoOrden(c) {
  if (orden.value.campo !== c.campo) return 'sort';
  return orden.value.asc ? 'arrowUp' : 'arrowDown';
}

async function cargar() {
  cargando.value = true;
  errorCarga.value = '';
  try {
    items.value = (await api.get(props.endpoint)).data || [];
  } catch (e) {
    errorCarga.value = mensajeError(e, 'No se pudo cargar la información.');
  } finally {
    cargando.value = false;
  }
}

// ----- Formulario -----
const modalAbierto = ref(false);
const editando = ref(null); // item en edición (null = nuevo)
const form = ref({});
const errores = ref({});
const guardando = ref(false);

function abrirNuevo() {
  editando.value = null;
  form.value = props.nuevoModelo ? props.nuevoModelo() : {};
  errores.value = {};
  modalAbierto.value = true;
}
function abrirEditar(item) {
  editando.value = item;
  form.value = { ...item };
  props.campos.filter((c) => c.tipo === 'date').forEach((c) => (form.value[c.campo] = String(form.value[c.campo] || '').slice(0, 10)));
  props.campos.filter((c) => c.tipo === 'password').forEach((c) => (form.value[c.campo] = ''));
  errores.value = {};
  modalAbierto.value = true;
}

function validar() {
  const e = {};
  for (const c of camposForm.value) {
    const v = form.value[c.campo];
    const vacio = v === null || v === undefined || (typeof v === 'string' && !v.trim());
    const obligatorio = c.requerido || (c.requeridoAlCrear && !editando.value);
    if (obligatorio && c.tipo !== 'checkbox' && vacio) {
      e[c.campo] = 'Este dato es obligatorio.';
      continue;
    }
    if (vacio) continue;
    if (c.tipo === 'number' || c.tipo === 'money') {
      const n = Number(v);
      if (isNaN(n)) e[c.campo] = 'Tiene que ser un número.';
      else if (c.min !== undefined && n < c.min) e[c.campo] = `No puede ser menor a ${c.min}.`;
      else if (c.max !== undefined && n > c.max) e[c.campo] = `No puede ser mayor a ${c.max}.`;
    }
    if (c.tipo === 'password' && (v.length < 8 || !/[A-Z]/.test(v) || !/[a-z]/.test(v) || !/\d/.test(v))) {
      e[c.campo] = 'Mínimo 8 caracteres con mayúscula, minúscula y número.';
    }
    if (/correo|email/i.test(c.campo + c.etiqueta) && c.tipo === 'text' && !/^\S+@\S+\.\S+$/.test(v)) {
      e[c.campo] = 'Escribí un correo válido.';
    }
  }
  const fi = camposForm.value.find((c) => c.campo === 'fechaInicio');
  const ff = camposForm.value.find((c) => c.campo === 'fechaFin');
  if (fi && ff && form.value.fechaInicio && form.value.fechaFin && form.value.fechaFin < form.value.fechaInicio) {
    e.fechaFin = 'La fecha final no puede ser anterior a la inicial.';
  }
  errores.value = e;
  return Object.keys(e).length === 0;
}

async function guardar() {
  if (!validar()) return;
  guardando.value = true;
  try {
    const cuerpo = { ...form.value };
    props.campos.forEach((c) => {
      if (c.tipo === 'number' || c.tipo === 'money') cuerpo[c.campo] = cuerpo[c.campo] === '' || cuerpo[c.campo] == null ? 0 : Number(cuerpo[c.campo]);
      if (typeof cuerpo[c.campo] === 'string') cuerpo[c.campo] = cuerpo[c.campo].trim();
    });
    if (editando.value) {
      await api.put(`${props.endpoint}/${editando.value.id}`, cuerpo);
      toast.ok('Cambios guardados.');
    } else {
      await api.post(props.endpoint, cuerpo);
      toast.ok(`Se creó ${props.nombreItem === 'registro' ? 'el registro' : 'el ' + props.nombreItem}.`);
    }
    modalAbierto.value = false;
    await cargar();
  } catch (e) {
    toast.error(mensajeError(e, 'No se pudo guardar. Revisá los datos.'));
  } finally {
    guardando.value = false;
  }
}

async function eliminar(item) {
  const nombre = item.nombre || item.email || `#${item.id}`;
  const si = await confirmar({
    titulo: `Eliminar ${props.nombreItem}`,
    mensaje: `¿Seguro que querés eliminar "${nombre}"? Esta acción no se puede deshacer.`,
    textoOk: 'Eliminar',
    peligro: true,
  });
  if (!si) return;
  try {
    await api.delete(`${props.endpoint}/${item.id}`);
    toast.ok('Eliminado.');
    await cargar();
  } catch (e) {
    toast.error(mensajeError(e, 'No se pudo eliminar. Puede estar en uso por otros registros.'));
  }
}

function exportar() {
  const filas = [columnas.value.map((c) => c.etiqueta), ...filtrados.value.map((it) => columnas.value.map((c) => textoCelda(it, c)))];
  descargarCsv(`${props.titulo.toLowerCase().replace(/\s+/g, '-')}.csv`, filas);
}

watch(() => props.endpoint, () => { busqueda.value = ''; orden.value = { campo: null, asc: true }; cargar(); });
onMounted(cargar);
</script>

<template>
  <div>
    <EncabezadoPagina :titulo="titulo" :subtitulo="subtitulo">
      <button type="button" class="btn btn-secundario" :disabled="cargando || !filtrados.length" @click="exportar">
        <AppIcon name="download" :size="16" /> Exportar
      </button>
      <button v-if="!sinCrear" type="button" class="btn btn-primario" @click="abrirNuevo">
        <AppIcon name="plus" :size="16" /> Nuevo
      </button>
    </EncabezadoPagina>

    <div v-if="errorCarga" class="aviso-linea error" role="alert" style="margin-bottom: 16px">
      <AppIcon name="alert" :size="18" /> <span class="crece">{{ errorCarga }}</span>
      <button type="button" class="btn btn-secundario btn-sm" @click="cargar">Reintentar</button>
    </div>

    <div class="tarjeta">
      <div class="herramientas">
        <div class="entrada-icono buscador">
          <AppIcon name="search" :size="17" class="icono-izq" />
          <input v-model="busqueda" type="search" placeholder="Buscar..." aria-label="Buscar en la tabla" />
        </div>
        <span class="texto-suave texto-chico">{{ filtrados.length }} {{ filtrados.length === 1 ? 'resultado' : 'resultados' }}</span>
      </div>

      <div v-if="cargando" class="tabla-contenedor" aria-busy="true">
        <table class="tabla">
          <tbody>
            <tr v-for="n in 5" :key="n">
              <td v-for="c in columnas.length + 1" :key="c"><span class="esqueleto"></span></td>
            </tr>
          </tbody>
        </table>
      </div>

      <EstadoVacio
        v-else-if="items.length === 0 && !errorCarga"
        icono="package"
        :titulo="`Todavía no hay ${titulo.toLowerCase()}`"
        :texto="sinCrear ? 'Cuando haya datos van a aparecer acá.' : 'Creá el primero para empezar.'"
      >
        <button v-if="!sinCrear" type="button" class="btn btn-primario" @click="abrirNuevo"><AppIcon name="plus" :size="16" /> Crear {{ nombreItem }}</button>
      </EstadoVacio>

      <EstadoVacio v-else-if="filtrados.length === 0" icono="search" titulo="Sin resultados" :texto="`No encontramos nada para “${busqueda}”.`">
        <button type="button" class="btn btn-secundario" @click="busqueda = ''">Limpiar búsqueda</button>
      </EstadoVacio>

      <template v-else>
        <div class="tabla-contenedor">
          <table class="tabla">
            <thead>
              <tr>
                <th
                  v-for="c in columnas"
                  :key="c.campo"
                  :class="{ ordenable: c.tipo !== 'password' }"
                  :aria-sort="orden.campo === c.campo ? (orden.asc ? 'ascending' : 'descending') : 'none'"
                  @click="ordenarPor(c)"
                >
                  <span class="fila" style="gap: 4px">{{ c.etiqueta }} <AppIcon v-if="c.tipo !== 'password'" :name="iconoOrden(c)" :size="13" /></span>
                </th>
                <th class="acciones">Acciones</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="it in visibles" :key="it.id">
                <td v-for="c in columnas" :key="c.campo" :class="{ num: c.tipo === 'money' || c.tipo === 'number' }">
                  <Insignia v-if="c.tipo === 'checkbox'" :tono="it[c.campo] ? 'ok' : ''">{{ it[c.campo] ? 'Sí' : 'No' }}</Insignia>
                  <span v-else>{{ textoCelda(it, c) }}</span>
                </td>
                <td class="acciones">
                  <button type="button" class="btn btn-secundario btn-sm" :aria-label="`Editar ${it.nombre || it.id}`" @click="abrirEditar(it)">
                    <AppIcon name="edit" :size="15" /> <span class="oculto-movil">Editar</span>
                  </button>
                  <button type="button" class="btn btn-peligro btn-sm btn-icono" :aria-label="`Eliminar ${it.nombre || it.id}`" @click="eliminar(it)">
                    <AppIcon name="trash" :size="15" />
                  </button>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
        <div class="paginacion">
          <label class="fila texto-chico" style="gap: 8px">
            Filas
            <select v-model.number="porPagina" style="width: auto; min-height: 32px; padding: 4px 8px">
              <option :value="10">10</option><option :value="25">25</option><option :value="50">50</option>
            </select>
          </label>
          <span>Página {{ pagina }} de {{ totalPaginas }}</span>
          <div class="fila" style="gap: 6px">
            <button type="button" class="btn btn-secundario btn-sm btn-icono" aria-label="Página anterior" :disabled="pagina <= 1" @click="pagina--"><AppIcon name="chevronLeft" :size="16" /></button>
            <button type="button" class="btn btn-secundario btn-sm btn-icono" aria-label="Página siguiente" :disabled="pagina >= totalPaginas" @click="pagina++"><AppIcon name="chevronRight" :size="16" /></button>
          </div>
        </div>
      </template>
    </div>

    <AppModal v-model="modalAbierto" :titulo="(editando ? 'Editar ' : 'Nuevo ') + nombreItem">
      <form id="form-crud" class="formulario" novalidate @submit.prevent="guardar">
        <template v-for="c in camposForm" :key="c.campo">
          <label v-if="c.tipo === 'checkbox'" class="opcion-check">
            <input v-model="form[c.campo]" type="checkbox" />
            <span><strong>{{ c.etiqueta }}</strong><br /><span v-if="c.ayuda" class="texto-tenue texto-chico">{{ c.ayuda }}</span></span>
          </label>

          <Campo v-else :label="c.etiqueta" :requerido="c.requerido || (c.requeridoAlCrear && !editando)" :ayuda="c.ayuda" :error="errores[c.campo]" v-slot="{ id, invalido }">
            <select v-if="c.tipo === 'select'" :id="id" v-model="form[c.campo]" :aria-invalid="invalido">
              <option :value="null" disabled>Elegí una opción</option>
              <option v-for="o in c.opciones" :key="o.valor" :value="o.valor">{{ o.texto }}</option>
            </select>
            <textarea v-else-if="c.tipo === 'textarea'" :id="id" v-model="form[c.campo]" rows="3" :maxlength="c.maxlength" :aria-invalid="invalido"></textarea>
            <input
              v-else
              :id="id"
              v-model="form[c.campo]"
              :type="c.tipo === 'number' || c.tipo === 'money' ? 'number' : c.tipo === 'password' ? 'password' : c.tipo === 'date' ? 'date' : 'text'"
              :step="c.tipo === 'money' ? '0.01' : c.tipo === 'number' ? 'any' : undefined"
              :min="c.min"
              :max="c.max"
              :maxlength="c.maxlength"
              :autocomplete="c.tipo === 'password' ? 'new-password' : 'off'"
              :aria-invalid="invalido"
            />
          </Campo>
        </template>
      </form>
      <template #pie>
        <button type="button" class="btn btn-secundario" @click="modalAbierto = false">Cancelar</button>
        <button type="submit" form="form-crud" class="btn btn-primario" :disabled="guardando">{{ guardando ? 'Guardando...' : 'Guardar' }}</button>
      </template>
    </AppModal>
  </div>
</template>

<style scoped>
.herramientas { display: flex; align-items: center; justify-content: space-between; gap: 12px; padding: 14px 16px; border-bottom: 1px solid var(--borde); flex-wrap: wrap; }
.buscador { width: min(340px, 100%); }
</style>
