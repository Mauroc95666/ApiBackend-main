using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BackendApi.Models
{
    [Table("Pedido")]
    public class Pedido
    {
        [Key]
        [Column("Id")]
        public int Id { get; set; }

        [Column("VentaId")]
        public int VentaId { get; set; }

        public Venta Venta { get; set; } = null!;

        [Column("Estado")]
        public string Estado { get; set; } = "PENDIENTE";

        [Column("FechaEntrega")]
        public DateTime? FechaEntrega { get; set; }

        // Req. 2: RETIRO (el cliente pasa a buscarlo) o DELIVERY (se envía a DireccionEntrega).
        [Column("Modalidad")]
        public string Modalidad { get; set; } = "RETIRO";

        [Column("DireccionEntrega")]
        public string? DireccionEntrega { get; set; }

        // Req. 11: marcas de tiempo de cada etapa (UTC) para medir el tiempo de servicio.
        [Column("FechaCreacion")]
        public DateTime FechaCreacion { get; set; } = DateTime.UtcNow;

        [Column("FechaPreparacion")]
        public DateTime? FechaPreparacion { get; set; }

        [Column("FechaListo")]
        public DateTime? FechaListo { get; set; }

        [Column("FechaEntregado")]
        public DateTime? FechaEntregado { get; set; }

        // Minutos desde que entró el pedido hasta que se entregó (null si aún está en curso).
        [NotMapped]
        public double? TiempoServicioMinutos =>
            FechaEntregado.HasValue ? Math.Round((FechaEntregado.Value - FechaCreacion).TotalMinutes, 1) : null;
    }
}