using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.EntityFrameworkCore;
using BackendApi.Models;
using BackendApi.Services;

namespace BackendApi.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize(Policy = "Ventas")]
public class ClientesController : ControllerBase
{
    private readonly ApplicationDbContext _context;
    private readonly AuditoriaService _auditoria;

    public ClientesController(ApplicationDbContext context, AuditoriaService auditoria)
    {
        _context = context;
        _auditoria = auditoria;
    }

    [HttpGet]
    public async Task<IActionResult> ObtenerClientes()
    {
        var clientes = await _context.Clientes.AsNoTracking().ToListAsync();
        return Ok(clientes);
    }

    [HttpGet("{id}")]
    public async Task<IActionResult> ObtenerClientePorId(int id)
    {
        var cliente = await _context.Clientes.AsNoTracking().FirstOrDefaultAsync(c => c.Id == id);

        if (cliente == null)
            return NotFound(new { mensaje = $"Cliente con id {id} no encontrado" });

        return Ok(cliente);
    }

    // Público: la tienda registra al cliente al comprar. Ley 164: para guardar datos personales
    // de un visitante hace falta su consentimiento (la tienda manda consentimientoFecha al aceptar).
    [AllowAnonymous]
    [EnableRateLimiting("publico")]
    [HttpPost]
    public async Task<IActionResult> CrearCliente([FromBody] Cliente nuevoCliente)
    {
        if (nuevoCliente == null)
            return BadRequest(new { mensaje = "Los datos del cliente son requeridos" });

        if (string.IsNullOrWhiteSpace(nuevoCliente.Nombre))
            return BadRequest(new { mensaje = "El nombre del cliente es requerido" });

        var esPersonal = User.Identity?.IsAuthenticated == true && RolHelper.PuedeVentas(User.FindFirst(System.Security.Claims.ClaimTypes.Role)?.Value);
        if (!esPersonal && nuevoCliente.ConsentimientoFecha == null)
            return BadRequest(new { mensaje = "Hace falta aceptar el tratamiento de datos personales para registrar la compra" });

        nuevoCliente.Id = 0;
        nuevoCliente.Emprendimiento = null!;
        nuevoCliente.Anonimizado = false;
        // La fecha de aceptación la fija el servidor, no el navegador.
        nuevoCliente.ConsentimientoFecha = nuevoCliente.ConsentimientoFecha == null ? null : DateTime.UtcNow;

        _context.Clientes.Add(nuevoCliente);
        await _context.SaveChangesAsync();

        return CreatedAtAction(nameof(ObtenerClientePorId), new { id = nuevoCliente.Id }, nuevoCliente);
    }

    [HttpPut("{id}")]
    public async Task<IActionResult> ActualizarCliente(int id, [FromBody] Cliente clienteActualizado)
    {
        var cliente = await _context.Clientes.FindAsync(id);

        if (cliente == null)
            return NotFound(new { mensaje = $"Cliente con id {id} no encontrado" });
        if (cliente.Anonimizado)
            return Conflict(new { mensaje = "El cliente fue anonimizado y no se puede modificar" });

        cliente.EmprendimientoId = clienteActualizado.EmprendimientoId;
        cliente.Nombre = clienteActualizado.Nombre;
        cliente.CI_NIT = clienteActualizado.CI_NIT;
        cliente.Telefono = clienteActualizado.Telefono;
        cliente.Email = clienteActualizado.Email;
        cliente.Direccion = clienteActualizado.Direccion;

        await _context.SaveChangesAsync();
        await _auditoria.RegistrarAsync("ACTUALIZAR", "Cliente", $"Cliente {id}");

        return Ok(new { mensaje = "Cliente actualizado correctamente", cliente });
    }

    // Ley 164 – derecho de acceso: todo lo que el sistema guarda de una persona.
    [Authorize(Policy = "Admin")]
    [HttpGet("{id}/datos")]
    public async Task<IActionResult> DatosPersonales(int id)
    {
        var cliente = await _context.Clientes.AsNoTracking().FirstOrDefaultAsync(c => c.Id == id);
        if (cliente == null)
            return NotFound(new { mensaje = $"Cliente con id {id} no encontrado" });

        var compras = await _context.Ventas.AsNoTracking().Where(v => v.ClienteId == id)
            .Select(v => new { v.Id, v.Fecha, v.Total, v.SucursalId }).ToListAsync();
        var resenas = await _context.Resenas.AsNoTracking().Where(r => r.ClienteId == id)
            .Select(r => new { r.Id, r.ProductoId, r.Calificacion, r.Comentario, r.Fecha }).ToListAsync();

        await _auditoria.RegistrarAsync("ACCESO_DATOS_PERSONALES", "Cliente", $"Consulta de los datos del cliente {id}");
        return Ok(new { cliente, compras, resenas });
    }

    // Ley 164 – derecho de cancelación: se borran los datos personales pero se conservan las ventas
    // (son registros contables) apuntando a un cliente ya anonimizado.
    [Authorize(Policy = "Admin")]
    [HttpPost("{id}/anonimizar")]
    public async Task<IActionResult> Anonimizar(int id)
    {
        var cliente = await _context.Clientes.FindAsync(id);
        if (cliente == null)
            return NotFound(new { mensaje = $"Cliente con id {id} no encontrado" });
        if (cliente.Anonimizado)
            return Ok(new { mensaje = "El cliente ya estaba anonimizado" });

        cliente.Nombre = "Cliente anonimizado";
        cliente.CI_NIT = null;
        cliente.Telefono = null;
        cliente.Email = null;
        cliente.Direccion = null;
        cliente.Anonimizado = true;

        // Los comentarios de reseñas también pueden contener datos personales.
        var resenas = await _context.Resenas.Where(r => r.ClienteId == id).ToListAsync();
        foreach (var r in resenas) r.Comentario = null;

        await _context.SaveChangesAsync();
        await _auditoria.RegistrarAsync("ANONIMIZAR", "Cliente", $"Cliente {id} anonimizado a pedido del titular");

        return Ok(new { mensaje = "Datos personales eliminados. Las ventas se conservan sin datos identificables." });
    }

    [Authorize(Policy = "Admin")]
    [HttpDelete("{id}")]
    public async Task<IActionResult> EliminarCliente(int id)
    {
        var cliente = await _context.Clientes.FindAsync(id);

        if (cliente == null)
            return NotFound(new { mensaje = $"Cliente con id {id} no encontrado" });

        _context.Clientes.Remove(cliente);
        await _context.SaveChangesAsync();
        await _auditoria.RegistrarAsync("ELIMINAR", "Cliente", $"Cliente {id}");

        return Ok(new { mensaje = $"Cliente {id} eliminado correctamente" });
    }
}
