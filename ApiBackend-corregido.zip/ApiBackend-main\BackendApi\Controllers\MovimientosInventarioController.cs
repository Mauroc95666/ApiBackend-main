using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using BackendApi.Models;
using BackendApi.Services;

namespace BackendApi.Controllers;

// Historial de entradas y salidas. Es un registro de auditoría: se consulta y se agrega,
// pero no se edita ni se borra (un error se corrige con un movimiento contrario).
[ApiController]
[Route("api/[controller]")]
[Authorize(Policy = "Inventario")]
public class MovimientosInventarioController : ControllerBase
{
    private readonly ApplicationDbContext _context;
    private readonly InventarioService _inventario;

    public MovimientosInventarioController(ApplicationDbContext context, InventarioService inventario)
    {
        _context = context;
        _inventario = inventario;
    }

    private IQueryable<MovimientoInventario> Visibles()
    {
        var q = _context.MovimientoInventario.AsNoTracking().AsQueryable();
        var restringida = RolHelper.SucursalRestringida(User);
        return restringida.HasValue ? q.Where(m => m.Inventario.SucursalId == restringida.Value) : q;
    }

    [HttpGet]
    public async Task<IActionResult> ObtenerMovimientos([FromQuery] int? inventarioId, [FromQuery] DateTime? desde, [FromQuery] DateTime? hasta)
    {
        var q = Visibles();
        if (inventarioId.HasValue) q = q.Where(m => m.InventarioId == inventarioId.Value);
        if (desde.HasValue) q = q.Where(m => m.Fecha >= desde.Value);
        if (hasta.HasValue) q = q.Where(m => m.Fecha <= hasta.Value);
        return Ok(await q.OrderByDescending(m => m.Fecha).Take(1000).ToListAsync());
    }

    [HttpGet("{id}")]
    public async Task<IActionResult> ObtenerMovimientoPorId(int id)
    {
        var movimiento = await Visibles().FirstOrDefaultAsync(m => m.Id == id);

        if (movimiento == null)
            return NotFound(new { mensaje = $"Movimiento con id {id} no encontrado" });

        return Ok(movimiento);
    }

    // Aplica el movimiento al stock (el usuario sale del token, no del cuerpo).
    [HttpPost]
    public async Task<IActionResult> CrearMovimiento([FromBody] MovimientoInventario nuevo)
    {
        if (nuevo == null)
            return BadRequest(new { mensaje = "Los datos del movimiento son requeridos" });

        var usuarioId = RolHelper.UsuarioId(User);
        if (usuarioId is null or 0) return Forbid();

        var r = await _inventario.AplicarMovimientoAsync(nuevo.InventarioId, nuevo.Tipo, nuevo.Cantidad, nuevo.Motivo, usuarioId.Value, RolHelper.SucursalRestringida(User));
        if (!r.Ok) return StatusCode(r.Codigo, new { mensaje = r.Mensaje });

        return CreatedAtAction(nameof(ObtenerMovimientoPorId), new { id = r.Movimiento!.Id },
            new { r.Movimiento.Id, r.Movimiento.InventarioId, r.Movimiento.UsuarioId, r.Movimiento.Tipo, r.Movimiento.Cantidad, r.Movimiento.Fecha, r.Movimiento.Motivo, stockActual = r.StockActual });
    }

    [HttpPut("{id}")]
    public IActionResult ActualizarMovimiento(int id) =>
        StatusCode(405, new { mensaje = "Los movimientos no se editan. Registrá un movimiento contrario para corregir." });

    [HttpDelete("{id}")]
    public IActionResult EliminarMovimiento(int id) =>
        StatusCode(405, new { mensaje = "Los movimientos no se eliminan. Registrá un movimiento contrario para corregir." });
}
