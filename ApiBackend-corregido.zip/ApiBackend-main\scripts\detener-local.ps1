<#
.SYNOPSIS
  Detiene el backend y el frontend iniciados con iniciar-local.ps1.
  Solo cierra los procesos de este proyecto (no toca otros procesos de Node o .NET).
#>
$raiz = Split-Path -Parent $PSScriptRoot
Get-CimInstance Win32_Process | Where-Object {
    $_.CommandLine -and $_.CommandLine -like "*$raiz*" -and ($_.Name -in 'dotnet.exe', 'node.exe')
} | ForEach-Object {
    Write-Host "Deteniendo $($_.Name) ($($_.ProcessId))"
    Stop-Process -Id $_.ProcessId -Force
}
