using System.Security.Claims;
using BackendApi.Models;

namespace BackendApi.Services;

// Registra en la tabla Auditoria las acciones sensibles (quién, qué, cuándo).
// Pensado para trazabilidad y para cumplir con el deber de control sobre datos personales (Ley 164).
public class AuditoriaService
{
    private readonly ApplicationDbContext _context;
    private readonly IHttpContextAccessor _http;

    public AuditoriaService(ApplicationDbContext context, IHttpContextAccessor http)
    {
        _context = context;
        _http = http;
    }

    // Guarda de inmediato. Un fallo de auditoría nunca debe tumbar la operación principal.
    public async Task RegistrarAsync(string accion, string tabla, string? detalles = null, int? usuarioId = null)
    {
        try
        {
            usuarioId ??= _http.HttpContext is { } ctx ? RolHelper.UsuarioId(ctx.User) : null;
            _context.Auditorias.Add(new Auditoria
            {
                UsuarioId = usuarioId,
                Accion = accion,
                TablaAfectada = tabla,
                Fecha = DateTime.UtcNow,
                Detalles = detalles,
            });
            await _context.SaveChangesAsync();
        }
        catch
        {
            // Se ignora a propósito (ver comentario arriba).
        }
    }
}
