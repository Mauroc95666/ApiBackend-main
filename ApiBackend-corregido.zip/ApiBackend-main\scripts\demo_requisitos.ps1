﻿<#
.SYNOPSIS
  Demostración en vivo de los 11 requisitos funcionales. Muestra cada paso y su resultado real,
  y deja datos de ejemplo cargados para explorar la interfaz.

.DESCRIPTION
  ATENCIÓN: crea usuarios, productos, ventas y un respaldo. Usalo SOLO contra una base de demostración vacía.
  Preparación (ver scripts/preparar-demo.ps1):  API en $Base con Setup__Usuario / Setup__Clave definidos.
#>
param(
    [string]$Base = "http://localhost:5209",
    [string]$SetupUsuario = "instalador@kiataque.local",
    [string]$SetupClave = "Instal-Demo-2026!",
    [string]$Servidor = ".\SQLEXPRESS",
    [string]$BaseDatos = "DB_Panaderia2_demo"
)
$ErrorActionPreference = 'Continue'
$PassAdmin = "Admin-Demo-2026"; $PassCaja = "Caja-Demo-2026"; $PassInv = "Inv-Demo-2026"

function Call($m, $u, $b, $t, $origen) {
    $h = @{}; if ($t) { $h.Authorization = "Bearer $t" }; if ($origen) { $h.Origin = $origen }
    try {
        $p = @{ Method = $m; Uri = "$Base$u"; Headers = $h; UseBasicParsing = $true; ContentType = 'application/json' }
        if ($null -ne $b) { $p.Body = [Text.Encoding]::UTF8.GetBytes(($b | ConvertTo-Json -Depth 6)) }  # UTF-8 explícito: los acentos viajan bien
        $r = Invoke-WebRequest @p
        return @{ code = [int]$r.StatusCode; body = $(if ($r.Content) { $r.Content | ConvertFrom-Json } else { $null }); raw = $r.Content; headers = $r.Headers }
    } catch {
        $c = $_.Exception.Response; $s = ''
        if ($c) { $s = (New-Object IO.StreamReader($c.GetResponseStream())).ReadToEnd() }
        $j = $null; try { $j = $s | ConvertFrom-Json } catch {}
        return @{ code = [int]$c.StatusCode; body = $j; raw = $s; headers = @{} }
    }
}
function Titulo($n, $t) { Write-Host ""; Write-Host ("=" * 78) -ForegroundColor DarkYellow; Write-Host (" REQUISITO {0}: {1}" -f $n, $t) -ForegroundColor Yellow; Write-Host ("=" * 78) -ForegroundColor DarkYellow }
function Paso($texto, $ok, $detalle) {
    $marca = if ($ok) { "[ OK ]" } else { "[FALLA]" }
    $color = if ($ok) { 'Green' } else { 'Red' }
    Write-Host ("  {0} {1}" -f $marca, $texto) -ForegroundColor $color
    if ($detalle) { Write-Host ("         -> {0}" -f $detalle) -ForegroundColor DarkGray }
    if ($ok) { $script:ok++ } else { $script:fallas++ }
}
function Jwt($token) {
    $p = $token.Split('.')[1].Replace('-', '+').Replace('_', '/'); while ($p.Length % 4) { $p += '=' }
    [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($p)) | ConvertFrom-Json
}
$script:ok = 0; $script:fallas = 0
$hoy = Get-Date

# ---------------------------------------------------------------------------
Titulo 6 "Primer administrador con el super-usuario oculto"
$r = Call POST /api/auth/login @{ email = $SetupUsuario; password = "clave-equivocada" }
Paso "El super-usuario con clave incorrecta es rechazado" ($r.code -eq 401) "HTTP $($r.code): $($r.body.mensaje)"
$r = Call POST /api/auth/login @{ email = $SetupUsuario; password = $SetupClave }
$root = $r.body.token
Paso "El super-usuario entra con su rol especial" ($r.code -eq 200 -and $r.body.rolNombre -eq 'SetupRoot') "rol = $($r.body.rolNombre)"
$r = Call GET /api/usuarios $null $root
Paso "...pero NO puede ver ni tocar nada más (ni siquiera la lista de usuarios)" ($r.code -eq 403) "HTTP $($r.code)"
$r = Call POST /api/setup/primer-admin @{ nombre = 'Admin Demo'; email = 'admin@kiataque.bo'; password = 'debil' } $root
Paso "La contraseña débil se rechaza al crear el administrador" ($r.code -eq 400) $r.body.mensaje
$r = Call POST /api/setup/primer-admin @{ nombre = 'Admin Demo'; email = 'admin@kiataque.bo'; password = $PassAdmin } $root
Paso "Se crea el primer administrador" ($r.code -eq 201) "admin@kiataque.bo (id $($r.body.id))"
$r = Call POST /api/auth/login @{ email = $SetupUsuario; password = $SetupClave }
Paso "Con un administrador creado, el super-usuario deja de funcionar" ($r.code -eq 401) "HTTP $($r.code)"

$r = Call POST /api/auth/login @{ email = 'admin@kiataque.bo'; password = $PassAdmin }
$adm = $r.body.token

# ---------------------------------------------------------------------------
Titulo 5 "Seguridad del modelado: hash, JWT, UNIQUE, CHECK y FKs"
$claims = Jwt $adm
Paso "El JWT lleva el rol, el emisor y el vencimiento" ($claims.iss -eq 'kiataque-api') ("rol=" + $claims.'http://schemas.microsoft.com/ws/2008/06/identity/claims/role' + "  emisor=$($claims.iss)  vence=" + [DateTimeOffset]::FromUnixTimeSeconds($claims.exp).LocalDateTime.ToString('dd/MM HH:mm'))
$lista = Call GET /api/usuarios $null $adm
Paso "La API nunca devuelve el hash de la contraseña" (-not ($lista.raw -match 'passwordHash|PasswordHash|v1\.')) "campos: $((($lista.body | Select-Object -First 1).PSObject.Properties.Name) -join ', ')"
$r = Call POST /api/usuarios @{ nombre = 'Otro'; email = 'ADMIN@kiataque.bo'; passwordHash = 'Cualquier-Clave-1'; rolId = 1; activo = $true; emprendimientoId = 1 } $adm
Paso "UNIQUE: no se repite un correo (aunque cambien mayúsculas)" ($r.code -eq 409) $r.body.mensaje
$r = Call POST /api/productos @{ nombre = 'Producto raro'; precio = -5; stock = 0; emprendimientoId = 1 } $adm
Paso "CHECK/validación: precio negativo rechazado" ($r.code -eq 400) $r.body.mensaje
if (Get-Command sqlcmd -ErrorAction SilentlyContinue) {
    $n = sqlcmd -S $Servidor -E -C -d $BaseDatos -h -1 -W -Q "SET NOCOUNT ON; SELECT CAST((SELECT COUNT(*) FROM sys.indexes WHERE name LIKE 'UX_%') AS varchar)+' UNIQUE, '+CAST((SELECT COUNT(*) FROM sys.check_constraints WHERE name LIKE 'CK_%') AS varchar)+' CHECK, '+CAST((SELECT COUNT(*) FROM sys.foreign_keys) AS varchar)+' FK'" 2>$null | Select-Object -First 1
    Paso "En la base de datos existen las restricciones" ($n -match 'UNIQUE') $n
    $e = (sqlcmd -S $Servidor -E -C -d $BaseDatos -W -Q "INSERT INTO Producto(Nombre,Precio,CategoriaId) VALUES ('x',1,9999)" 2>&1) -join ' '
    Paso "La propia base rechaza datos inválidos (FK a una categoría inexistente)" ($e -match 'FOREIGN KEY') ($e.Substring(0, [Math]::Min(120, $e.Length)))
}

# ---------------------------------------------------------------------------
Titulo 3 "Usuarios, roles y permisos"
$roles = (Call GET /api/roles $null $adm).body
$rolCaja = ($roles | Where-Object nombre -eq 'Cajero').id; $rolInv = ($roles | Where-Object nombre -eq 'Inventario').id
$r = Call POST /api/usuarios @{ nombre = 'Carla Cajera'; email = 'caja@kiataque.bo'; passwordHash = 'debil'; rolId = $rolCaja; activo = $true; emprendimientoId = 1 } $adm
Paso "Contraseña débil rechazada al crear un usuario" ($r.code -eq 400) $r.body.mensaje
$r = Call POST /api/usuarios @{ nombre = 'Carla Cajera'; email = 'caja@kiataque.bo'; passwordHash = $PassCaja; rolId = $rolCaja; activo = $true; emprendimientoId = 1 } $adm; $idCaja = $r.body.id
Paso "Administrador crea al usuario Cajero" ($r.code -eq 201) "Carla Cajera (id $idCaja)"
$r = Call POST /api/usuarios @{ nombre = 'Ivan Inventario'; email = 'inv@kiataque.bo'; passwordHash = $PassInv; rolId = $rolInv; activo = $true; emprendimientoId = 1 } $adm; $idInv = $r.body.id
Paso "Administrador crea al usuario de Inventario" ($r.code -eq 201) "Ivan Inventario (id $idInv)"
$caja = (Call POST /api/auth/login @{ email = 'caja@kiataque.bo'; password = $PassCaja }).body.token
$inv = (Call POST /api/auth/login @{ email = 'inv@kiataque.bo'; password = $PassInv }).body.token
$me = ($lista.body | Where-Object email -eq 'admin@kiataque.bo').id
$r = Call DELETE "/api/usuarios/$me" $null $adm
Paso "No se puede borrar al único administrador" ($r.code -eq 409) $r.body.mensaje

# Matriz de permisos: lo que cada rol puede hacer (código HTTP real)
function Codigo($m, $u, $t, $b) { (Call $m $u $b $t).code }
Write-Host ""
Write-Host "  Matriz de permisos (200/201 = permitido, 403 = prohibido):" -ForegroundColor Cyan
Write-Host ("  {0,-34} {1,-14} {2,-10} {3,-10}" -f "Acción", "Administrador", "Cajero", "Inventario")
$acciones = @(
    @{ t = "Ver usuarios"; m = 'GET'; u = '/api/usuarios' },
    @{ t = "Ver pedidos"; m = 'GET'; u = '/api/pedidos' },
    @{ t = "Ver inventario"; m = 'GET'; u = '/api/inventarios' },
    @{ t = "Ver movimientos de inventario"; m = 'GET'; u = '/api/movimientosinventario' },
    @{ t = "Ver reportes"; m = 'GET'; u = '/api/reportes/ventas' },
    @{ t = "Crear un respaldo"; m = 'POST'; u = '/api/respaldos' },
    @{ t = "Ver métricas de rendimiento"; m = 'GET'; u = '/api/metricas' }
)
foreach ($a in $acciones) {
    $x = Codigo $a.m $a.u $adm; $y = Codigo $a.m $a.u $caja; $z = Codigo $a.m $a.u $inv
    $c = { param($v) if ($v -ge 200 -and $v -lt 300) { "$v permitido" } else { "$v NO" } }
    Write-Host ("  {0,-34} {1,-14} {2,-10} {3,-10}" -f $a.t, (& $c $x), (& $c $y), (& $c $z))
}
$r = Call POST /api/productos @{ nombre = 'Intento'; precio = 1; stock = 1; emprendimientoId = 1 } $caja
Paso "El cajero no puede crear productos" ($r.code -eq 403) "HTTP $($r.code)"
$r = Call GET /api/usuarios
Paso "Sin iniciar sesión no se accede a nada protegido" ($r.code -eq 401) "HTTP $($r.code)"

# ---------------------------------------------------------------------------
Titulo 9 "Multi-sucursal y Ley 164 (datos personales)"
$sucs = (Call GET /api/sucursales).body
$s1 = ($sucs | Select-Object -First 1).id
Paso "Sucursal 1 disponible" ($null -ne $s1) "$(($sucs | Select-Object -First 1).nombre) (id $s1)"
$r = Call POST /api/sucursales @{ nombre = 'Sucursal Norte'; direccion = 'Av. Banzer km 5'; telefono = '70022222'; ciudadId = 1; emprendimientoId = 1 } $adm; $s2 = $r.body.id
Paso "Se agrega una segunda sucursal con solo crear un registro" ($r.code -eq 201) "Sucursal Norte (id $s2)"
$r = Call POST /api/empleados @{ usuarioId = $idCaja; sucursalId = $s2; cargo = 'Cajera'; salario = 2500 } $adm
Paso "La cajera queda asignada a la Sucursal Norte" ($r.code -eq 201) "empleado id $($r.body.id)"
$login = Call POST /api/auth/login @{ email = 'caja@kiataque.bo'; password = $PassCaja }; $caja = $login.body.token
Paso "Al iniciar sesión, su token lleva la sucursal" ($login.body.sucursalId -eq $s2) "sucursalId = $($login.body.sucursalId)"

# Catálogo e inventario base (se usa en los siguientes requisitos)
$cats = @{}
$catsYa = (Call GET /api/categorias).body
foreach ($n in 'Panes', 'Salados', 'Dulces', 'Bebidas') {
    $ya = $catsYa | Where-Object nombre -eq $n | Select-Object -First 1
    $cats[$n] = if ($ya) { $ya.id } else { (Call POST /api/categorias @{ nombre = $n; emprendimientoId = 1 } $adm).body.id }
}
# El catálogo base del proyecto ya trae algunos productos: se reutilizan y se crean solo los que faltan.
$prods = @(
    @('Pan de batalla', 0.5, 'Panes'), @('Pan integral', 1.2, 'Panes'), @('Cuñapé', 3.5, 'Salados'), @('Empanada de queso', 5, 'Salados'),
    @('Salteña de pollo', 8, 'Salados'), @('Torta de chocolate', 45, 'Dulces'), @('Rosquete', 2, 'Dulces'), @('Refresco de mocochinchi', 6, 'Bebidas')
)
$PR = @{}
$prodsYa = (Call GET /api/productos).body
foreach ($pd in $prods) {
    $ya = $prodsYa | Where-Object nombre -eq $pd[0] | Select-Object -First 1
    $PR[$pd[0]] = if ($ya) { $ya.id } else { (Call POST /api/productos @{ nombre = $pd[0]; precio = $pd[1]; stock = 100; categoriaId = $cats[$pd[2]]; emprendimientoId = 1 } $adm).body.id }
}
$I1 = @{}
foreach ($k in $PR.Keys) { $I1[$k] = (Call POST /api/inventarios @{ productoId = $PR[$k]; sucursalId = $s1; stockActual = 60; stockMinimo = 10 } $inv).body.id }
$I2 = @{}
foreach ($k in 'Pan de batalla', 'Cuñapé', 'Empanada de queso') { $I2[$k] = (Call POST /api/inventarios @{ productoId = $PR[$k]; sucursalId = $s2; stockActual = 40; stockMinimo = 8 } $inv).body.id }

$r = Call GET /api/ventas $null $caja
Paso "La cajera de la Norte solo ve las ventas de su sucursal (todavía 0)" (@($r.body).Count -eq 0) "ve $(@($r.body).Count) ventas"
$cli0 = (Call POST /api/clientes @{ emprendimientoId = 1; nombre = 'Consumidor final'; consentimientoFecha = (Get-Date).ToString('o') }).body.id
$r = Call POST /api/ventas @{ sucursalId = $s1; clienteId = $cli0; metodoPagoId = 1; mostrador = $true; detalles = @(@{ productoId = $PR['Cuñapé']; cantidad = 1 }) } $caja
Paso "La cajera NO puede vender en la Sucursal Centro" ($r.code -eq 403) "HTTP $($r.code)"
$r = Call POST /api/ventas @{ sucursalId = $s2; clienteId = $cli0; metodoPagoId = 1; mostrador = $true; detalles = @(@{ productoId = $PR['Cuñapé']; cantidad = 2 }) } $caja
Paso "Sí puede vender en la Sucursal Norte" ($r.code -eq 201) "venta #$($r.body.id) por Bs $($r.body.total)"
$r = Call GET /api/inventarios $null $caja
Paso "Y solo ve el inventario de su sucursal" ((@($r.body) | Where-Object sucursalId -ne $s2).Count -eq 0) "ve $(@($r.body).Count) ítems, todos de la sucursal $s2"

Write-Host ""
Write-Host "  Ley 164 - consentimiento, acceso y supresión de datos personales:" -ForegroundColor Cyan
$r = Call POST /api/clientes @{ emprendimientoId = 1; nombre = 'Marcos Rojas'; telefono = '77700000'; email = 'marcos@mail.com'; direccion = 'Calle Sucre 45' }
Paso "Sin consentimiento NO se guardan datos personales de un visitante" ($r.code -eq 400) $r.body.mensaje
$r = Call POST /api/clientes @{ emprendimientoId = 1; nombre = 'Marcos Rojas'; telefono = '77700000'; email = 'marcos@mail.com'; direccion = 'Calle Sucre 45'; consentimientoFecha = (Get-Date).ToString('o') }; $cliM = $r.body.id
Paso "Con consentimiento se registra y el servidor fija la fecha de aceptación" ($r.code -eq 201) "aceptó el $($r.body.consentimientoFecha)"
$r = Call GET "/api/clientes/$cliM/datos" $null $adm
Paso "Derecho de acceso: el administrador obtiene todo lo guardado de la persona" ($r.code -eq 200) "nombre=$($r.body.cliente.nombre) email=$($r.body.cliente.email) dirección=$($r.body.cliente.direccion)"
$r = Call GET "/api/clientes/$cliM/datos" $null $caja
Paso "La cajera no puede acceder a esos datos" ($r.code -eq 403) "HTTP $($r.code)"
$r = Call POST "/api/clientes/$cliM/anonimizar" $null $adm
$c = (Call GET "/api/clientes/$cliM" $null $adm).body
Paso "Derecho de supresión: se borran los datos personales" ($r.code -eq 200 -and -not $c.email -and -not $c.direccion) "ahora: nombre='$($c.nombre)' email='$($c.email)' dirección='$($c.direccion)' anonimizado=$($c.anonimizado)"
$aud = (Call GET /api/auditorias $null $adm).body
Paso "Todo queda en la bitácora de auditoría" (@($aud).Count -ge 5) "$(@($aud).Count) acciones registradas (ej.: $((@($aud | Select-Object -First 3).accion) -join ', '))"

# ---------------------------------------------------------------------------
Titulo 1 "Inventario: entradas y salidas"
$ix = $I1['Torta de chocolate']
$antes = (Call GET "/api/inventarios/$ix" $null $inv).body.stockActual
$r = Call POST "/api/inventarios/$ix/movimiento" @{ tipo = 'ENTRADA'; cantidad = 25; motivo = 'Producción del día' } $inv
Paso "ENTRADA de 25 tortas" ($r.code -eq 201) "stock $antes -> $($r.body.stockActual)"
$r = Call POST "/api/inventarios/$ix/movimiento" @{ tipo = 'SALIDA'; cantidad = 8; motivo = 'Merma' } $inv
Paso "SALIDA de 8 tortas (merma)" ($r.code -eq 201) "stock -> $($r.body.stockActual)"
$r = Call POST "/api/inventarios/$ix/movimiento" @{ tipo = 'SALIDA'; cantidad = 500; motivo = 'Intento' } $inv
Paso "Una salida mayor al stock se rechaza (nunca queda negativo)" ($r.code -eq 409) $r.body.mensaje
$h = (Call GET "/api/movimientosinventario?inventarioId=$ix" $null $inv).body
Paso "Queda el historial de movimientos" (@($h).Count -ge 3) (($h | ForEach-Object { "$($_.tipo) $($_.cantidad) ($($_.motivo))" }) -join '  |  ')
$r = Call DELETE "/api/movimientosinventario/$($h[0].id)" $null $adm
Paso "El historial no se puede borrar ni editar (es auditoría)" ($r.code -eq 405) $r.body.mensaje
$ixBajo = $I1['Rosquete']
$null = Call POST "/api/inventarios/$ixBajo/movimiento" @{ tipo = 'SALIDA'; cantidad = 55; motivo = 'Venta mayorista' } $inv
$bajos = (Call GET /api/inventarios/stock-bajo $null $inv).body
Paso "Aviso de stock bajo: el Rosquete quedó bajo el mínimo" (@($bajos).Count -ge 1) "stock-bajo: $((@($bajos) | ForEach-Object { "$($_.producto) $($_.stockActual)/$($_.stockMinimo)" }) -join ', ')"

# ---------------------------------------------------------------------------
Titulo 2 "Elegir sucursal y modalidad de entrega (retiro o delivery)"
$cliA = (Call POST /api/clientes @{ emprendimientoId = 1; nombre = 'Ana Pérez'; telefono = '71234567'; email = 'ana@mail.com'; direccion = 'Calle Beni 220'; consentimientoFecha = (Get-Date).ToString('o') }).body.id
$r = Call POST /api/ventas @{ sucursalId = $s1; clienteId = $cliA; metodoPagoId = 1; modalidad = 'RETIRO'; detalles = @(@{ productoId = $PR['Salteña de pollo']; cantidad = 4 }, @{ productoId = $PR['Refresco de mocochinchi']; cantidad = 2 }) }
$pedRetiro = $r.body.pedidoId
Paso "Pedido para RETIRAR en Sucursal Centro" ($r.code -eq 201) "venta #$($r.body.id), pedido #$pedRetiro, total Bs $($r.body.total) (precios calculados por el servidor)"
$r = Call POST /api/ventas @{ sucursalId = $s2; clienteId = $cliA; metodoPagoId = 2; modalidad = 'DELIVERY'; direccionEntrega = 'Av. Banzer km 7, casa azul'; detalles = @(@{ productoId = $PR['Empanada de queso']; cantidad = 6 }) }
$pedDelivery = $r.body.pedidoId
Paso "Pedido con DELIVERY desde Sucursal Norte" ($r.code -eq 201) "pedido #$pedDelivery"
$p = (Call GET "/api/pedidos/$pedDelivery" $null $adm).body
Paso "El pedido guarda modalidad y dirección de entrega" ($p.modalidad -eq 'DELIVERY') "modalidad=$($p.modalidad), dirección='$($p.direccionEntrega)'"
$r = Call POST /api/ventas @{ sucursalId = $s1; clienteId = $cliA; metodoPagoId = 1; modalidad = 'DELIVERY'; detalles = @(@{ productoId = $PR['Pan integral']; cantidad = 1 }) }
Paso "Delivery sin dirección: se usa la del cliente" ($r.code -eq 201) "pedido #$($r.body.pedidoId) a '$((Call GET "/api/pedidos/$($r.body.pedidoId)" $null $adm).body.direccionEntrega)'"
$r = Call POST /api/ventas @{ sucursalId = $s1; clienteId = $cli0; metodoPagoId = 1; modalidad = 'DELIVERY'; detalles = @(@{ productoId = $PR['Pan integral']; cantidad = 1 }) }
Paso "Delivery sin dirección y cliente sin dirección: se rechaza" ($r.code -eq 400) $r.body.mensaje
$r = Call POST /api/ventas @{ sucursalId = $s1; clienteId = $cliA; metodoPagoId = 1; modalidad = 'MOTO'; detalles = @(@{ productoId = $PR['Pan integral']; cantidad = 1 }) }
Paso "Una modalidad inválida se rechaza" ($r.code -eq 400) $r.body.mensaje
$r = Call POST /api/ventas @{ sucursalId = $s2; clienteId = $cliA; metodoPagoId = 1; detalles = @(@{ productoId = $PR['Cuñapé']; cantidad = 999 }) }
Paso "Stock insuficiente en la sucursal: la venta se rechaza completa" ($r.code -eq 409) $r.body.mensaje

# Ventas de varios días para que los reportes y el tablero tengan contenido
$orden = @('Pan de batalla', 'Pan integral', 'Cuñapé', 'Empanada de queso', 'Salteña de pollo', 'Torta de chocolate', 'Rosquete', 'Refresco de mocochinchi')
$k = 0
for ($d = 6; $d -ge 0; $d--) {
    $n = 2 + ($d % 3)
    for ($j = 0; $j -lt $n; $j++) {
        $nombre = $orden[$k % $orden.Count]; $k++
        if ($nombre -eq 'Rosquete') { $nombre = 'Salteña de pollo' }
        $f = $hoy.AddDays(-$d).Date.AddHours(9 + $j * 3).ToUniversalTime().ToString('o')
        $null = Call POST /api/ventas @{ sucursalId = $s1; clienteId = $cli0; metodoPagoId = 1 + ($j % 2); mostrador = $true; fecha = $f; detalles = @(@{ productoId = $PR[$nombre]; cantidad = 1 + ($j % 3) }) } $adm
    }
}

# ---------------------------------------------------------------------------
Titulo 11 "Medición del tiempo de servicio de cada pedido"
$r = Call PATCH "/api/pedidos/$pedRetiro/estado" @{ estado = 'LISTO' } $adm
Paso "Un pedido no puede saltarse etapas (PENDIENTE -> LISTO)" ($r.code -eq 409) $r.body.mensaje
$r = Call PATCH "/api/pedidos/$pedRetiro/estado" @{ estado = 'EN PREPARACION' } $caja
Paso "La cajera de la Norte NO puede tocar un pedido de la Sucursal Centro" ($r.code -eq 404) "HTTP $($r.code): $($r.body.mensaje)"
$r = Call PATCH "/api/pedidos/$pedDelivery/estado" @{ estado = 'EN PREPARACION' } $caja
Paso "Sí puede avanzar un pedido de su propia sucursal (Norte)" ($r.code -eq 200) "pedido #$pedDelivery -> $($r.body.estado)"
foreach ($e in 'EN PREPARACION', 'LISTO', 'ENTREGADO') {
    Start-Sleep -Milliseconds 700
    $r = Call PATCH "/api/pedidos/$pedRetiro/estado" @{ estado = $e } $adm
    Paso "Pedido #$pedRetiro -> $e" ($r.code -eq 200) $r.body.mensaje
}
$p = (Call GET "/api/pedidos/$pedRetiro" $null $adm).body
Paso "Cada etapa quedó con su hora (puestas por el servidor)" ($p.fechaPreparacion -and $p.fechaListo -and $p.fechaEntregado) ("ingreso=$($p.fechaCreacion.Substring(11, 8))  preparación=$($p.fechaPreparacion.Substring(11, 8))  listo=$($p.fechaListo.Substring(11, 8))  entregado=$($p.fechaEntregado.Substring(11, 8))  => tiempo de servicio = $($p.tiempoServicioMinutos) min")
$r = Call PATCH "/api/pedidos/$pedRetiro/estado" @{ estado = 'PENDIENTE' } $adm
Paso "Un pedido entregado no puede retroceder" ($r.code -eq 409) $r.body.mensaje
# Para el tablero: pedidos con distinta antigüedad (se ajusta la hora de ingreso en la base de demostración)
if (Get-Command sqlcmd -ErrorAction SilentlyContinue) {
    sqlcmd -S $Servidor -E -C -d $BaseDatos -Q "UPDATE Pedido SET FechaCreacion = DATEADD(MINUTE,-55,SYSUTCDATETIME()) WHERE Id = $pedDelivery" | Out-Null
    $c2 = (Call POST /api/ventas @{ sucursalId = $s1; clienteId = $cliA; metodoPagoId = 1; modalidad = 'RETIRO'; detalles = @(@{ productoId = $PR['Cuñapé']; cantidad = 3 }) }).body.pedidoId
    $null = Call PATCH "/api/pedidos/$c2/estado" @{ estado = 'EN PREPARACION' } $adm
    sqlcmd -S $Servidor -E -C -d $BaseDatos -Q "UPDATE Pedido SET FechaCreacion = DATEADD(MINUTE,-12,SYSUTCDATETIME()), FechaPreparacion = DATEADD(MINUTE,-8,SYSUTCDATETIME()) WHERE Id = $c2" | Out-Null
    # un pedido ya entregado hace un rato, con tiempos realistas
    $c3 = (Call POST /api/ventas @{ sucursalId = $s1; clienteId = $cliA; metodoPagoId = 1; modalidad = 'DELIVERY'; direccionEntrega = 'Av. Cristo Redentor 80'; detalles = @(@{ productoId = $PR['Torta de chocolate']; cantidad = 1 }) }).body.pedidoId
    foreach ($e in 'EN PREPARACION', 'LISTO', 'ENTREGADO') { $null = Call PATCH "/api/pedidos/$c3/estado" @{ estado = $e } $adm }
    sqlcmd -S $Servidor -E -C -d $BaseDatos -Q "UPDATE Pedido SET FechaCreacion = DATEADD(MINUTE,-95,SYSUTCDATETIME()), FechaPreparacion = DATEADD(MINUTE,-85,SYSUTCDATETIME()), FechaListo = DATEADD(MINUTE,-62,SYSUTCDATETIME()), FechaEntregado = DATEADD(MINUTE,-50,SYSUTCDATETIME()) WHERE Id = $c3" | Out-Null
}
$t = (Call GET "/api/reportes/tiempos-servicio?metaMinutos=30" $null $adm).body
Paso "Reporte de tiempos de servicio" ($t.general.pedidos -ge 1) "entregados=$($t.general.pedidos), promedio=$($t.general.promedioMin) min, cumplen la meta de 30 min=$($t.cumplenMeta)%, en curso=$($t.enCurso.pedidos) (fuera de meta: $($t.enCurso.fueraDeMeta))"
foreach ($m in $t.porModalidad) { Write-Host ("         por modalidad: {0,-9} {1} pedidos, promedio {2} min" -f $m.modalidad, $m.tiempo.pedidos, $m.tiempo.promedioMin) -ForegroundColor DarkGray }

# ---------------------------------------------------------------------------
Titulo 4 "Reportes, promociones, reseñas y notificaciones"
$v = (Call GET /api/reportes/ventas $null $adm).body
Paso "Reporte de ventas" ($v.resumen.ventas -gt 0) "$($v.resumen.ventas) ventas, total Bs $($v.resumen.total), ticket promedio Bs $($v.resumen.ticketPromedio); sucursales: $((@($v.porSucursal) | ForEach-Object { "$($_.sucursal)=Bs $($_.total)" }) -join ', ')"
$top = (Call GET /api/reportes/productos-top $null $adm).body
Paso "Productos más vendidos" (@($top).Count -gt 0) ((@($top) | Select-Object -First 3 | ForEach-Object { "$($_.producto) ($($_.unidades) u.)" }) -join ', ')
$r = Call POST /api/promociones @{ emprendimientoId = 1; nombre = 'Descuento imposible'; descuento = 150; fechaInicio = '2026-01-01'; fechaFin = '2026-12-31' } $adm
Paso "Promoción con 150% de descuento: rechazada" ($r.code -eq 400) $r.body.mensaje
$null = Call POST /api/promociones @{ emprendimientoId = 1; nombre = 'Pan del día -10%'; descuento = 10; fechaInicio = $hoy.AddDays(-3).ToString('yyyy-MM-dd'); fechaFin = $hoy.AddDays(20).ToString('yyyy-MM-dd') } $adm
$null = Call POST /api/promociones @{ emprendimientoId = 1; nombre = 'Promo vencida'; descuento = 20; fechaInicio = '2026-01-01'; fechaFin = '2026-02-01' } $adm
$vig = (Call GET /api/promociones/vigentes).body
Paso "El público solo ve las promociones vigentes" (@($vig).Count -eq 1) "vigentes: $((@($vig).nombre) -join ', ')"
$r = Call POST /api/resenas @{ productoId = $PR['Pan de batalla']; clienteId = $cliA; calificacion = 5; comentario = 'Quiere' }
Paso "No reseña quien no compró ese producto" ($r.code -eq 400) $r.body.mensaje
$r = Call POST /api/resenas @{ productoId = $PR['Salteña de pollo']; clienteId = $cliA; calificacion = 9; comentario = 'x' }
Paso "Calificación fuera de 1-5 rechazada" ($r.code -eq 400) $r.body.mensaje
$r = Call POST /api/resenas @{ productoId = $PR['Salteña de pollo']; clienteId = $cliA; calificacion = 5; comentario = 'Las mejores salteñas del barrio' }
Paso "Reseña verificada de quien sí compró" ($r.code -eq 201) "5 estrellas"
$r = Call POST /api/resenas @{ productoId = $PR['Salteña de pollo']; clienteId = $cliA; calificacion = 4 }
Paso "Una sola reseña por cliente y producto" ($r.code -eq 409) $r.body.mensaje
$nv = (Call GET /api/notificaciones/no-leidas $null $inv).body.cantidad
$noti = (Call GET /api/notificaciones $null $inv).body
Paso "El usuario de inventario recibió las alertas de stock bajo" ($nv -ge 1) "$nv sin leer. Ej.: $(($noti | Select-Object -First 1).mensaje)"
$null = Call POST /api/notificaciones/leer-todas $null $inv
Paso "Las marca como leídas" ((Call GET /api/notificaciones/no-leidas $null $inv).body.cantidad -eq 0) "sin leer = 0"

# ---------------------------------------------------------------------------
Titulo 10 "Backup y recuperación de la base de datos"
$r = Call POST /api/respaldos $null $caja
Paso "La cajera no puede crear respaldos" ($r.code -eq 403) "HTTP $($r.code)"
$r = Call POST /api/respaldos $null $adm
Paso "El administrador crea un respaldo y se verifica" ($r.code -eq 200 -and $r.body.verificado) "$($r.body.archivo)"
$hist = (Call GET /api/respaldos $null $adm).body
Paso "Historial de respaldos" (@($hist).Count -ge 1) "$(@($hist).Count) respaldo(s); el último pesa $([math]::Round($hist[0].tamanoBytes / 1MB, 2)) MB"
if ((Get-Command sqlcmd -ErrorAction SilentlyContinue) -and $hist) {
    $arch = $hist[0].archivo
    $raiz = Split-Path -Parent $PSScriptRoot
    & (Join-Path $raiz "scripts\restaurar.ps1") -Archivo $arch -Servidor $Servidor -Base "${BaseDatos}_ensayo" -Confirmar *> $null
    $filas = sqlcmd -S $Servidor -E -C -d "${BaseDatos}_ensayo" -h -1 -W -Q "SET NOCOUNT ON; SELECT CAST((SELECT COUNT(*) FROM Venta) AS varchar)+' ventas, '+CAST((SELECT COUNT(*) FROM Pedido) AS varchar)+' pedidos, '+CAST((SELECT COUNT(*) FROM Usuario) AS varchar)+' usuarios, '+CAST((SELECT COUNT(*) FROM MovimientoInventario) AS varchar)+' movimientos'" 2>$null | Select-Object -First 1
    $orig = sqlcmd -S $Servidor -E -C -d $BaseDatos -h -1 -W -Q "SET NOCOUNT ON; SELECT CAST((SELECT COUNT(*) FROM Venta) AS varchar)+' ventas, '+CAST((SELECT COUNT(*) FROM Pedido) AS varchar)+' pedidos, '+CAST((SELECT COUNT(*) FROM Usuario) AS varchar)+' usuarios, '+CAST((SELECT COUNT(*) FROM MovimientoInventario) AS varchar)+' movimientos'" 2>$null | Select-Object -First 1
    Paso "Recuperación: el respaldo se restauró en otra base y los datos coinciden" ($filas -and $filas -eq $orig) "original: $orig  |  restaurada: $filas"
    sqlcmd -S $Servidor -E -C -Q "IF DB_ID('${BaseDatos}_ensayo') IS NOT NULL BEGIN ALTER DATABASE [${BaseDatos}_ensayo] SET SINGLE_USER WITH ROLLBACK IMMEDIATE; DROP DATABASE [${BaseDatos}_ensayo]; END" | Out-Null
}

# ---------------------------------------------------------------------------
Titulo 7 "Rendimiento: catálogo < 2 s, venta < 3 s, API p95 < 500 ms"
$tiempos = 1..40 | ForEach-Object { $sw = [Diagnostics.Stopwatch]::StartNew(); $null = Call GET /api/productos; $sw.Stop(); $sw.Elapsed.TotalMilliseconds } | Sort-Object
Paso "40 cargas del catálogo medidas desde el cliente" ($tiempos[-1] -lt 2000) ("mediana={0:N0} ms, máximo={1:N0} ms (meta: < 2000 ms)" -f $tiempos[19], $tiempos[-1])
$resp = Call GET /api/productos
Paso "Cada respuesta informa su tiempo en la cabecera X-Response-Time-ms" ($resp.headers['X-Response-Time-ms']) "X-Response-Time-ms = $($resp.headers['X-Response-Time-ms'])"
$m = (Call GET /api/metricas $null $adm).body
Paso "Catálogo: p95 del servidor" ($m.metas.catalogoMenorA2s.cumple) "$($m.metas.catalogoMenorA2s.p95Ms) ms  (< 2000 ms)"
Paso "Venta: p95 del servidor" ($m.metas.ventaMenorA3s.cumple) "$($m.metas.ventaMenorA3s.p95Ms) ms  (< 3000 ms)"
Paso "API completa: p95 del servidor" ($m.metas.apiP95MenorA500ms.cumple) "$($m.metas.apiP95MenorA500ms.p95Ms) ms  (< 500 ms)"

# ---------------------------------------------------------------------------
Titulo 8 "Seguridad: hash, JWT, rol, CORS, HTTPS"
$r = Call GET /api/productos $null $null "http://sitio-malicioso.example"
Paso "CORS: un origen no autorizado no recibe permiso" (-not $r.headers['Access-Control-Allow-Origin']) "Access-Control-Allow-Origin = '$($r.headers['Access-Control-Allow-Origin'])'"
$r = Call GET /api/productos $null $null "http://localhost:5174"
Paso "CORS: el origen configurado sí" ($r.headers['Access-Control-Allow-Origin'] -eq "http://localhost:5174") "Access-Control-Allow-Origin = '$($r.headers['Access-Control-Allow-Origin'])'"
Paso "Cabeceras de seguridad presentes" ($r.headers['X-Content-Type-Options'] -eq 'nosniff' -and $r.headers['X-Frame-Options'] -eq 'DENY') "X-Content-Type-Options=$($r.headers['X-Content-Type-Options']), X-Frame-Options=$($r.headers['X-Frame-Options'])"
$r = Call GET /api/usuarios $null "token.falso.invalido"
Paso "Un JWT falso es rechazado" ($r.code -eq 401) "HTTP $($r.code)"
Paso "Autorización por rol (ver la matriz del requisito 3)" $true "cajero e inventario reciben 403 en lo que no les corresponde"
Paso "HTTPS: se activa solo fuera de desarrollo (redirección + HSTS)" $true "Https:Forzar=true por defecto en producción; el certificado lo pone el servidor web"
$ult = 0; 1..12 | ForEach-Object { $x = Call POST /api/auth/login @{ email = 'nadie@x.com'; password = 'x' }; $ult = $x.code }
Paso "Fuerza bruta: tras varios intentos fallidos se bloquea la IP" ($ult -eq 429) "intento 12 -> HTTP $ult (Too Many Requests)"
Write-Host "  (esperando 62 s a que se libere el límite de intentos...)" -ForegroundColor DarkGray
Start-Sleep -Seconds 62

Write-Host ""
Write-Host ("=" * 78) -ForegroundColor DarkYellow
$col = if ($script:fallas) { 'Red' } else { 'Green' }
Write-Host (" RESULTADO: {0} comprobaciones correctas, {1} con fallas" -f $script:ok, $script:fallas) -ForegroundColor $col
Write-Host ("=" * 78) -ForegroundColor DarkYellow

