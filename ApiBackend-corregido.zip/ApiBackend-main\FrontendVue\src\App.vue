<script setup>
// Componente raíz. Según la pantalla del store se muestra:
//  - Login · Tienda (vista pública) · Panel (gestión interna) · Setup (primer administrador)
import { defineAsyncComponent, watch } from 'vue';
import { store } from './store';
import HostFeedback from './ui/HostFeedback.vue';
import Login from './components/Login.vue';

// El panel y la tienda se cargan bajo demanda: el inicio de sesión abre más rápido.
const TiendaCliente = defineAsyncComponent(() => import('./components/TiendaCliente.vue'));
const PanelAdmin = defineAsyncComponent(() => import('./components/PanelAdmin.vue'));
const Setup = defineAsyncComponent(() => import('./components/Setup.vue'));

store.restaurar();

const TITULOS = { login: 'Iniciar sesión · Kiataque', tienda: 'Tienda · Panadería Kiataque', setup: 'Configuración inicial · Kiataque' };
watch(() => store.pantalla, (p) => { if (TITULOS[p]) document.title = TITULOS[p]; }, { immediate: true });
</script>

<template>
  <Login v-if="store.pantalla === 'login'" />
  <TiendaCliente v-else-if="store.pantalla === 'tienda'" />
  <PanelAdmin v-else-if="store.pantalla === 'panel'" />
  <Setup v-else-if="store.pantalla === 'setup'" />
  <HostFeedback />
</template>
