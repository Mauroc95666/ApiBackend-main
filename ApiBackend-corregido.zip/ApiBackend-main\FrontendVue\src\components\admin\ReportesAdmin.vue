<script setup>
import { ref, computed, onMounted } from 'vue';
import api from '@/api/axios';
import { toast } from '@/ui/feedback';
import { bs, entero, claveDia, duracion, mensajeError, descargarCsv } from '@/utils/format';
import AppIcon from '@/ui/AppIcon.vue';
import Campo from '@/ui/Campo.vue';
import EncabezadoPagina from '@/ui/EncabezadoPagina.vue';
import EstadoVacio from '@/ui/EstadoVacio.vue';
import TarjetaKpi from '@/ui/TarjetaKpi.vue';

const hoy = new Date();
const desde = ref(claveDia(new Date(Date.now() - 29 * 86400000)));
const hasta = ref(claveDia(hoy));
const sucursalId = ref('');
const metaMin = ref(30);
const sucursales = ref([]);

const ventas = ref(null);
const top = ref([]);
const tiempos = ref(null);
const cargando = ref(true);
const errorCarga = ref('');

// Atajos de período
function periodo(dias) {
  desde.value = claveDia(new Date(Date.now() - (dias - 1) * 86400000));
  hasta.value = claveDia(new Date());
  cargar();
}

async function cargar() {
  if (desde.value > hasta.value) return toast.aviso('La fecha inicial no puede ser posterior a la final.');
  cargando.value = true;
  errorCarga.value = '';
  const params = { desde: desde.value, hasta: hasta.value };
  if (sucursalId.value) params.sucursalId = sucursalId.value;
  try {
    const [v, t, s] = await Promise.all([
      api.get('/reportes/ventas', { params }),
      api.get('/reportes/productos-top', { params: { ...params, limite: 10 } }),
      api.get('/reportes/tiempos-servicio', { params: { ...params, metaMinutos: metaMin.value } }),
    ]);
    ventas.value = v.data;
    top.value = t.data || [];
    tiempos.value = s.data;
  } catch (e) {
    errorCarga.value = mensajeError(e, 'No se pudieron cargar los reportes.');
  } finally {
    cargando.value = false;
  }
}

const maxDia = computed(() => Math.max(1, ...(ventas.value?.porDia || []).map((d) => d.total)));
const maxTop = computed(() => Math.max(1, ...top.value.map((p) => p.unidades)));
const diaCorto = (f) => new Date(f).toLocaleDateString('es-BO', { day: '2-digit', month: 'short', timeZone: 'UTC' });

function exportar() {
  if (!ventas.value) return;
  descargarCsv(`reporte-ventas_${desde.value}_${hasta.value}.csv`, [
    ['Día', 'Ventas', 'Total (Bs)'],
    ...ventas.value.porDia.map((d) => [claveDia(d.fecha.slice(0, 10) + 'T12:00:00'), d.ventas, d.total]),
    [],
    ['Producto', 'Unidades', 'Ingresos (Bs)'],
    ...top.value.map((p) => [p.producto, p.unidades, p.ingresos]),
  ]);
}

onMounted(async () => {
  try {
    sucursales.value = (await api.get('/sucursales')).data || [];
  } catch {
    sucursales.value = [];
  }
  cargar();
});
</script>

<template>
  <div>
    <EncabezadoPagina titulo="Reportes" subtitulo="Ventas, productos más vendidos y tiempo de servicio de los pedidos">
      <button type="button" class="btn btn-secundario" :disabled="!ventas" @click="exportar"><AppIcon name="download" :size="16" /> Exportar CSV</button>
    </EncabezadoPagina>

    <form class="tarjeta filtros" @submit.prevent="cargar">
      <Campo label="Desde" v-slot="{ id }"><input :id="id" v-model="desde" type="date" :max="hasta" /></Campo>
      <Campo label="Hasta" v-slot="{ id }"><input :id="id" v-model="hasta" type="date" :min="desde" /></Campo>
      <Campo v-if="sucursales.length > 1" label="Sucursal" v-slot="{ id }">
        <select :id="id" v-model="sucursalId"><option value="">Todas</option><option v-for="s in sucursales" :key="s.id" :value="s.id">{{ s.nombre }}</option></select>
      </Campo>
      <Campo label="Meta de entrega (min)" v-slot="{ id }"><input :id="id" v-model.number="metaMin" type="number" min="1" /></Campo>
      <div class="fila fila-envolver">
        <button type="button" class="btn btn-fantasma btn-sm" @click="periodo(7)">7 días</button>
        <button type="button" class="btn btn-fantasma btn-sm" @click="periodo(30)">30 días</button>
        <button type="button" class="btn btn-fantasma btn-sm" @click="periodo(90)">90 días</button>
        <button class="btn btn-primario" :disabled="cargando"><AppIcon name="refresh" :size="16" :class="{ girando: cargando }" /> Actualizar</button>
      </div>
    </form>

    <div v-if="errorCarga" class="aviso-linea error" role="alert" style="margin: 16px 0">
      <AppIcon name="alert" :size="18" /> <span class="crece">{{ errorCarga }}</span>
      <button type="button" class="btn btn-secundario btn-sm" @click="cargar">Reintentar</button>
    </div>

    <div class="pila" style="margin-top: 20px; gap: 20px">
      <div class="rejilla-kpi">
        <TarjetaKpi titulo="Ventas" icono="receipt" :valor="entero(ventas?.resumen.ventas)" :cargando="cargando" />
        <TarjetaKpi titulo="Total vendido" icono="chart" tono="ok" :valor="bs(ventas?.resumen.total)" :cargando="cargando" />
        <TarjetaKpi titulo="Ticket promedio" icono="tag" tono="info" :valor="bs(ventas?.resumen.ticketPromedio)" :cargando="cargando" />
      </div>

      <div class="dos">
        <section class="tarjeta">
          <div class="tarjeta-cabecera"><h3>Ventas por día</h3></div>
          <div class="tarjeta-cuerpo">
            <div v-if="cargando" class="esqueleto" style="height: 160px"></div>
            <EstadoVacio v-else-if="!ventas?.porDia.length" icono="chart" titulo="Sin ventas en el período" />
            <div v-else class="barras-h">
              <div v-for="d in ventas.porDia" :key="d.fecha" class="barra-fila">
                <span class="texto-chico texto-suave">{{ diaCorto(d.fecha) }}</span>
                <div class="pista"><div class="rel" :style="{ width: (d.total / maxDia) * 100 + '%' }"></div></div>
                <span class="texto-chico numeros">{{ bs(d.total) }}</span>
              </div>
            </div>
          </div>
        </section>

        <section class="tarjeta">
          <div class="tarjeta-cabecera"><h3>Productos más vendidos</h3></div>
          <div class="tarjeta-cuerpo">
            <div v-if="cargando" class="esqueleto" style="height: 160px"></div>
            <EstadoVacio v-else-if="!top.length" icono="package" titulo="Sin datos en el período" />
            <ol v-else class="ranking">
              <li v-for="(p, n) in top" :key="p.productoId">
                <span class="pos">{{ n + 1 }}</span>
                <div class="crece">
                  <div class="fila entre"><span class="truncar negrita">{{ p.producto }}</span><span class="texto-chico texto-suave numeros">{{ entero(p.unidades) }} u. · {{ bs(p.ingresos) }}</span></div>
                  <div class="pista fina"><div class="rel" :style="{ width: (p.unidades / maxTop) * 100 + '%' }"></div></div>
                </div>
              </li>
            </ol>
          </div>
        </section>
      </div>

      <div v-if="ventas && (ventas.porSucursal.length > 1 || ventas.porMetodo.length)" class="dos">
        <section v-if="ventas.porSucursal.length > 1" class="tarjeta">
          <div class="tarjeta-cabecera"><h3>Por sucursal</h3></div>
          <div class="tabla-contenedor"><table class="tabla"><thead><tr><th>Sucursal</th><th class="num">Ventas</th><th class="num">Total</th></tr></thead>
            <tbody><tr v-for="s in ventas.porSucursal" :key="s.sucursalId"><td>{{ s.sucursal }}</td><td class="num">{{ s.ventas }}</td><td class="num">{{ bs(s.total) }}</td></tr></tbody></table></div>
        </section>
        <section class="tarjeta">
          <div class="tarjeta-cabecera"><h3>Por método de pago</h3></div>
          <div class="tabla-contenedor"><table class="tabla"><thead><tr><th>Método</th><th class="num">Ventas</th><th class="num">Total</th></tr></thead>
            <tbody><tr v-for="m in ventas.porMetodo" :key="m.metodo"><td>{{ m.metodo }}</td><td class="num">{{ m.ventas }}</td><td class="num">{{ bs(m.total) }}</td></tr>
              <tr v-if="!ventas.porMetodo.length"><td colspan="3" class="texto-suave">Sin datos.</td></tr></tbody></table></div>
        </section>
      </div>

      <section class="tarjeta">
        <div class="tarjeta-cabecera">
          <div><h3>Tiempo de servicio de los pedidos</h3><p class="texto-chico texto-suave">Desde que entra el pedido hasta que se entrega. Meta: {{ tiempos?.metaMinutos ?? metaMin }} min.</p></div>
        </div>
        <div class="tarjeta-cuerpo pila">
          <div class="rejilla-kpi">
            <TarjetaKpi titulo="Entregados" icono="checkCircle" tono="ok" :valor="entero(tiempos?.general.pedidos)" :cargando="cargando" />
            <TarjetaKpi titulo="Promedio" icono="clock" :valor="duracion(tiempos?.general.promedioMin)" :cargando="cargando" />
            <TarjetaKpi titulo="9 de cada 10 en menos de" icono="clock" tono="info" :valor="duracion(tiempos?.general.p90Min)" :cargando="cargando" />
            <TarjetaKpi titulo="Cumplen la meta" icono="star" :tono="(tiempos?.cumplenMeta ?? 100) >= 80 ? 'ok' : 'aviso'" :valor="(tiempos?.cumplenMeta ?? 0) + ' %'" :cargando="cargando" />
            <TarjetaKpi titulo="En curso ahora" icono="clipboard" tono="aviso" :valor="entero(tiempos?.enCurso.pedidos)" :detalle="tiempos ? `${tiempos.enCurso.fueraDeMeta} fuera de meta` : ''" :cargando="cargando" />
          </div>
          <div class="tabla-contenedor">
            <table class="tabla">
              <thead><tr><th>Modalidad</th><th class="num">Pedidos</th><th class="num">Promedio</th><th class="num">Mínimo</th><th class="num">Máximo</th></tr></thead>
              <tbody>
                <tr v-for="m in tiempos?.porModalidad || []" :key="m.modalidad">
                  <td>{{ m.modalidad === 'DELIVERY' ? 'Delivery' : 'Retiro en local' }}</td><td class="num">{{ m.tiempo.pedidos }}</td>
                  <td class="num">{{ duracion(m.tiempo.promedioMin) }}</td><td class="num">{{ duracion(m.tiempo.minimoMin) }}</td><td class="num">{{ duracion(m.tiempo.maximoMin) }}</td>
                </tr>
                <tr v-if="!tiempos?.porModalidad.length"><td colspan="5" class="texto-suave">Todavía no hay pedidos entregados en el período.</td></tr>
              </tbody>
            </table>
          </div>
        </div>
      </section>
    </div>
  </div>
</template>

<style scoped>
.filtros { display: flex; gap: 16px; align-items: flex-end; flex-wrap: wrap; padding: 16px 20px; }
.filtros .campo { min-width: 150px; }
.dos { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 20px; align-items: start; }
@media (max-width: 1000px) { .dos { grid-template-columns: 1fr; } }

.barras-h { display: grid; gap: 8px; max-height: 340px; overflow-y: auto; }
.barra-fila { display: grid; grid-template-columns: 56px 1fr 96px; gap: 10px; align-items: center; }
.barra-fila span:last-child { text-align: right; }
.pista { background: var(--superficie-2); border-radius: 6px; height: 12px; overflow: hidden; }
.pista.fina { height: 6px; margin-top: 6px; }
.rel { height: 100%; background: var(--marca); border-radius: 6px; transition: width 0.4s ease; }

.ranking { list-style: none; margin: 0; padding: 0; display: grid; gap: 14px; }
.ranking li { display: flex; gap: 12px; align-items: center; }
.pos { flex: none; width: 26px; height: 26px; border-radius: 50%; background: var(--marca-suave); color: var(--marca-tinta); font-weight: 800; font-size: 13px; display: grid; place-items: center; }
</style>
