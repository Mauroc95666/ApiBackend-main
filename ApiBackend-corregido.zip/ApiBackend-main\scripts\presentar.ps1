<#
.SYNOPSIS
  Presentación automática de los 11 requisitos funcionales.
  Prepara una demo limpia (base nueva, API y frontend), abre Chrome y recorre los 11 requisitos solo,
  con un rótulo en pantalla que indica qué requisito se está mostrando. Dura unos 10 minutos.

  No toca tu base real: usa DB_Panaderia2_demo, la API en :5209 y el frontend en :5174.

.EXAMPLE
  .\scripts\presentar.ps1                 # presentación normal, con pausas para explicar
  .\scripts\presentar.ps1 -Pausa 1.5      # más lenta (más tiempo para hablar)
  .\scripts\presentar.ps1 -Rapido         # ensayo veloz
  .\scripts\presentar.ps1 -Oculto -Rapido # verificación sin ventana (comprueba que todo funciona)
  .\scripts\presentar.ps1 -SinPreparar    # reutiliza la demo ya preparada (debe estar VACÍA: sin administrador)
#>
param(
    [double]$Pausa = 1,
    [switch]$Rapido,
    [switch]$Oculto,
    [switch]$SinPreparar
)
$ErrorActionPreference = 'Stop'
$raiz = Split-Path -Parent $PSScriptRoot
$carpeta = Join-Path $raiz "scripts\presentacion"

if (-not (Get-Command node -ErrorAction SilentlyContinue)) { throw "Hace falta Node.js (ya lo usás para el frontend)." }
if (-not (Test-Path "C:\Program Files\Google\Chrome\Application\chrome.exe") -and -not (Test-Path "C:\Program Files (x86)\Google\Chrome\Application\chrome.exe")) {
    throw "No encontré Google Chrome instalado."
}

if (-not $SinPreparar) {
    Write-Host "1/3  Preparando la demo (base nueva + API + frontend)..." -ForegroundColor Cyan
    & (Join-Path $raiz "scripts\preparar-demo.ps1")
}
if (-not (Test-Path (Join-Path $carpeta "node_modules\playwright-core"))) {
    Write-Host "2/3  Instalando la librería que maneja Chrome (una sola vez)..." -ForegroundColor Cyan
    Push-Location $carpeta; npm install --no-audit --no-fund; Pop-Location
}

Write-Host "3/3  Abriendo Chrome y comenzando la presentación..." -ForegroundColor Cyan
$argsNode = @("presentar.mjs", "--pausa=$Pausa")
if ($Rapido) { $argsNode += "--rapido" }
if ($Oculto) { $argsNode += "--oculto" }
Push-Location $carpeta
try { & node @argsNode; $codigo = $LASTEXITCODE } finally { Pop-Location }
if ($codigo -eq 0) { Write-Host "Presentación completa: 11 de 11 requisitos." -ForegroundColor Green }
else { Write-Host "Alguno de los requisitos falló: mirá el detalle y los archivos falla-req*.png en scripts\presentacion." -ForegroundColor Yellow }
