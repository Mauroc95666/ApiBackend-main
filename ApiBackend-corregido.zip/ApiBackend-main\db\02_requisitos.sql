/* ============================================================
   02_requisitos.sql  -  Panadería Kiataque
   Cambios de modelo para los requisitos funcionales 2, 5, 6, 9 y 11.
   Es idempotente: se puede ejecutar varias veces sin duplicar nada.
   Se ejecuta después de init.sql (db-init lo hace en Docker).
   ============================================================ */
USE DB_Panaderia2;
GO

/* ---------- Roles del sistema (req. 3) ---------- */
IF NOT EXISTS (SELECT 1 FROM [Rol] WHERE [Nombre] = 'Administrador')
    INSERT INTO [Rol] ([Nombre],[Descripcion]) VALUES ('Administrador','Gestiona usuarios, roles, reportes y configuración.');
IF NOT EXISTS (SELECT 1 FROM [Rol] WHERE [Nombre] = 'Cajero')
    INSERT INTO [Rol] ([Nombre],[Descripcion]) VALUES ('Cajero','Registra ventas y gestiona pedidos.');
IF NOT EXISTS (SELECT 1 FROM [Rol] WHERE [Nombre] = 'Vendedor')
    INSERT INTO [Rol] ([Nombre],[Descripcion]) VALUES ('Vendedor','Atiende ventas y consulta productos.');
IF NOT EXISTS (SELECT 1 FROM [Rol] WHERE [Nombre] = 'Inventario')
    INSERT INTO [Rol] ([Nombre],[Descripcion]) VALUES ('Inventario','Controla el stock y los productos.');
GO

/* ---------- Req. 6: sin credenciales conocidas ----------
   El script original sembraba superadmin@kiataque.bo con la clave 'Admin123'.
   Si ese usuario todavía conserva la clave en texto plano, se elimina: el primer
   administrador ahora se crea con el super-usuario oculto (POST /api/setup/primer-admin). */
DELETE FROM [Usuario]
WHERE [Email] = 'superadmin@kiataque.bo'
  AND [PasswordHash] = 'Admin123'
  AND NOT EXISTS (SELECT 1 FROM [Venta] v WHERE v.[UsuarioId] = [Usuario].[Id])
  AND NOT EXISTS (SELECT 1 FROM [MovimientoInventario] m WHERE m.[UsuarioId] = [Usuario].[Id])
  AND NOT EXISTS (SELECT 1 FROM [Empleado] e WHERE e.[UsuarioId] = [Usuario].[Id])
  AND NOT EXISTS (SELECT 1 FROM [Notificacion] n WHERE n.[UsuarioId] = [Usuario].[Id])
  AND NOT EXISTS (SELECT 1 FROM [Auditoria] a WHERE a.[UsuarioId] = [Usuario].[Id]);
GO

/* ---------- Req. 2 y 11: modalidad de entrega y tiempos del pedido ---------- */
IF COL_LENGTH('Pedido','Modalidad') IS NULL
    ALTER TABLE [Pedido] ADD [Modalidad] nvarchar(20) NOT NULL CONSTRAINT [DF_Pedido_Modalidad] DEFAULT 'RETIRO';
IF COL_LENGTH('Pedido','DireccionEntrega') IS NULL
    ALTER TABLE [Pedido] ADD [DireccionEntrega] nvarchar(300) NULL;
IF COL_LENGTH('Pedido','FechaCreacion') IS NULL
    ALTER TABLE [Pedido] ADD [FechaCreacion] datetime2 NOT NULL CONSTRAINT [DF_Pedido_FechaCreacion] DEFAULT SYSUTCDATETIME();
IF COL_LENGTH('Pedido','FechaPreparacion') IS NULL
    ALTER TABLE [Pedido] ADD [FechaPreparacion] datetime2 NULL;
IF COL_LENGTH('Pedido','FechaListo') IS NULL
    ALTER TABLE [Pedido] ADD [FechaListo] datetime2 NULL;
IF COL_LENGTH('Pedido','FechaEntregado') IS NULL
    ALTER TABLE [Pedido] ADD [FechaEntregado] datetime2 NULL;
GO

/* ---------- Req. 9 (Ley 164): consentimiento y anonimización del cliente ---------- */
IF COL_LENGTH('Cliente','ConsentimientoFecha') IS NULL
    ALTER TABLE [Cliente] ADD [ConsentimientoFecha] datetime2 NULL;
IF COL_LENGTH('Cliente','Anonimizado') IS NULL
    ALTER TABLE [Cliente] ADD [Anonimizado] bit NOT NULL CONSTRAINT [DF_Cliente_Anonimizado] DEFAULT 0;
GO

/* ---------- Req. 5: FOREIGN KEY que faltaban ---------- */
IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = 'FK_Producto_Categoria_CategoriaId')
    ALTER TABLE [Producto] ADD CONSTRAINT [FK_Producto_Categoria_CategoriaId]
        FOREIGN KEY ([CategoriaId]) REFERENCES [Categoria]([Id]);
IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = 'FK_Producto_Proveedor_ProveedorId')
    ALTER TABLE [Producto] ADD CONSTRAINT [FK_Producto_Proveedor_ProveedorId]
        FOREIGN KEY ([ProveedorId]) REFERENCES [Proveedor]([Id]);
IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = 'FK_Producto_Emprendimiento_EmprendimientoId')
    ALTER TABLE [Producto] ADD CONSTRAINT [FK_Producto_Emprendimiento_EmprendimientoId]
        FOREIGN KEY ([EmprendimientoId]) REFERENCES [Emprendimiento]([Id]);
IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = 'FK_Proveedor_Emprendimiento_EmprendimientoId')
    ALTER TABLE [Proveedor] ADD CONSTRAINT [FK_Proveedor_Emprendimiento_EmprendimientoId]
        FOREIGN KEY ([EmprendimientoId]) REFERENCES [Emprendimiento]([Id]);
GO

/* ---------- Req. 5: acotar columnas nvarchar(max) para poder indexarlas ---------- */
IF EXISTS (SELECT 1 FROM sys.columns WHERE object_id=OBJECT_ID('Usuario') AND name='Email' AND max_length=-1)
    ALTER TABLE [Usuario] ALTER COLUMN [Email] nvarchar(150) NOT NULL;
IF EXISTS (SELECT 1 FROM sys.columns WHERE object_id=OBJECT_ID('Rol') AND name='Nombre' AND max_length=-1)
    ALTER TABLE [Rol] ALTER COLUMN [Nombre] nvarchar(100) NOT NULL;
IF EXISTS (SELECT 1 FROM sys.columns WHERE object_id=OBJECT_ID('Permiso') AND name='Nombre' AND max_length=-1)
    ALTER TABLE [Permiso] ALTER COLUMN [Nombre] nvarchar(100) NOT NULL;
IF EXISTS (SELECT 1 FROM sys.columns WHERE object_id=OBJECT_ID('MetodoPago') AND name='Nombre' AND max_length=-1)
    ALTER TABLE [MetodoPago] ALTER COLUMN [Nombre] nvarchar(100) NOT NULL;
IF EXISTS (SELECT 1 FROM sys.columns WHERE object_id=OBJECT_ID('Categoria') AND name='Nombre' AND max_length=-1)
    ALTER TABLE [Categoria] ALTER COLUMN [Nombre] nvarchar(100) NOT NULL;
IF EXISTS (SELECT 1 FROM sys.columns WHERE object_id=OBJECT_ID('Producto') AND name='Nombre' AND max_length=-1)
    ALTER TABLE [Producto] ALTER COLUMN [Nombre] nvarchar(200) NOT NULL;
IF EXISTS (SELECT 1 FROM sys.columns WHERE object_id=OBJECT_ID('Pedido') AND name='Estado' AND max_length=-1)
    ALTER TABLE [Pedido] ALTER COLUMN [Estado] nvarchar(20) NOT NULL;
IF EXISTS (SELECT 1 FROM sys.columns WHERE object_id=OBJECT_ID('MovimientoInventario') AND name='Tipo' AND max_length=-1)
    ALTER TABLE [MovimientoInventario] ALTER COLUMN [Tipo] nvarchar(20) NOT NULL;
GO

/* ---------- Req. 5: UNIQUE ---------- */
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'UX_Usuario_Email')
    CREATE UNIQUE INDEX [UX_Usuario_Email] ON [Usuario]([Email]);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'UX_Rol_Nombre')
    CREATE UNIQUE INDEX [UX_Rol_Nombre] ON [Rol]([Nombre]);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'UX_Permiso_Nombre')
    CREATE UNIQUE INDEX [UX_Permiso_Nombre] ON [Permiso]([Nombre]);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'UX_MetodoPago_Nombre')
    CREATE UNIQUE INDEX [UX_MetodoPago_Nombre] ON [MetodoPago]([Nombre]);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'UX_Categoria_Emprendimiento_Nombre')
    CREATE UNIQUE INDEX [UX_Categoria_Emprendimiento_Nombre] ON [Categoria]([EmprendimientoId],[Nombre]);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'UX_Inventario_Producto_Sucursal')
    CREATE UNIQUE INDEX [UX_Inventario_Producto_Sucursal] ON [Inventario]([ProductoId],[SucursalId]);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'UX_Empleado_Usuario')
    CREATE UNIQUE INDEX [UX_Empleado_Usuario] ON [Empleado]([UsuarioId]);
GO

/* ---------- Req. 5: CHECK ---------- */
IF NOT EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = 'CK_Producto_Precio')
    ALTER TABLE [Producto] ADD CONSTRAINT [CK_Producto_Precio] CHECK ([Precio] >= 0);
IF NOT EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = 'CK_Producto_Stock')
    ALTER TABLE [Producto] ADD CONSTRAINT [CK_Producto_Stock] CHECK ([Stock] IS NULL OR [Stock] >= 0);
IF NOT EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = 'CK_Inventario_Stock')
    ALTER TABLE [Inventario] ADD CONSTRAINT [CK_Inventario_Stock] CHECK ([StockActual] >= 0);
IF NOT EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = 'CK_Inventario_StockMinimo')
    ALTER TABLE [Inventario] ADD CONSTRAINT [CK_Inventario_StockMinimo] CHECK ([StockMinimo] IS NULL OR [StockMinimo] >= 0);
IF NOT EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = 'CK_Movimiento_Cantidad')
    ALTER TABLE [MovimientoInventario] ADD CONSTRAINT [CK_Movimiento_Cantidad] CHECK ([Cantidad] > 0);
IF NOT EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = 'CK_Movimiento_Tipo')
    ALTER TABLE [MovimientoInventario] ADD CONSTRAINT [CK_Movimiento_Tipo] CHECK ([Tipo] IN ('ENTRADA','SALIDA'));
IF NOT EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = 'CK_DetalleVenta_Cantidad')
    ALTER TABLE [DetalleVenta] ADD CONSTRAINT [CK_DetalleVenta_Cantidad] CHECK ([Cantidad] > 0);
IF NOT EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = 'CK_Venta_Total')
    ALTER TABLE [Venta] ADD CONSTRAINT [CK_Venta_Total] CHECK ([Total] >= 0);
IF NOT EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = 'CK_Pedido_Estado')
    ALTER TABLE [Pedido] ADD CONSTRAINT [CK_Pedido_Estado]
        CHECK ([Estado] IN ('PENDIENTE','EN PREPARACION','LISTO','ENTREGADO','CANCELADO'));
IF NOT EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = 'CK_Pedido_Modalidad')
    ALTER TABLE [Pedido] ADD CONSTRAINT [CK_Pedido_Modalidad] CHECK ([Modalidad] IN ('RETIRO','DELIVERY'));
IF NOT EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = 'CK_Resena_Calificacion')
    ALTER TABLE [Resena] ADD CONSTRAINT [CK_Resena_Calificacion] CHECK ([Calificacion] IS NULL OR [Calificacion] BETWEEN 1 AND 5);
IF NOT EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = 'CK_Promocion_Descuento')
    ALTER TABLE [Promocion] ADD CONSTRAINT [CK_Promocion_Descuento] CHECK ([Descuento] >= 0 AND [Descuento] <= 100);
IF NOT EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = 'CK_Promocion_Fechas')
    ALTER TABLE [Promocion] ADD CONSTRAINT [CK_Promocion_Fechas] CHECK ([FechaFin] >= [FechaInicio]);
GO

/* ---------- Req. 7: índices para rendimiento ---------- */
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_Venta_Fecha')
    CREATE INDEX [IX_Venta_Fecha] ON [Venta]([Fecha]) INCLUDE ([SucursalId],[Total]);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_Pedido_Estado')
    CREATE INDEX [IX_Pedido_Estado] ON [Pedido]([Estado]) INCLUDE ([VentaId],[Modalidad],[FechaCreacion]);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_Movimiento_Fecha')
    CREATE INDEX [IX_Movimiento_Fecha] ON [MovimientoInventario]([Fecha]);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_Producto_Nombre')
    CREATE INDEX [IX_Producto_Nombre] ON [Producto]([Nombre]);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_Notificacion_Usuario_Leido')
    CREATE INDEX [IX_Notificacion_Usuario_Leido] ON [Notificacion]([UsuarioId],[Leido]);
GO

PRINT 'Migración 02_requisitos aplicada.';
GO
