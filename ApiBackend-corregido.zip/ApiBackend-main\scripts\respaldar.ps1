<#
.SYNOPSIS
  Respaldo de la base de datos de la Panadería Kiataque (requisito 10).

.DESCRIPTION
  Hace un BACKUP DATABASE con CHECKSUM, lo verifica con RESTORE VERIFYONLY y borra los
  respaldos propios de más de -DiasRetencion días. Pensado para correr a mano o desde el
  Programador de tareas de Windows (ver docs/RESPALDO_Y_RECUPERACION.md).

.EXAMPLE
  .\scripts\respaldar.ps1
  .\scripts\respaldar.ps1 -Servidor "localhost,1433" -Usuario sa -Clave "Kiataque2026!" -Carpeta /var/opt/mssql/backup
#>
param(
    [string]$Servidor = ".\SQLEXPRESS",
    [string]$Base = "DB_Panaderia2",
    [string]$Carpeta = "",          # vacío = carpeta de respaldos por defecto de la instancia
    [string]$Usuario = "",          # vacío = autenticación de Windows
    [string]$Clave = "",
    [int]$DiasRetencion = 14
)
$ErrorActionPreference = 'Stop'

function Invocar-Sql([string]$consulta) {
    $args = @("-S", $Servidor, "-C", "-b", "-h", "-1", "-W", "-Q", $consulta)
    if ($Usuario) { $args += @("-U", $Usuario, "-P", $Clave) } else { $args += "-E" }
    $salida = & sqlcmd @args
    if ($LASTEXITCODE -ne 0) { throw "sqlcmd falló: $salida" }
    return $salida
}

if (-not $Carpeta) {
    $Carpeta = (Invocar-Sql "SET NOCOUNT ON; SELECT CAST(SERVERPROPERTY('InstanceDefaultBackupPath') AS nvarchar(512))" | Select-Object -First 1).Trim()
}
$sep = if ($Carpeta -match '\\') { '\' } else { '/' }
$archivo = "{0}_{1:yyyyMMdd_HHmmss}.bak" -f $Base, (Get-Date)
$ruta = $Carpeta.TrimEnd('\', '/') + $sep + $archivo

Write-Host "Respaldando '$Base' en $ruta ..."
Invocar-Sql "BACKUP DATABASE [$Base] TO DISK = N'$ruta' WITH INIT, CHECKSUM, STATS = 25" | Out-Null
Invocar-Sql "RESTORE VERIFYONLY FROM DISK = N'$ruta' WITH CHECKSUM" | Out-Null
Write-Host "Respaldo creado y verificado: $ruta" -ForegroundColor Green

# Retención: solo se tocan archivos de esta base (Base_*.bak) que sean accesibles desde esta máquina.
if ($DiasRetencion -gt 0 -and (Test-Path -LiteralPath $Carpeta)) {
    Get-ChildItem -LiteralPath $Carpeta -Filter "${Base}_*.bak" -ErrorAction SilentlyContinue |
        Where-Object { $_.LastWriteTime -lt (Get-Date).AddDays(-$DiasRetencion) } |
        ForEach-Object { Write-Host "Borrando respaldo antiguo: $($_.Name)"; Remove-Item -LiteralPath $_.FullName -Force }
}
