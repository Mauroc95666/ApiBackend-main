using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.EntityFrameworkCore;
using BackendApi.Models;
using BackendApi.Services;

namespace BackendApi.Controllers;

public class DetalleVentaDto
{
    public int ProductoId { get; set; }
    public int Cantidad { get; set; }
}

public class VentaCrearDto
{
    public int SucursalId { get; set; }
    public int ClienteId { get; set; }
    public int MetodoPagoId { get; set; }
    public DateTime? Fecha { get; set; }
    // Req. 2: RETIRO (por defecto) o DELIVERY. En delivery la dirección es obligatoria.
    public string? Modalidad { get; set; }
    public string? DireccionEntrega { get; set; }
    // Venta de mostrador: se cobra y se entrega en el momento, así que no genera pedido
    // (no ensucia la cola de preparación ni los tiempos de servicio).
    public bool Mostrador { get; set; }
    public List<DetalleVentaDto> Detalles { get; set; } = new();
}

[ApiController]
[Route("api/[controller]")]
[Authorize]
public class VentasController : ControllerBase
{
    private readonly ApplicationDbContext _context;
    private readonly AuditoriaService _auditoria;

    public VentasController(ApplicationDbContext context, AuditoriaService auditoria)
    {
        _context = context;
        _auditoria = auditoria;
    }

    // Req. 9: el personal de una sucursal solo ve las ventas de su sucursal; el administrador ve todas.
    [Authorize(Policy = "Ventas")]
    [HttpGet]
    public async Task<IActionResult> ObtenerVentas([FromQuery] DateTime? desde, [FromQuery] DateTime? hasta, [FromQuery] int? sucursalId)
    {
        var q = _context.Ventas.AsNoTracking().AsQueryable();
        var restringida = RolHelper.SucursalRestringida(User);
        if (restringida.HasValue) q = q.Where(v => v.SucursalId == restringida.Value);
        else if (sucursalId.HasValue) q = q.Where(v => v.SucursalId == sucursalId.Value);
        if (desde.HasValue) q = q.Where(v => v.Fecha >= desde.Value);
        if (hasta.HasValue) q = q.Where(v => v.Fecha <= hasta.Value);

        var ventas = await q.OrderByDescending(v => v.Fecha).Take(2000).ToListAsync();
        return Ok(ventas);
    }

    [Authorize(Policy = "Ventas")]
    [HttpGet("{id}")]
    public async Task<IActionResult> ObtenerVentaPorId(int id)
    {
        var venta = await _context.Ventas.AsNoTracking().FirstOrDefaultAsync(v => v.Id == id);

        if (venta == null)
            return NotFound(new { mensaje = $"Venta con id {id} no encontrada" });

        var restringida = RolHelper.SucursalRestringida(User);
        if (restringida.HasValue && venta.SucursalId != restringida.Value)
            return NotFound(new { mensaje = $"Venta con id {id} no encontrada" });

        return Ok(venta);
    }

    // Público: la tienda en línea registra compras sin sesión (con límite de peticiones por IP).
    // Los precios y el total se calculan acá con los datos de la base, no con lo que mande el cliente.
    // Venta, detalle, pedido, descuento de stock y movimientos se guardan en una sola transacción.
    [AllowAnonymous]
    [EnableRateLimiting("publico")]
    [HttpPost]
    public async Task<IActionResult> CrearVenta([FromBody] VentaCrearDto dto)
    {
        if (dto == null || dto.Detalles.Count == 0)
            return BadRequest(new { mensaje = "La venta necesita al menos un producto" });

        if (dto.Detalles.Any(d => d.Cantidad <= 0))
            return BadRequest(new { mensaje = "Las cantidades deben ser mayores a 0" });

        var modalidad = (dto.Modalidad ?? "RETIRO").Trim().ToUpperInvariant();
        if (modalidad != "RETIRO" && modalidad != "DELIVERY")
            return BadRequest(new { mensaje = "La modalidad debe ser RETIRO o DELIVERY" });

        // Si hay sesión, el vendedor es quien está logueado; si no, el primer usuario activo (venta de tienda).
        int usuarioId;
        if (int.TryParse(User.FindFirstValue(ClaimTypes.NameIdentifier), out var uid) && uid > 0)
            usuarioId = uid;
        else
        {
            usuarioId = await _context.Usuarios.Where(u => u.Activo).OrderBy(u => u.Id).Select(u => u.Id).FirstOrDefaultAsync();
            if (usuarioId == 0)
                return BadRequest(new { mensaje = "Todavía no hay usuarios activos: creá el primer administrador antes de vender." });
        }

        // Req. 9: un empleado solo puede vender en su propia sucursal.
        var restringida = RolHelper.SucursalRestringida(User);
        if (restringida.HasValue && restringida.Value != dto.SucursalId)
            return Forbid();

        if (!await _context.Sucursales.AnyAsync(s => s.Id == dto.SucursalId))
            return BadRequest(new { mensaje = $"No existe la sucursal {dto.SucursalId}" });
        var cliente = await _context.Clientes.FirstOrDefaultAsync(c => c.Id == dto.ClienteId);
        if (cliente == null)
            return BadRequest(new { mensaje = $"No existe el cliente {dto.ClienteId}" });
        if (!await _context.MetodosPago.AnyAsync(m => m.Id == dto.MetodoPagoId))
            return BadRequest(new { mensaje = $"No existe el método de pago {dto.MetodoPagoId}" });

        var direccion = string.IsNullOrWhiteSpace(dto.DireccionEntrega) ? cliente.Direccion : dto.DireccionEntrega;
        if (!dto.Mostrador && modalidad == "DELIVERY" && string.IsNullOrWhiteSpace(direccion))
            return BadRequest(new { mensaje = "Para delivery hace falta la dirección de entrega" });

        // Agrupar por producto por si viene repetido.
        var pedido = dto.Detalles.GroupBy(d => d.ProductoId).ToDictionary(g => g.Key, g => g.Sum(x => x.Cantidad));
        var ids = pedido.Keys.ToList();
        var productos = await _context.Productos.Where(p => ids.Contains(p.Id)).ToDictionaryAsync(p => p.Id);
        var faltante = ids.Where(i => !productos.ContainsKey(i)).Cast<int?>().FirstOrDefault();
        if (faltante.HasValue)
            return BadRequest(new { mensaje = $"No existe el producto {faltante}" });

        await using var tx = await _context.Database.BeginTransactionAsync();

        var ahora = DateTime.UtcNow;
        var venta = new Venta
        {
            SucursalId = dto.SucursalId,
            ClienteId = dto.ClienteId,
            UsuarioId = usuarioId,
            MetodoPagoId = dto.MetodoPagoId,
            // Solo se acepta una fecha pasada (carga atrasada desde el panel); si no, la del servidor.
            Fecha = dto.Fecha.HasValue && dto.Fecha.Value.ToUniversalTime() <= ahora ? dto.Fecha.Value : ahora,
        };

        foreach (var (productoId, cantidad) in pedido)
        {
            var producto = productos[productoId];
            venta.DetallesVenta.Add(new DetalleVenta
            {
                ProductoId = productoId,
                Cantidad = cantidad,
                PrecioUnitario = producto.Precio,
                Subtotal = producto.Precio * cantidad,
            });
        }
        venta.Total = venta.DetallesVenta.Sum(d => d.Subtotal ?? 0);
        _context.Ventas.Add(venta);

        // Req. 2 y 11: el pedido nace con su modalidad y la hora de ingreso (inicio del tiempo de servicio).
        Pedido? nuevoPedido = null;
        if (!dto.Mostrador)
        {
            nuevoPedido = new Pedido
            {
                Venta = venta,
                Estado = "PENDIENTE",
                Modalidad = modalidad,
                DireccionEntrega = modalidad == "DELIVERY" ? direccion!.Trim() : null,
                FechaCreacion = ahora,
            };
            _context.Pedidos.Add(nuevoPedido);
        }

        // Descuento de stock en la sucursal. Si un producto no tiene fila de inventario ahí,
        // no se controla stock (la panadería puede vender sin haber cargado el inventario).
        var invs = await _context.Inventarios
            .Where(i => i.SucursalId == dto.SucursalId && ids.Contains(i.ProductoId))
            .ToListAsync();
        var bajos = new List<string>();
        foreach (var inv in invs)
        {
            var cant = pedido[inv.ProductoId];
            if (inv.StockActual < cant)
                return Conflict(new { mensaje = $"Stock insuficiente de '{productos[inv.ProductoId].Nombre}' (disponible: {inv.StockActual})" });

            inv.StockActual -= cant;
            _context.MovimientoInventario.Add(new MovimientoInventario
            {
                InventarioId = inv.Id,
                UsuarioId = usuarioId,
                Tipo = "SALIDA",
                Cantidad = cant,
                Fecha = ahora,
                Motivo = "Venta",
            });
            if (inv.StockMinimo.HasValue && inv.StockActual <= inv.StockMinimo.Value)
                bajos.Add($"Stock bajo de '{productos[inv.ProductoId].Nombre}': quedan {inv.StockActual} (mínimo {inv.StockMinimo})");
        }

        // Req. 4: alerta a quienes controlan el inventario cuando algo queda bajo el mínimo.
        if (bajos.Count > 0)
        {
            var destinatarios = (await _context.Usuarios.Include(u => u.Rol).Where(u => u.Activo).ToListAsync())
                .Where(u => RolHelper.PuedeInventario(u.Rol.Nombre)).Select(u => u.Id).ToList();
            foreach (var mensaje in bajos)
                foreach (var destino in destinatarios)
                    _context.Notificaciones.Add(new Notificacion { UsuarioId = destino, Mensaje = mensaje, Leido = false, Fecha = ahora });
        }

        await _context.SaveChangesAsync();
        await tx.CommitAsync();

        return CreatedAtAction(nameof(ObtenerVentaPorId), new { id = venta.Id },
            new
            {
                venta.Id, venta.SucursalId, venta.ClienteId, venta.UsuarioId, venta.MetodoPagoId, venta.Fecha, venta.Total,
                pedidoId = nuevoPedido?.Id, modalidad = nuevoPedido?.Modalidad,
            });
    }

    [Authorize(Policy = "Admin")]
    [HttpPut("{id}")]
    public async Task<IActionResult> ActualizarVenta(int id, [FromBody] Venta ventaActualizada)
    {
        var venta = await _context.Ventas.FindAsync(id);

        if (venta == null)
            return NotFound(new { mensaje = $"Venta con id {id} no encontrada" });

        venta.SucursalId = ventaActualizada.SucursalId;
        venta.ClienteId = ventaActualizada.ClienteId;
        venta.UsuarioId = ventaActualizada.UsuarioId;
        venta.MetodoPagoId = ventaActualizada.MetodoPagoId;
        venta.Fecha = ventaActualizada.Fecha;
        venta.Total = ventaActualizada.Total;

        await _context.SaveChangesAsync();
        await _auditoria.RegistrarAsync("ACTUALIZAR", "Venta", $"Venta {id}");

        return Ok(new { mensaje = "Venta actualizada correctamente", venta });
    }

    [Authorize(Policy = "Admin")]
    [HttpDelete("{id}")]
    public async Task<IActionResult> EliminarVenta(int id)
    {
        var venta = await _context.Ventas.FindAsync(id);

        if (venta == null)
            return NotFound(new { mensaje = $"Venta con id {id} no encontrada" });

        _context.Ventas.Remove(venta);
        await _context.SaveChangesAsync();
        await _auditoria.RegistrarAsync("ELIMINAR", "Venta", $"Venta {id}");

        return Ok(new { mensaje = $"Venta {id} eliminada correctamente" });
    }
}
