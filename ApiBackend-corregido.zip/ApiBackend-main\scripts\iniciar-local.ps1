<#
.SYNOPSIS
  Levanta backend (.NET) y frontend (Vite) en tu PC usando SQL Server Express, sin Docker.

.DESCRIPTION
  - Crea la base DB_Panaderia2 si no existe (db/init.sql + db/02_requisitos.sql, ambos idempotentes).
  - Inicia la API en http://localhost:5208 (Swagger en /swagger) y el frontend en http://localhost:5173.
  - Los dos quedan corriendo en segundo plano; para detenerlos usá  .\scripts\detener-local.ps1

  Super-usuario oculto (requisito 6): si todavía no hay administrador, pasá -SetupUsuario y -SetupClave
  para poder entrar y crear el primero. Con administrador creado no hace falta.

.EXAMPLE
  .\scripts\iniciar-local.ps1
  .\scripts\iniciar-local.ps1 -SetupUsuario instalador@kiataque.local -SetupClave "Una-Clave-Larga-2026"
#>
param(
    [string]$Servidor = ".\SQLEXPRESS",
    [string]$Base = "DB_Panaderia2",
    [string]$SetupUsuario = "",
    [string]$SetupClave = "",
    [string]$JwtKey = ""
)
$ErrorActionPreference = 'Stop'
$raiz = Split-Path -Parent $PSScriptRoot

# 1) Base de datos
$existe = (sqlcmd -S $Servidor -E -C -h -1 -W -Q "SET NOCOUNT ON; SELECT COUNT(*) FROM sys.databases WHERE name = N'$Base'" | Select-Object -First 1).Trim()
if ($existe -ne '1') {
    Write-Host "Creando la base $Base ..."
    sqlcmd -S $Servidor -E -C -b -i (Join-Path $raiz "db\init.sql") | Out-Null
}
sqlcmd -S $Servidor -E -C -b -i (Join-Path $raiz "db\02_requisitos.sql") | Out-Null

# 2) Variables de entorno de la API (solo para estos procesos)
if (-not $JwtKey) {
    # Clave estable por equipo: guardada la primera vez para que las sesiones sobrevivan a un reinicio.
    $archivoClave = Join-Path $env:LOCALAPPDATA "kiataque_jwt.key"
    if (-not (Test-Path $archivoClave)) {
        $bytes = New-Object byte[] 48
        [Security.Cryptography.RandomNumberGenerator]::Create().GetBytes($bytes)
        [Convert]::ToBase64String($bytes) | Set-Content $archivoClave
    }
    $JwtKey = (Get-Content $archivoClave -Raw).Trim()
}
$env:ConnectionStrings__ConexionDB = "Server=$Servidor;Database=$Base;Trusted_Connection=True;TrustServerCertificate=True;"
$env:Jwt__Key = $JwtKey
$env:ASPNETCORE_ENVIRONMENT = "Development"
if ($SetupUsuario) { $env:Setup__Usuario = $SetupUsuario; $env:Setup__Clave = $SetupClave }

# 3) Procesos
$logs = Join-Path $env:TEMP "kiataque"
New-Item -ItemType Directory -Force $logs | Out-Null
Start-Process dotnet -ArgumentList "run --project `"$raiz\BackendApi`" --no-launch-profile --urls http://localhost:5208" `
    -WindowStyle Hidden -RedirectStandardOutput "$logs\backend.log" -RedirectStandardError "$logs\backend.err"

$front = Join-Path $raiz "FrontendVue"
if (-not (Test-Path (Join-Path $front "node_modules"))) {
    Write-Host "Instalando dependencias del frontend ..."
    Push-Location $front; npm install --legacy-peer-deps; Pop-Location
}
Start-Process npm.cmd -ArgumentList "run dev" -WorkingDirectory $front -WindowStyle Hidden `
    -RedirectStandardOutput "$logs\frontend.log" -RedirectStandardError "$logs\frontend.err"

Write-Host ""
Write-Host "Levantando... en unos segundos:" -ForegroundColor Green
Write-Host "  Frontend : http://localhost:5173"
Write-Host "  API      : http://localhost:5208/swagger"
Write-Host "  Logs     : $logs"
