using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OutputCaching;
using Microsoft.EntityFrameworkCore;
using BackendApi.Models;

namespace BackendApi.Controllers;

[ApiController]
[Route("api/[controller]")]
public class ProductosController : ControllerBase
{
    private readonly ApplicationDbContext _context;

    private readonly IOutputCacheStore _cache;

    public ProductosController(ApplicationDbContext context, IOutputCacheStore cache)
    {
        _context = context;
        _cache = cache;
    }

    // Req. 5: reglas de negocio además de los CHECK de la base.
    private static string? ValidarProducto(Producto p)
    {
        if (string.IsNullOrWhiteSpace(p.Nombre)) return "El nombre del producto es requerido";
        if (p.Precio < 0) return "El precio no puede ser negativo";
        if (p.Stock < 0) return "El stock no puede ser negativo";
        return null;
    }

    // Req. 7: el catálogo es público y se cachea 30 s (se invalida al editar productos).
    [AllowAnonymous]
    [OutputCache(PolicyName = "catalogo")]
    [HttpGet]
    public async Task<IActionResult> ObtenerProductos()
    {
        var productos = await _context.Productos.AsNoTracking().OrderBy(p => p.Nombre).ToListAsync();
        return Ok(productos);
    }

    [Authorize(Policy = "Staff")]
    [HttpGet("{id}")]
    public async Task<IActionResult> ObtenerProductoPorId(int id)
    {
        var producto = await _context.Productos.FindAsync(id);

        if (producto == null)
            return NotFound(new { mensaje = $"No se encontró el producto con ID {id}" });

        return Ok(producto);
    }

    [Authorize(Policy = "Inventario")]
    [HttpPost]
    public async Task<IActionResult> RegistrarProducto([FromBody] Producto producto)
    {
        if (producto == null)
            return BadRequest(new { mensaje = "Los datos del producto son requeridos" });

        var errorValidacion = ValidarProducto(producto);
        if (errorValidacion != null)
            return BadRequest(new { mensaje = errorValidacion });

        if (producto.ProveedorId.HasValue)
        {
            var proveedorExiste = await _context.Proveedores.FindAsync(producto.ProveedorId.Value);
            if (proveedorExiste == null)
                return BadRequest(new { mensaje = $"No existe el Proveedor con ID {producto.ProveedorId.Value}" });
        }

        try
        {
            // EF Core asigna el Id generado por la base (antes se devolvía siempre 0).
            producto.Id = 0;
            _context.Productos.Add(producto);
            await _context.SaveChangesAsync();
            await _cache.EvictByTagAsync("catalogo", default);
            return CreatedAtAction(nameof(ObtenerProductoPorId), new { id = producto.Id }, producto);
        }
        catch (Microsoft.EntityFrameworkCore.DbUpdateException)
        {
            return Conflict(new { mensaje = "No se pudo guardar el producto: revisá la categoría, el proveedor y los valores." });
        }
    }

    [Authorize(Policy = "Inventario")]
    [HttpPut("{id}")]
    public async Task<IActionResult> ActualizarProducto(int id, [FromBody] Producto producto)
    {
        var existente = await _context.Productos.FindAsync(id);

        if (existente == null)
            return NotFound(new { mensaje = $"No se encontró el producto con ID {id}" });

        var errorValidacion = ValidarProducto(producto);
        if (errorValidacion != null)
            return BadRequest(new { mensaje = errorValidacion });

        // Actualizar únicamente las propiedades reales de Producto.cs (DB_Panaderia2)
        existente.Nombre = producto.Nombre;
        existente.Precio = producto.Precio;
        existente.Stock = producto.Stock;
        existente.EmprendimientoId = producto.EmprendimientoId;
        existente.CategoriaId = producto.CategoriaId;
        existente.ProveedorId = producto.ProveedorId;
        existente.ImagenUrl = producto.ImagenUrl;

        await _context.SaveChangesAsync();
        await _cache.EvictByTagAsync("catalogo", default);

        return Ok(new
        {
            mensaje = "Producto actualizado correctamente",
            producto = existente
        });
    }

    [Authorize(Policy = "Inventario")]
    [HttpDelete("{id}")]
    public async Task<IActionResult> EliminarProducto(int id)
    {
        var producto = await _context.Productos.FindAsync(id);

        if (producto == null)
            return NotFound(new { mensaje = $"No se encontró el producto con ID {id}" });

        _context.Productos.Remove(producto);
        await _context.SaveChangesAsync();
        await _cache.EvictByTagAsync("catalogo", default);

        return Ok(new { mensaje = $"Producto {id} eliminado correctamente" });
    }
}