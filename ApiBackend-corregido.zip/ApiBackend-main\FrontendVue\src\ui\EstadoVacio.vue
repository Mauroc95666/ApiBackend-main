<script setup>
import AppIcon from './AppIcon.vue';
defineProps({
  icono: { type: String, default: 'package' },
  titulo: String,
  texto: String,
});
</script>

<template>
  <div class="vacio">
    <div class="vacio-icono"><AppIcon :name="icono" :size="26" /></div>
    <h3>{{ titulo }}</h3>
    <p v-if="texto">{{ texto }}</p>
    <slot />
  </div>
</template>
