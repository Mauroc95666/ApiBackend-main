<script setup>
import { ref, onMounted } from 'vue';
import api from '@/api/axios';
import { toast, confirmar } from '@/ui/feedback';
import { fechaHora, mensajeError } from '@/utils/format';
import AppIcon from '@/ui/AppIcon.vue';
import EncabezadoPagina from '@/ui/EncabezadoPagina.vue';
import EstadoVacio from '@/ui/EstadoVacio.vue';
import Insignia from '@/ui/Insignia.vue';

// Respaldos de la base, rendimiento medido y bitácora de auditoría.
const respaldos = ref([]);
const metricas = ref(null);
const auditoria = ref([]);
const usuarios = ref([]);
const cargando = ref(true);
const respaldando = ref(false);
const tab = ref('respaldos');

async function cargar() {
  cargando.value = true;
  const pedir = (url) => api.get(url).then((r) => r.data).catch((e) => { toast.error(mensajeError(e, `No se pudo cargar ${url}`)); return null; });
  const [r, m, a, u] = await Promise.all([pedir('/respaldos'), pedir('/metricas'), pedir('/auditorias'), api.get('/usuarios').then((x) => x.data).catch(() => [])]);
  respaldos.value = r || [];
  metricas.value = m;
  auditoria.value = (a || []).slice().sort((x, y) => (y.fecha || '').localeCompare(x.fecha || '')).slice(0, 100);
  usuarios.value = u || [];
  cargando.value = false;
}

async function respaldar() {
  const si = await confirmar({ titulo: 'Hacer un respaldo ahora', mensaje: 'Se guarda una copia completa de la base de datos y se verifica. Puede tardar unos segundos.', textoOk: 'Hacer respaldo' });
  if (!si) return;
  respaldando.value = true;
  try {
    const { data } = await api.post('/respaldos');
    data.verificado ? toast.ok(`Respaldo creado y verificado: ${data.archivo}`) : toast.aviso('El respaldo se creó pero no pasó la verificación. Repetilo.');
    await cargar();
  } catch (e) {
    toast.error(mensajeError(e, 'No se pudo crear el respaldo.'));
  } finally {
    respaldando.value = false;
  }
}

const mb = (b) => (b / 1048576).toLocaleString('es-BO', { maximumFractionDigits: 2 }) + ' MB';
const nombreArchivo = (ruta) => String(ruta).split(/[\\/]/).pop();
const nombreUsuario = (id) => (id == null ? 'Sistema' : usuarios.value.find((u) => u.id === id)?.nombre || `Usuario #${id}`);
const tonoAccion = (a) => (/ELIMINAR|FALLIDO/.test(a) ? 'peligro' : /CREAR|RESPALDO/.test(a) ? 'ok' : /ANONIMIZAR|ACCESO/.test(a) ? 'aviso' : 'info');

const METAS = [
  { clave: 'catalogoMenorA2s', texto: 'Catálogo en menos de 2 s' },
  { clave: 'ventaMenorA3s', texto: 'Venta en menos de 3 s' },
  { clave: 'apiP95MenorA500ms', texto: 'API p95 en menos de 500 ms' },
];

onMounted(cargar);
</script>

<template>
  <div>
    <EncabezadoPagina titulo="Sistema y respaldos" subtitulo="Copias de seguridad, rendimiento y registro de actividad">
      <button type="button" class="btn btn-secundario" :disabled="cargando" @click="cargar"><AppIcon name="refresh" :size="16" :class="{ girando: cargando }" /> Actualizar</button>
    </EncabezadoPagina>

    <div class="pestanas" role="tablist" style="margin-bottom: 20px">
      <button type="button" role="tab" class="pestana" :class="{ activa: tab === 'respaldos' }" @click="tab = 'respaldos'">Respaldos</button>
      <button type="button" role="tab" class="pestana" :class="{ activa: tab === 'rendimiento' }" @click="tab = 'rendimiento'">Rendimiento</button>
      <button type="button" role="tab" class="pestana" :class="{ activa: tab === 'auditoria' }" @click="tab = 'auditoria'">Actividad <span class="contador">{{ auditoria.length }}</span></button>
    </div>

    <section v-if="tab === 'respaldos'" class="tarjeta">
      <div class="tarjeta-cabecera">
        <div>
          <h3>Copias de seguridad</h3>
          <p class="texto-chico texto-suave">Hay una automática por día. Para restaurar, usá <code>scripts/restaurar.ps1</code> en el servidor.</p>
        </div>
        <button type="button" class="btn btn-primario" :disabled="respaldando" @click="respaldar">
          <AppIcon :name="respaldando ? 'refresh' : 'database'" :size="16" :class="{ girando: respaldando }" /> {{ respaldando ? 'Respaldando...' : 'Hacer respaldo ahora' }}
        </button>
      </div>
      <div v-if="cargando" class="tarjeta-cuerpo pila-sm"><span class="esqueleto"></span><span class="esqueleto"></span></div>
      <EstadoVacio v-else-if="!respaldos.length" icono="database" titulo="Todavía no hay respaldos" texto="Hacé el primero ahora para tener una copia de seguridad." />
      <div v-else class="tabla-contenedor">
        <table class="tabla">
          <thead><tr><th>Fecha</th><th class="num">Tamaño</th><th>Archivo</th></tr></thead>
          <tbody><tr v-for="r in respaldos" :key="r.archivo"><td>{{ fechaHora(r.fecha) }}</td><td class="num">{{ mb(r.tamanoBytes) }}</td><td class="texto-chico texto-suave" :title="r.archivo">{{ nombreArchivo(r.archivo) }}</td></tr></tbody>
        </table>
      </div>
      <p class="aviso-linea aviso" style="margin: 16px"><AppIcon name="alert" :size="18" /> <span>Una copia en el mismo disco que la base no protege si el equipo falla. Copiá los archivos <code>.bak</code> a otro lugar con regularidad.</span></p>
    </section>

    <section v-else-if="tab === 'rendimiento'" class="pila">
      <div v-if="metricas" class="metas">
        <div v-for="m in METAS" :key="m.clave" class="meta" :class="metricas.metas[m.clave].cumple ? 'bien' : 'mal'">
          <div>
            <div class="texto-chico">{{ m.texto }}</div>
            <strong class="valor numeros">{{ metricas.metas[m.clave].p95Ms }} ms</strong>
          </div>
          <AppIcon :name="metricas.metas[m.clave].cumple ? 'checkCircle' : 'alert'" :size="26" />
        </div>
      </div>
      <div class="tarjeta">
        <div class="tarjeta-cabecera"><h3>Tiempo de respuesta por ruta</h3><span class="texto-chico texto-suave">Últimas 1000 llamadas · se reinicia con el servidor</span></div>
        <EstadoVacio v-if="!cargando && (!metricas || !metricas.rutas.length)" icono="chart" titulo="Sin mediciones todavía" texto="Usá el sistema un rato y volvé a mirar." />
        <div v-else class="tabla-contenedor">
          <table class="tabla">
            <thead><tr><th>Ruta</th><th class="num">Llamadas</th><th class="num">Promedio</th><th class="num">p95</th><th class="num">p99</th><th class="num">Errores</th></tr></thead>
            <tbody>
              <tr v-for="r in metricas?.rutas || []" :key="r.ruta">
                <td class="texto-chico">{{ r.ruta }}</td><td class="num">{{ r.solicitudes }}</td><td class="num">{{ r.promedioMs }} ms</td>
                <td class="num">{{ r.p95Ms }} ms</td><td class="num">{{ r.p99Ms }} ms</td><td class="num"><span :class="{ rojo: r.errores5xx }">{{ r.errores5xx }}</span></td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </section>

    <section v-else class="tarjeta">
      <div class="tarjeta-cabecera"><h3>Actividad reciente</h3><span class="texto-chico texto-suave">Las últimas 100 acciones registradas</span></div>
      <EstadoVacio v-if="!cargando && !auditoria.length" icono="clock" titulo="Sin actividad registrada" />
      <div v-else class="tabla-contenedor">
        <table class="tabla">
          <thead><tr><th>Fecha</th><th>Usuario</th><th>Acción</th><th>Detalle</th></tr></thead>
          <tbody>
            <tr v-for="a in auditoria" :key="a.id">
              <td class="texto-chico" style="white-space: nowrap">{{ fechaHora(a.fecha) }}</td>
              <td>{{ nombreUsuario(a.usuarioId) }}</td>
              <td><Insignia :tono="tonoAccion(a.accion)" sin-punto>{{ a.accion }}</Insignia> <span class="texto-chico texto-tenue">{{ a.tablaAfectada }}</span></td>
              <td class="texto-chico texto-suave">{{ a.detalles || '—' }}</td>
            </tr>
          </tbody>
        </table>
      </div>
    </section>
  </div>
</template>

<style scoped>
.metas { display: grid; grid-template-columns: repeat(auto-fit, minmax(230px, 1fr)); gap: 16px; }
.meta { display: flex; justify-content: space-between; align-items: center; border-radius: var(--r-md); padding: 16px 18px; }
.meta .valor { font-size: 26px; }
.meta.bien { background: var(--ok-suave); color: var(--ok); }
.meta.mal { background: var(--peligro-suave); color: var(--peligro); }
.rojo { color: var(--peligro); font-weight: 700; }
code { background: var(--superficie-2); padding: 1px 6px; border-radius: 4px; font-size: 0.9em; }
</style>
