<script setup>
import { ref, computed, watch, onMounted, onBeforeUnmount, defineAsyncComponent } from 'vue';
import api from '@/api/axios';
import { store, puedeVer } from '@/store';
import { MENU, MODULOS_PROPIOS, TITULOS, crearConfigs } from '@/modulos';
import { iniciales, haceCuanto } from '@/utils/format';
import AppIcon from '@/ui/AppIcon.vue';
import TablaCrud from './admin/TablaCrud.vue';

// Cada pantalla propia se carga bajo demanda.
const PANTALLAS = {
  inicio: defineAsyncComponent(() => import('./admin/Dashboard.vue')),
  ventas: defineAsyncComponent(() => import('./admin/VentasAdmin.vue')),
  pedidos: defineAsyncComponent(() => import('./admin/PedidosAdmin.vue')),
  inventario: defineAsyncComponent(() => import('./admin/InventarioAdmin.vue')),
  productos: defineAsyncComponent(() => import('./admin/ProductosAdmin.vue')),
  notificaciones: defineAsyncComponent(() => import('./admin/NotificacionesAdmin.vue')),
  reportes: defineAsyncComponent(() => import('./admin/ReportesAdmin.vue')),
  sistema: defineAsyncComponent(() => import('./admin/SistemaAdmin.vue')),
};

// ---------- Navegación por URL (#/clave): se puede recargar o compartir el enlace ----------
const menu = computed(() =>
  MENU.map((s) => ({ ...s, items: s.items.filter((it) => puedeVer(it.clave)) })).filter((s) => s.items.length)
);
const permitidas = computed(() => menu.value.flatMap((s) => s.items.map((i) => i.clave)).concat(puedeVer('notificaciones') ? ['notificaciones'] : []));

function claveDeHash() {
  const c = location.hash.replace(/^#\//, '').split('?')[0];
  return permitidas.value.includes(c) ? c : permitidas.value[0] || 'inicio';
}
const modulo = ref(claveDeHash());

function ir(clave) {
  modulo.value = clave;
  location.hash = '#/' + clave;
  menuAbierto.value = false;
  window.scrollTo({ top: 0 });
}
function alCambiarHash() {
  modulo.value = claveDeHash();
  // Si pidieron un módulo que no les corresponde, la URL se corrige al que se muestra.
  if (location.hash !== '#/' + modulo.value) location.hash = '#/' + modulo.value;
}

// ---------- Datos de referencia para los selects de los módulos CRUD ----------
const ref_ = ref({ roles: [], ciudades: [], emprendimientos: [], usuarios: [], sucursales: [], productos: [], clientes: [] });
const refsListas = ref(false);

async function cargarReferencias() {
  const pedir = (url) => api.get(url).then((r) => r.data || []).catch(() => []);
  const [roles, ciudades, emprendimientos, usuarios, sucursales, productos, clientes] = await Promise.all(
    ['/roles', '/ciudades', '/emprendimientos', '/usuarios', '/sucursales', '/productos', '/clientes'].map(pedir)
  );
  ref_.value = { roles, ciudades, emprendimientos, usuarios, sucursales, productos, clientes };
  refsListas.value = true;
}

const esCrud = computed(() => !MODULOS_PROPIOS.includes(modulo.value));
const configActual = computed(() => (refsListas.value ? crearConfigs(ref_.value)[modulo.value] : null));

watch(
  modulo,
  (m) => {
    if (!MODULOS_PROPIOS.includes(m)) {
      refsListas.value = false;
      cargarReferencias();
    }
  },
  { immediate: true }
);

const tituloActual = computed(() => TITULOS[modulo.value] || configActual.value?.titulo || '');
watch(tituloActual, (t) => { document.title = (t ? t + ' · ' : '') + 'Kiataque'; }, { immediate: true });

// ---------- Notificaciones (campana) ----------
const noLeidas = ref(0);
const recientes = ref([]);
const campanaAbierta = ref(false);
let temporizador = null;

async function actualizarNotificaciones() {
  if (!puedeVer('notificaciones') || document.hidden) return;
  try {
    const [c, l] = await Promise.all([api.get('/notificaciones/no-leidas'), api.get('/notificaciones', { params: { soloNoLeidas: true } })]);
    noLeidas.value = c.data.cantidad;
    recientes.value = (l.data || []).slice(0, 5);
  } catch {
    // sin permiso o servidor apagado: la campana simplemente no muestra nada.
  }
}

// ---------- Menús ----------
const menuAbierto = ref(false); // cajón lateral en pantallas chicas
const usuarioAbierto = ref(false);
const raiz = ref(null);

function cerrarFlotantes(e) {
  if (raiz.value && !e.target.closest?.('[data-flotante]')) {
    campanaAbierta.value = false;
    usuarioAbierto.value = false;
  }
}
function alTeclear(e) {
  if (e.key === 'Escape') {
    campanaAbierta.value = false;
    usuarioAbierto.value = false;
    menuAbierto.value = false;
  }
}

onMounted(() => {
  if (location.hash.replace(/^#\//, '') !== modulo.value) location.hash = '#/' + modulo.value;
  window.addEventListener('hashchange', alCambiarHash);
  document.addEventListener('click', cerrarFlotantes);
  document.addEventListener('keydown', alTeclear);
  document.addEventListener('visibilitychange', actualizarNotificaciones);
  actualizarNotificaciones();
  temporizador = setInterval(actualizarNotificaciones, 60000);
});
onBeforeUnmount(() => {
  window.removeEventListener('hashchange', alCambiarHash);
  document.removeEventListener('click', cerrarFlotantes);
  document.removeEventListener('keydown', alTeclear);
  document.removeEventListener('visibilitychange', actualizarNotificaciones);
  clearInterval(temporizador);
});

// Al volver a la pantalla de notificaciones, la campana se refresca.
watch(modulo, () => actualizarNotificaciones());

const nombreUsuario = computed(() => store.usuario?.nombre || 'Usuario');
</script>

<template>
  <div ref="raiz" class="panel">
    <a class="saltar" href="#contenido-principal" @click.prevent="$refs.principal?.focus()">Saltar al contenido</a>

    <!-- Fondo del cajón lateral (solo móvil) -->
    <div v-if="menuAbierto" class="velo" @click="menuAbierto = false"></div>

    <aside class="lateral" :class="{ abierto: menuAbierto }" aria-label="Menú principal">
      <div class="marca">
        <div class="marca-logo"><AppIcon name="loaf" :size="22" /></div>
        <div>
          <strong>Kiataque</strong>
          <div class="marca-sub">Panadería</div>
        </div>
      </div>

      <nav class="nav">
        <section v-for="s in menu" :key="s.seccion">
          <h4 class="nav-titulo">{{ s.seccion }}</h4>
          <a
            v-for="it in s.items"
            :key="it.clave"
            :href="'#/' + it.clave"
            class="nav-item"
            :class="{ activo: modulo === it.clave }"
            :aria-current="modulo === it.clave ? 'page' : undefined"
            @click.prevent="ir(it.clave)"
          >
            <AppIcon :name="it.icono" :size="18" />
            <span>{{ it.texto }}</span>
          </a>
        </section>
      </nav>

      <div class="lateral-pie">
        <a href="#/tienda" class="nav-item" @click.prevent="store.entrarComoVisitante()">
          <AppIcon name="store" :size="18" /> <span>Ver la tienda</span>
        </a>
      </div>
    </aside>

    <div class="cuerpo">
      <header class="barra">
        <button type="button" class="btn btn-fantasma btn-icono menu-movil" aria-label="Abrir menú" @click="menuAbierto = true">
          <AppIcon name="menu" :size="22" />
        </button>
        <h1 class="barra-titulo">{{ tituloActual }}</h1>

        <div class="barra-derecha">
          <button v-if="puedeVer('ventas') && modulo !== 'ventas'" type="button" class="btn btn-primario btn-sm" @click="ir('ventas')">
            <AppIcon name="plus" :size="16" /> <span class="oculto-movil">Nueva venta</span>
          </button>

          <!-- Campana -->
          <div v-if="puedeVer('notificaciones')" class="flotante" data-flotante>
            <button
              type="button"
              class="btn btn-fantasma btn-icono campana"
              :aria-label="`Notificaciones${noLeidas ? ', ' + noLeidas + ' sin leer' : ''}`"
              :aria-expanded="campanaAbierta"
              @click="campanaAbierta = !campanaAbierta; usuarioAbierto = false"
            >
              <AppIcon name="bell" :size="21" />
              <span v-if="noLeidas" class="punto">{{ noLeidas > 9 ? '9+' : noLeidas }}</span>
            </button>
            <div v-if="campanaAbierta" class="desplegable ancho">
              <div class="desp-cab">Notificaciones</div>
              <div v-if="recientes.length === 0" class="desp-vacio">No tenés notificaciones sin leer.</div>
              <button v-for="n in recientes" :key="n.id" type="button" class="desp-item" @click="campanaAbierta = false; ir('notificaciones')">
                <span>{{ n.mensaje }}</span>
                <small>{{ haceCuanto(n.fecha) }}</small>
              </button>
              <button type="button" class="desp-pie" @click="campanaAbierta = false; ir('notificaciones')">Ver todas</button>
            </div>
          </div>

          <!-- Usuario -->
          <div class="flotante" data-flotante>
            <button type="button" class="usuario-btn" :aria-expanded="usuarioAbierto" @click="usuarioAbierto = !usuarioAbierto; campanaAbierta = false">
              <span class="avatar">{{ iniciales(nombreUsuario) }}</span>
              <span class="usuario-datos oculto-movil">
                <strong>{{ nombreUsuario }}</strong>
                <small>{{ store.rolNombre }}</small>
              </span>
              <AppIcon name="chevronDown" :size="16" class="oculto-movil" />
            </button>
            <div v-if="usuarioAbierto" class="desplegable">
              <div class="desp-cab">
                <strong>{{ nombreUsuario }}</strong>
                <small class="texto-tenue">{{ store.usuario?.email }}</small>
              </div>
              <button type="button" class="desp-item" @click="store.entrarComoVisitante()"><AppIcon name="store" :size="16" /> Ver la tienda</button>
              <button type="button" class="desp-item peligro" @click="store.cerrarSesion()"><AppIcon name="logout" :size="16" /> Cerrar sesión</button>
            </div>
          </div>
        </div>
      </header>

      <main id="contenido-principal" ref="principal" class="area" tabindex="-1">
        <component :is="PANTALLAS[modulo]" v-if="PANTALLAS[modulo]" :key="modulo" @ir="ir" />
        <template v-else-if="esCrud">
          <TablaCrud
            v-if="configActual"
            :key="modulo"
            :titulo="configActual.titulo"
            :subtitulo="configActual.subtitulo"
            :endpoint="configActual.endpoint"
            :campos="configActual.campos"
            :nuevo-modelo="configActual.nuevoModelo"
            :sin-crear="configActual.sinCrear"
            :nombre-item="configActual.nombreItem"
          />
          <div v-else class="tarjeta tarjeta-cuerpo pila">
            <span class="esqueleto" style="width: 40%"></span>
            <span class="esqueleto"></span>
            <span class="esqueleto" style="width: 70%"></span>
          </div>
        </template>
      </main>
    </div>
  </div>
</template>

<style scoped>
.panel { min-height: 100vh; display: grid; grid-template-columns: 252px minmax(0, 1fr); }

.saltar { position: absolute; left: -999px; top: 8px; background: var(--marca); color: #fff; padding: 8px 14px; border-radius: 8px; z-index: 300; }
.saltar:focus { left: 8px; }

/* ----- Lateral ----- */
.lateral {
  position: sticky; top: 0; height: 100vh; overflow-y: auto;
  display: flex; flex-direction: column;
  background: var(--espresso); color: #e9dcc9; padding: 18px 12px;
}
.marca { display: flex; align-items: center; gap: 12px; padding: 4px 8px 18px; color: #fff; }
.marca-logo { width: 38px; height: 38px; border-radius: 11px; display: grid; place-items: center; background: #d98a2b; color: var(--espresso); }
.marca-sub { font-size: 12px; color: #b9a58d; }

.nav { flex: 1; display: grid; gap: 18px; align-content: start; }
.nav-titulo { margin: 0 0 6px; padding: 0 10px; font-size: 11px; font-weight: 700; letter-spacing: 0.08em; text-transform: uppercase; color: #8f7b66; }
.nav-item {
  display: flex; align-items: center; gap: 12px; padding: 9px 10px; border-radius: 9px;
  color: #dccbb4; font-size: 14px; font-weight: 500; text-decoration: none; transition: background 0.12s, color 0.12s;
}
.nav-item:hover { background: var(--espresso-2); color: #fff; text-decoration: none; }
.nav-item.activo { background: #d98a2b; color: var(--espresso); font-weight: 700; }
.lateral-pie { border-top: 1px solid #44301f; padding-top: 10px; margin-top: 12px; }

/* ----- Cuerpo ----- */
.cuerpo { min-width: 0; display: flex; flex-direction: column; }
.barra {
  position: sticky; top: 0; z-index: 30; height: 64px; padding: 0 24px;
  display: flex; align-items: center; gap: 12px;
  background: rgba(250, 246, 239, 0.9); backdrop-filter: blur(8px); border-bottom: 1px solid var(--borde);
}
.barra-titulo { font-size: 18px; flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.barra-derecha { display: flex; align-items: center; gap: 8px; }
.menu-movil { display: none; }
.area { padding: 28px 24px 56px; max-width: 1280px; width: 100%; margin: 0 auto; outline: none; }

/* ----- Campana y usuario ----- */
.flotante { position: relative; }
.campana { position: relative; }
.punto {
  position: absolute; top: 2px; right: 2px; min-width: 18px; height: 18px; padding: 0 5px;
  border-radius: 9px; background: var(--peligro); color: #fff; font-size: 11px; font-weight: 700; display: grid; place-items: center;
}
.usuario-btn { display: flex; align-items: center; gap: 10px; background: none; border: none; cursor: pointer; padding: 4px 6px; border-radius: 10px; color: var(--texto); }
.usuario-btn:hover { background: var(--superficie-2); }
.usuario-datos { display: grid; text-align: left; line-height: 1.2; }
.usuario-datos small { color: var(--texto-3); font-size: 12px; }

.desplegable {
  position: absolute; right: 0; top: calc(100% + 8px); width: 240px; z-index: 60;
  background: var(--superficie); border: 1px solid var(--borde); border-radius: var(--r-md); box-shadow: var(--sombra-2); overflow: hidden;
}
.desplegable.ancho { width: 340px; }
.desp-cab { padding: 12px 14px; font-weight: 700; border-bottom: 1px solid var(--borde); display: grid; }
.desp-vacio { padding: 18px 14px; color: var(--texto-3); font-size: 14px; }
.desp-item {
  display: flex; align-items: center; gap: 10px; width: 100%; text-align: left; padding: 10px 14px; background: none; border: none;
  border-bottom: 1px solid var(--borde); cursor: pointer; font-size: 14px; color: var(--texto);
}
.desp-item:hover { background: var(--superficie-2); }
.desp-item small { margin-left: auto; color: var(--texto-3); white-space: nowrap; }
.desp-item.peligro { color: var(--peligro); }
.desp-pie { width: 100%; padding: 10px; background: var(--superficie-2); border: none; cursor: pointer; font-weight: 700; color: var(--marca); }

/* ----- Móvil ----- */
.velo { position: fixed; inset: 0; background: rgba(34, 20, 12, 0.5); z-index: 70; }
@media (max-width: 960px) {
  .panel { grid-template-columns: 1fr; }
  .lateral { position: fixed; left: 0; top: 0; z-index: 80; width: 272px; transform: translateX(-100%); transition: transform 0.2s ease; }
  .lateral.abierto { transform: none; }
  .menu-movil { display: inline-flex; }
  .barra { padding: 0 12px; }
  .area { padding: 20px 14px 48px; }
  .desplegable.ancho { width: min(340px, calc(100vw - 24px)); position: fixed; right: 12px; }
}
</style>
