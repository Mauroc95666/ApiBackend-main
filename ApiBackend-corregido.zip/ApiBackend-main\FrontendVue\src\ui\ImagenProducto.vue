<script setup>
// Foto del producto. Si no hay URL o falla la carga, muestra un recuadro de color con la inicial.
import { ref, computed, watch } from 'vue';

const props = defineProps({ url: String, nombre: { type: String, default: '' } });
const fallo = ref(false);
watch(() => props.url, () => (fallo.value = false));

const mostrarFoto = computed(() => !!props.url && !fallo.value);
const inicial = computed(() => (props.nombre.trim().charAt(0) || '?').toUpperCase());
// Color estable por nombre, dentro de la gama cálida de la marca.
const tono = computed(() => {
  let h = 0;
  for (const c of props.nombre) h = (h * 31 + c.charCodeAt(0)) % 360;
  return 22 + (h % 26); // 22–48: de terracota a trigo
});
</script>

<template>
  <div class="imagen-producto" :style="mostrarFoto ? {} : { background: `linear-gradient(135deg, hsl(${tono} 70% 88%), hsl(${tono} 65% 78%))`, color: `hsl(${tono} 60% 28%)` }">
    <img v-if="mostrarFoto" :src="url" :alt="nombre" loading="lazy" @error="fallo = true" />
    <span v-else aria-hidden="true">{{ inicial }}</span>
  </div>
</template>

<style scoped>
.imagen-producto { width: 100%; height: 100%; display: grid; place-items: center; overflow: hidden; font-weight: 800; font-size: 2rem; }
.imagen-producto img { width: 100%; height: 100%; object-fit: cover; display: block; }
</style>
