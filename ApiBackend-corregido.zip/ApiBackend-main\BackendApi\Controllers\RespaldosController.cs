using BackendApi.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace BackendApi.Controllers;

// Req. 10: respaldo de la base de datos. La restauración se hace con scripts/restaurar.ps1
// (operación destructiva que requiere acceso al servidor, no se expone por la API).
[ApiController]
[Route("api/[controller]")]
[Authorize(Policy = "Admin")]
public class RespaldosController : ControllerBase
{
    private readonly RespaldoService _respaldo;
    private readonly AuditoriaService _auditoria;

    public RespaldosController(RespaldoService respaldo, AuditoriaService auditoria)
    {
        _respaldo = respaldo;
        _auditoria = auditoria;
    }

    [HttpGet]
    public async Task<IActionResult> Historial() => Ok(await _respaldo.HistorialAsync());

    [HttpPost]
    public async Task<IActionResult> Crear(CancellationToken ct)
    {
        var r = await _respaldo.RespaldarAsync(ct);
        await _auditoria.RegistrarAsync("RESPALDO", "Base de datos", $"{r.Archivo} (verificado: {r.Verificado})");
        return Ok(new
        {
            mensaje = r.Verificado ? "Respaldo creado y verificado." : "Respaldo creado pero la verificación falló: repetilo.",
            r.Archivo, r.Carpeta, r.Verificado, fecha = r.FechaUtc,
        });
    }
}
