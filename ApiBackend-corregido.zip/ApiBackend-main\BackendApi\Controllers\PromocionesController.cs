using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OutputCaching;
using Microsoft.EntityFrameworkCore;
using BackendApi.Models;

namespace BackendApi.Controllers;

// Req. 4: promociones. El público ve las vigentes; el administrador las gestiona todas.
[ApiController]
[Route("api/[controller]")]
[Authorize(Policy = "Admin")]
public class PromocionesController : ControllerBase
{
    private readonly ApplicationDbContext _context;
    private readonly IOutputCacheStore _cache;

    public PromocionesController(ApplicationDbContext context, IOutputCacheStore cache)
    {
        _context = context;
        _cache = cache;
    }

    [AllowAnonymous]
    [OutputCache(PolicyName = "catalogo")]
    [HttpGet("vigentes")]
    public async Task<IActionResult> Vigentes()
    {
        var hoy = DateTime.UtcNow;
        var promos = await _context.Promociones.AsNoTracking()
            .Where(p => p.FechaInicio <= hoy && p.FechaFin >= hoy).ToListAsync();
        return Ok(promos);
    }

    [Authorize(Policy = "Staff")]
    [HttpGet]
    public async Task<IActionResult> ObtenerPromociones()
    {
        var promociones = await _context.Promociones.AsNoTracking().OrderByDescending(p => p.FechaInicio).ToListAsync();
        return Ok(promociones);
    }

    [Authorize(Policy = "Staff")]
    [HttpGet("{id}")]
    public async Task<IActionResult> ObtenerPromocionPorId(int id)
    {
        var promocion = await _context.Promociones.AsNoTracking().FirstOrDefaultAsync(p => p.Id == id);

        if (promocion == null)
            return NotFound(new { mensaje = $"Promoción con id {id} no encontrada" });

        return Ok(promocion);
    }

    static string? Validar(Promocion p)
    {
        if (string.IsNullOrWhiteSpace(p.Nombre)) return "El nombre de la promoción es requerido";
        if (p.Descuento < 0 || p.Descuento > 100) return "El descuento debe estar entre 0 y 100";
        if (p.FechaFin < p.FechaInicio) return "La fecha de fin no puede ser anterior a la de inicio";
        return null;
    }

    [HttpPost]
    public async Task<IActionResult> CrearPromocion([FromBody] Promocion nuevaPromocion)
    {
        if (nuevaPromocion == null)
            return BadRequest(new { mensaje = "Los datos de la promoción son requeridos" });
        var error = Validar(nuevaPromocion);
        if (error != null) return BadRequest(new { mensaje = error });

        nuevaPromocion.Id = 0;
        nuevaPromocion.Emprendimiento = null!;
        _context.Promociones.Add(nuevaPromocion);
        await _context.SaveChangesAsync();
        await _cache.EvictByTagAsync("catalogo", default);

        return CreatedAtAction(nameof(ObtenerPromocionPorId), new { id = nuevaPromocion.Id }, nuevaPromocion);
    }

    [HttpPut("{id}")]
    public async Task<IActionResult> ActualizarPromocion(int id, [FromBody] Promocion promocionActualizada)
    {
        var promocion = await _context.Promociones.FindAsync(id);

        if (promocion == null)
            return NotFound(new { mensaje = $"Promoción con id {id} no encontrada" });
        var error = Validar(promocionActualizada);
        if (error != null) return BadRequest(new { mensaje = error });

        promocion.EmprendimientoId = promocionActualizada.EmprendimientoId;
        promocion.Nombre = promocionActualizada.Nombre;
        promocion.Descuento = promocionActualizada.Descuento;
        promocion.FechaInicio = promocionActualizada.FechaInicio;
        promocion.FechaFin = promocionActualizada.FechaFin;

        await _context.SaveChangesAsync();
        await _cache.EvictByTagAsync("catalogo", default);

        return Ok(new { mensaje = "Promoción actualizada correctamente", promocion });
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> EliminarPromocion(int id)
    {
        var promocion = await _context.Promociones.FindAsync(id);

        if (promocion == null)
            return NotFound(new { mensaje = $"Promoción con id {id} no encontrada" });

        _context.Promociones.Remove(promocion);
        await _context.SaveChangesAsync();
        await _cache.EvictByTagAsync("catalogo", default);

        return Ok(new { mensaje = $"Promoción {id} eliminada correctamente" });
    }
}
