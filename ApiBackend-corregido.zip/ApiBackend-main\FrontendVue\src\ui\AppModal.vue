<script setup>
// Modal accesible: se cierra con Esc o al tocar el fondo, enfoca el primer campo,
// bloquea el scroll de la página y devuelve el foco al elemento que lo abrió.
import { ref, watch, nextTick, onBeforeUnmount, useId } from 'vue';
import AppIcon from './AppIcon.vue';

const props = defineProps({
  modelValue: Boolean,
  titulo: String,
  tamano: { type: String, default: 'md' }, // sm | md | lg
  cerrarAlFondo: { type: Boolean, default: true },
});
const emit = defineEmits(['update:modelValue', 'cerrar']);

const idTitulo = useId();
const caja = ref(null);
let previo = null;

function cerrar() {
  emit('update:modelValue', false);
  emit('cerrar');
}

function alTeclear(e) {
  if (e.key === 'Escape') {
    e.stopPropagation();
    cerrar();
    return;
  }
  // Mantiene el foco dentro del modal con Tab.
  if (e.key === 'Tab' && caja.value) {
    const foco = caja.value.querySelectorAll(
      'a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])'
    );
    if (!foco.length) return;
    const primero = foco[0];
    const ultimo = foco[foco.length - 1];
    if (e.shiftKey && document.activeElement === primero) {
      e.preventDefault();
      ultimo.focus();
    } else if (!e.shiftKey && document.activeElement === ultimo) {
      e.preventDefault();
      primero.focus();
    }
  }
}

watch(
  () => props.modelValue,
  async (abierto) => {
    if (abierto) {
      previo = document.activeElement;
      document.body.style.overflow = 'hidden';
      await nextTick();
      const campo = caja.value?.querySelector('input:not([type=hidden]), select, textarea');
      (campo || caja.value?.querySelector('button'))?.focus();
    } else {
      document.body.style.overflow = '';
      previo?.focus?.();
    }
  }
);

onBeforeUnmount(() => {
  document.body.style.overflow = '';
});
</script>

<template>
  <Teleport to="body">
    <div v-if="modelValue" class="modal-fondo" @mousedown.self="cerrarAlFondo && cerrar()" @keydown="alTeclear">
      <div ref="caja" class="modal" :class="tamano" role="dialog" aria-modal="true" :aria-labelledby="idTitulo">
        <header class="modal-cabecera">
          <h3 :id="idTitulo">{{ titulo }}</h3>
          <button type="button" class="btn btn-fantasma btn-icono btn-sm" aria-label="Cerrar" @click="cerrar">
            <AppIcon name="x" :size="18" />
          </button>
        </header>
        <div class="modal-cuerpo"><slot /></div>
        <footer v-if="$slots.pie" class="modal-pie"><slot name="pie" /></footer>
      </div>
    </div>
  </Teleport>
</template>
