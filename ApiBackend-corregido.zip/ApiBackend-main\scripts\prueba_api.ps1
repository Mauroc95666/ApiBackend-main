<#
.SYNOPSIS
  Prueba de punta a punta de los requisitos funcionales contra una API recién instalada.

.DESCRIPTION
  ATENCIÓN: crea usuarios, productos, ventas y un respaldo. Usalo SOLO contra una base de pruebas vacía:
    1) Creá una base nueva (db/init.sql + db/02_requisitos.sql cambiando el nombre a DB_Panaderia2_test).
    2) Iniciá la API apuntando a esa base, en el puerto 5209, con
         Setup__Usuario=instalador@kiataque.local  y  Setup__Clave=Instal-Temporal-2026!
         Backup__Automatico=false
    3) Ejecutá este script. Si la base ya tiene un administrador, el primer bloque falla (es lo esperado).
#>
param([string]$Base = "http://localhost:5209")
$ErrorActionPreference = 'Continue'
$script:ok = 0; $script:fail = 0

function Call($m, $u, $b, $t) {
    $h = @{}; if ($t) { $h.Authorization = "Bearer $t" }
    try {
        $p = @{ Method = $m; Uri = "$Base$u"; Headers = $h; UseBasicParsing = $true; ContentType = 'application/json' }
        if ($null -ne $b) { $p.Body = ($b | ConvertTo-Json -Depth 6) }
        $r = Invoke-WebRequest @p
        return @{ code = [int]$r.StatusCode; body = $(if ($r.Content) { $r.Content | ConvertFrom-Json } else { $null }); raw = $r.Content }
    } catch {
        $c = $_.Exception.Response; $s = ''
        if ($c) { $s = (New-Object IO.StreamReader($c.GetResponseStream())).ReadToEnd() }
        $j = $null; try { $j = $s | ConvertFrom-Json } catch {}
        return @{ code = [int]$c.StatusCode; body = $j; raw = $s }
    }
}
function Check($nombre, $cond, $detalle) {
    if ($cond) { $script:ok++; Write-Host "  OK   $nombre" -ForegroundColor Green }
    else { $script:fail++; Write-Host "  FALLA $nombre  -> $detalle" -ForegroundColor Red }
}

Write-Host "== Req 6: super-usuario oculto / primer admin"
$r = Call POST /api/ventas @{ sucursalId = 1; clienteId = 1; metodoPagoId = 1; detalles = @(@{ productoId = 1; cantidad = 1 }) }
Check "venta sin usuarios activos se rechaza" ($r.code -eq 400) "$($r.code) $($r.raw)"
$r = Call POST /api/auth/login @{ email = 'instalador@kiataque.local'; password = 'mala' }
Check "super-usuario con clave mala -> 401" ($r.code -eq 401) $r.code
$r = Call POST /api/auth/login @{ email = 'instalador@kiataque.local'; password = 'Instal-Temporal-2026!' }
Check "super-usuario entra" ($r.code -eq 200 -and $r.body.rolNombre -eq 'SetupRoot') $r.raw
$root = $r.body.token
$r = Call GET /api/usuarios $null $root
Check "super-usuario NO puede listar usuarios" ($r.code -eq 403) $r.code
$r = Call GET /api/productos $null $root
Check "super-usuario NO ve nada mas (productos con token root sigue publico)" ($r.code -eq 200) $r.code
$r = Call POST /api/ventas @{ sucursalId = 1; clienteId = 1; metodoPagoId = 1; detalles = @(@{ productoId = 1; cantidad = 1 }) } $root
$r = Call POST /api/setup/primer-admin @{ nombre = 'Admin'; email = 'admin@kiataque.bo'; password = 'debil' } $root
Check "clave debil rechazada" ($r.code -eq 400) "$($r.code) $($r.raw)"
$r = Call POST /api/setup/primer-admin @{ nombre = 'Admin Prueba'; email = 'admin@kiataque.bo'; password = 'Admin-Prueba-2026' } $root
Check "primer admin creado" ($r.code -eq 201) "$($r.code) $($r.raw)"
$r = Call POST /api/setup/primer-admin @{ nombre = 'Otro'; email = 'otro@kiataque.bo'; password = 'Admin-Prueba-2026' } $root
Check "segundo intento rechazado" ($r.code -eq 409) "$($r.code) $($r.raw)"
$r = Call POST /api/auth/login @{ email = 'instalador@kiataque.local'; password = 'Instal-Temporal-2026!' }
Check "super-usuario ya no puede entrar" ($r.code -eq 401) $r.code

Write-Host "== Req 3/8: roles y autorizacion"
$r = Call POST /api/auth/login @{ email = 'admin@kiataque.bo'; password = 'Admin-Prueba-2026' }
Check "login admin" ($r.code -eq 200) $r.raw
$adm = $r.body.token
$roles = (Call GET /api/roles $null $adm).body
$rolCajero = ($roles | Where-Object nombre -eq 'Cajero').id
$rolInv = ($roles | Where-Object nombre -eq 'Inventario').id
$r = Call POST /api/usuarios @{ nombre = 'Caja'; email = 'caja@kiataque.bo'; passwordHash = 'Caja-Prueba-2026'; rolId = $rolCajero; activo = $true; emprendimientoId = 1 } $adm
Check "admin crea cajero" ($r.code -eq 201) "$($r.code) $($r.raw)"
$idCaja = $r.body.id
$r = Call POST /api/usuarios @{ nombre = 'Caja2'; email = 'CAJA@kiataque.bo'; passwordHash = 'Caja-Prueba-2026'; rolId = $rolCajero; activo = $true; emprendimientoId = 1 } $adm
Check "email duplicado -> 409 (UNIQUE)" ($r.code -eq 409) "$($r.code) $($r.raw)"
$r = Call POST /api/usuarios @{ nombre = 'X'; email = 'x@kiataque.bo'; passwordHash = '123'; rolId = $rolCajero; activo = $true; emprendimientoId = 1 } $adm
Check "clave debil en usuario -> 400" ($r.code -eq 400) $r.code
$r = Call POST /api/usuarios @{ nombre = 'Inv'; email = 'inv@kiataque.bo'; passwordHash = 'Inv-Prueba-2026'; rolId = $rolInv; activo = $true; emprendimientoId = 1 } $adm
$idInv = $r.body.id
$r = Call POST /api/auth/login @{ email = 'caja@kiataque.bo'; password = 'Caja-Prueba-2026' }
$caja = $r.body.token
$r = Call POST /api/auth/login @{ email = 'inv@kiataque.bo'; password = 'Inv-Prueba-2026' }
$inv = $r.body.token
$r = Call GET /api/usuarios $null $caja
Check "cajero no ve usuarios" ($r.code -eq 403) $r.code
$r = Call POST /api/productos @{ nombre = 'X'; precio = 1; stock = 1; emprendimientoId = 1 } $caja
Check "cajero no crea productos" ($r.code -eq 403) $r.code
$r = Call GET /api/reportes/ventas $null $caja
Check "cajero no ve reportes" ($r.code -eq 403) $r.code
$r = Call GET /api/pedidos $null $inv
Check "inventario no ve pedidos" ($r.code -eq 403) $r.code
$r = Call GET /api/usuarios $null $null
Check "sin token -> 401" ($r.code -eq 401) $r.code
$r = Call DELETE "/api/usuarios/$($r.body.id)" $null $adm
$me = (Call GET /api/usuarios $null $adm).body | Where-Object email -eq 'admin@kiataque.bo'
$r = Call DELETE "/api/usuarios/$($me.id)" $null $adm
Check "no se puede borrar al unico admin" ($r.code -eq 409) "$($r.code) $($r.raw)"

Write-Host "== Req 9: multi-sucursal"
$r = Call POST /api/sucursales @{ nombre = 'Sucursal Norte'; direccion = 'Av. Norte 1'; telefono = '700'; ciudadId = 1; emprendimientoId = 1 } $adm
Check "admin crea 2da sucursal" ($r.code -eq 201) "$($r.code) $($r.raw)"
$suc2 = $r.body.id
$r = Call POST /api/empleados @{ usuarioId = $idCaja; sucursalId = $suc2; cargo = 'Cajero'; salario = 1000 } $adm
Check "cajero asignado a sucursal 2" ($r.code -eq 201) "$($r.code) $($r.raw)"
$r = Call POST /api/auth/login @{ email = 'caja@kiataque.bo'; password = 'Caja-Prueba-2026' }
Check "login devuelve sucursalId" ($r.body.sucursalId -eq $suc2) $r.raw
$caja = $r.body.token

Write-Host "== Req 1: inventario (entradas/salidas)"
$r = Call POST /api/categorias @{ nombre = 'Prueba'; emprendimientoId = 1 } $adm
$cat = $r.body.id
$r = Call POST /api/productos @{ nombre = 'Pan prueba'; precio = 2.5; stock = 0; emprendimientoId = 1; categoriaId = $cat } $adm
Check "admin crea producto" ($r.code -eq 201) "$($r.code) $($r.raw)"
$prod = $r.body.id
$r = Call POST /api/productos @{ nombre = 'Malo'; precio = -5; stock = 0; emprendimientoId = 1 } $adm
Check "precio negativo -> 400" ($r.code -eq 400) $r.code
$r = Call POST /api/inventarios @{ productoId = $prod; sucursalId = 1; stockActual = 10; stockMinimo = 8 } $inv
Check "inventario crea fila (stock inicial 10)" ($r.code -eq 201) "$($r.code) $($r.raw)"
$invId = $r.body.id
$r = Call POST /api/inventarios @{ productoId = $prod; sucursalId = 1; stockActual = 1 } $inv
Check "producto+sucursal duplicado -> 409" ($r.code -eq 409) $r.code
$r = Call POST "/api/inventarios/$invId/movimiento" @{ tipo = 'ENTRADA'; cantidad = 5; motivo = 'Compra' } $inv
Check "ENTRADA +5 => 15" ($r.code -eq 201 -and $r.body.stockActual -eq 15) "$($r.code) $($r.raw)"
$r = Call POST "/api/inventarios/$invId/movimiento" @{ tipo = 'SALIDA'; cantidad = 100; motivo = 'Merma' } $inv
Check "SALIDA mayor al stock -> 409" ($r.code -eq 409) "$($r.code) $($r.raw)"
$r = Call POST "/api/inventarios/$invId/movimiento" @{ tipo = 'SALIDA'; cantidad = 3; motivo = 'Merma' } $inv
Check "SALIDA -3 => 12" ($r.code -eq 201 -and $r.body.stockActual -eq 12) "$($r.code) $($r.raw)"
$r = Call POST "/api/inventarios/$invId/movimiento" @{ tipo = 'AJUSTE'; cantidad = 3 } $inv
Check "tipo invalido -> 400" ($r.code -eq 400) $r.code
$r = Call DELETE "/api/movimientosinventario/1" $null $adm
Check "movimientos no se borran (405)" ($r.code -eq 405) $r.code
$r = Call GET "/api/movimientosinventario?inventarioId=$invId" $null $inv
Check "historial: 3 movimientos" (@($r.body).Count -eq 3) $r.raw

Write-Host "== Req 2/9(Ley 164): venta publica con sucursal y modalidad"
$r = Call POST /api/clientes @{ emprendimientoId = 1; nombre = 'Ana'; telefono = '777'; direccion = 'Calle 1' }
Check "cliente sin consentimiento -> 400" ($r.code -eq 400) "$($r.code) $($r.raw)"
$r = Call POST /api/clientes @{ emprendimientoId = 1; nombre = 'Ana'; telefono = '777'; email = 'ana@x.com'; direccion = 'Calle 1'; consentimientoFecha = (Get-Date).ToString('o') }
Check "cliente con consentimiento -> 201 y fecha del servidor" ($r.code -eq 201 -and $r.body.consentimientoFecha) "$($r.code) $($r.raw)"
$cli = $r.body.id
$r = Call POST /api/ventas @{ sucursalId = 1; clienteId = $cli; metodoPagoId = 1; modalidad = 'DELIVERY'; detalles = @(@{ productoId = $prod; cantidad = 5 }) }
Check "delivery sin direccion propia usa la del cliente" ($r.code -eq 201 -and $r.body.modalidad -eq 'DELIVERY') "$($r.code) $($r.raw)"
$venta1 = $r.body.id; $ped1 = $r.body.pedidoId
$r = Call POST /api/clientes @{ emprendimientoId = 1; nombre = 'Sin dir'; consentimientoFecha = (Get-Date).ToString('o') }
$cli2 = $r.body.id
$r = Call POST /api/ventas @{ sucursalId = 1; clienteId = $cli2; metodoPagoId = 1; modalidad = 'DELIVERY'; detalles = @(@{ productoId = $prod; cantidad = 1 }) }
Check "delivery sin direccion -> 400" ($r.code -eq 400) "$($r.code) $($r.raw)"
$r = Call POST /api/ventas @{ sucursalId = 1; clienteId = $cli2; metodoPagoId = 1; modalidad = 'MOTO'; detalles = @(@{ productoId = $prod; cantidad = 1 }) }
Check "modalidad invalida -> 400" ($r.code -eq 400) $r.code
$r = Call POST /api/ventas @{ sucursalId = 1; clienteId = $cli2; metodoPagoId = 1; detalles = @(@{ productoId = $prod; cantidad = 500 }) }
Check "stock insuficiente en venta -> 409" ($r.code -eq 409) "$($r.code) $($r.raw)"
$r = Call POST /api/ventas @{ sucursalId = 1; clienteId = $cli2; metodoPagoId = 1; detalles = @(@{ productoId = $prod; cantidad = 1 }) }
Check "retiro por defecto" ($r.code -eq 201 -and $r.body.modalidad -eq 'RETIRO') "$($r.code) $($r.raw)"
$ped2 = $r.body.pedidoId
$st = (Call GET "/api/inventarios/$invId" $null $inv).body.stockActual
Check "stock descontado 12-5-1 = 6" ($st -eq 6) "stock=$st"
$notis = (Call GET "/api/notificaciones" $null $inv).body
Check "alerta de stock bajo generada" (@($notis | Where-Object { $_.mensaje -like '*Stock bajo*' }).Count -ge 1) ($notis | ConvertTo-Json -Compress)
$r = Call POST /api/ventas @{ sucursalId = 1; clienteId = $cli2; metodoPagoId = 1; detalles = @(@{ productoId = $prod; cantidad = 1 }) } $caja
Check "cajero de otra sucursal no vende en la 1 -> 403" ($r.code -eq 403) $r.code
$r = Call GET /api/ventas $null $caja
Check "cajero (sucursal 2) ve 0 ventas" (@($r.body).Count -eq 0) $r.raw
$r = Call GET /api/ventas $null $adm
Check "admin ve las 2 ventas" (@($r.body).Count -eq 2) $r.raw

Write-Host "== Req 11: tiempo de servicio"
$r = Call PATCH "/api/pedidos/$ped1/estado" @{ estado = 'LISTO' } $adm
Check "no se salta de PENDIENTE a LISTO -> 409" ($r.code -eq 409) "$($r.code) $($r.raw)"
foreach ($e in 'EN PREPARACION', 'LISTO', 'ENTREGADO') {
    Start-Sleep -Milliseconds 400
    $r = Call PATCH "/api/pedidos/$ped1/estado" @{ estado = $e } $adm
    Check "pedido -> $e" ($r.code -eq 200) "$($r.code) $($r.raw)"
}
$p = (Call GET "/api/pedidos/$ped1" $null $adm).body
Check "pedido guarda 4 marcas y tiempo de servicio" ($p.fechaPreparacion -and $p.fechaListo -and $p.fechaEntregado -and $null -ne $p.tiempoServicioMinutos) ($p | ConvertTo-Json -Compress)
Check "pedido delivery guarda direccion" ($p.modalidad -eq 'DELIVERY' -and $p.direccionEntrega -eq 'Calle 1') ($p | ConvertTo-Json -Compress)
$r = Call PATCH "/api/pedidos/$ped1/estado" @{ estado = 'PENDIENTE' } $adm
Check "pedido entregado no retrocede" ($r.code -eq 409) $r.code
$r = Call GET "/api/reportes/tiempos-servicio" $null $adm
Check "reporte tiempos-servicio" ($r.code -eq 200 -and $r.body.general.pedidos -eq 1) "$($r.code) $($r.raw)"

Write-Host "== Req 4: reportes / promociones / resenas / notificaciones"
$r = Call GET /api/reportes/ventas $null $adm
Check "reporte ventas" ($r.code -eq 200 -and $r.body.resumen.ventas -eq 2) "$($r.code) $($r.raw)"
$r = Call GET /api/reportes/productos-top $null $adm
Check "productos top" ($r.code -eq 200 -and @($r.body).Count -ge 1) "$($r.code) $($r.raw)"
$r = Call POST /api/promociones @{ emprendimientoId = 1; nombre = 'Promo'; descuento = 150; fechaInicio = '2026-01-01'; fechaFin = '2026-12-31' } $adm
Check "promo con descuento 150 -> 400" ($r.code -eq 400) $r.code
$r = Call POST /api/promociones @{ emprendimientoId = 1; nombre = 'Promo'; descuento = 10; fechaInicio = '2026-01-01'; fechaFin = '2027-12-31' } $adm
Check "promo valida" ($r.code -eq 201) "$($r.code) $($r.raw)"
$r = Call GET /api/promociones/vigentes
Check "promos vigentes son publicas" ($r.code -eq 200 -and @($r.body).Count -eq 1) "$($r.code) $($r.raw)"
$r = Call POST /api/resenas @{ productoId = $prod; clienteId = $cli; calificacion = 9; comentario = 'x' }
Check "resena calificacion 9 -> 400" ($r.code -eq 400) $r.code
$r = Call POST /api/resenas @{ productoId = $prod; clienteId = $cli2 + 99; calificacion = 5 }
Check "resena de quien no compro -> 400" ($r.code -eq 400) $r.code
$r = Call POST /api/resenas @{ productoId = $prod; clienteId = $cli; calificacion = 5; comentario = 'Rico' }
Check "resena verificada -> 201" ($r.code -eq 201) "$($r.code) $($r.raw)"
$r = Call POST /api/resenas @{ productoId = $prod; clienteId = $cli; calificacion = 4 }
Check "resena repetida -> 409" ($r.code -eq 409) $r.code
$r = Call GET "/api/notificaciones/no-leidas" $null $inv
Check "contador de no leidas" ($r.code -eq 200 -and $r.body.cantidad -ge 1) $r.raw
$r = Call POST "/api/notificaciones/leer-todas" $null $inv
$r = Call GET "/api/notificaciones/no-leidas" $null $inv
Check "leer-todas deja 0" ($r.body.cantidad -eq 0) $r.raw

Write-Host "== Ley 164: derechos del titular"
$r = Call GET "/api/clientes/$cli/datos" $null $adm
Check "acceso a datos personales (admin)" ($r.code -eq 200 -and $r.body.cliente.email -eq 'ana@x.com') "$($r.code) $($r.raw)"
$r = Call GET "/api/clientes/$cli/datos" $null $caja
Check "cajero no accede a esos datos" ($r.code -eq 403) $r.code
$r = Call POST "/api/clientes/$cli/anonimizar" $null $adm
Check "anonimizar cliente" ($r.code -eq 200) "$($r.code) $($r.raw)"
$c = (Call GET "/api/clientes/$cli" $null $adm).body
Check "datos personales borrados, venta intacta" ($c.anonimizado -and -not $c.email -and -not $c.direccion -and $c.nombre -eq 'Cliente anonimizado') ($c | ConvertTo-Json -Compress)
$aud = (Call GET /api/auditorias $null $adm).body
Check "auditoria registra acciones sensibles" (@($aud).Count -ge 5) "filas=$(@($aud).Count)"

Write-Host "== Req 10: respaldo"
$r = Call POST /api/respaldos $null $adm
Check "respaldo creado y verificado" ($r.code -eq 200 -and $r.body.verificado -eq $true) "$($r.code) $($r.raw)"
$r = Call GET /api/respaldos $null $adm
Check "historial de respaldos" ($r.code -eq 200 -and @($r.body).Count -ge 1) "$($r.code) $($r.raw)"
$r = Call POST /api/respaldos $null $caja
Check "cajero no puede respaldar" ($r.code -eq 403) $r.code

Write-Host "== Req 7: rendimiento"
1..30 | ForEach-Object { Call GET /api/productos | Out-Null }
$r = Call GET /api/metricas $null $adm
Check "metricas disponibles" ($r.code -eq 200) $r.code
$cat = $r.body.rutas | Where-Object ruta -eq 'GET /api/productos'
Write-Host ("  catalogo p95={0} ms, venta p95={1} ms, global p95={2} ms" -f $cat.p95Ms, $r.body.metas.ventaMenorA3s.p95Ms, $r.body.metas.apiP95MenorA500ms.p95Ms)
Check "catalogo < 2 s" ($r.body.metas.catalogoMenorA2s.cumple) ""
Check "venta < 3 s" ($r.body.metas.ventaMenorA3s.cumple) ""
Check "API p95 < 500 ms" ($r.body.metas.apiP95MenorA500ms.cumple) "p95=$($r.body.metas.apiP95MenorA500ms.p95Ms)"

Write-Host "== Req 8: seguridad"
$h = (Invoke-WebRequest "$Base/api/productos" -UseBasicParsing).Headers
Check "cabeceras de seguridad" ($h['X-Content-Type-Options'] -eq 'nosniff' -and $h['X-Frame-Options'] -eq 'DENY') ""
Check "cabecera X-Response-Time-ms" ($null -ne $h['X-Response-Time-ms']) ""
try { $o = Invoke-WebRequest "$Base/api/productos" -Headers @{ Origin = 'http://malo.example' } -UseBasicParsing; $cors = $o.Headers['Access-Control-Allow-Origin'] } catch { $cors = $null }
Check "CORS no autoriza origenes ajenos" (-not $cors) "cors=$cors"
$last = 0
1..12 | ForEach-Object { $x = Call POST /api/auth/login @{ email = 'nadie@x.com'; password = 'x' }; $last = $x.code }
Check "limite de intentos de login -> 429" ($last -eq 429) "ultimo=$last"

Write-Host "== Venta de mostrador (POS)"
$antes = @((Call GET /api/pedidos $null $adm).body).Count
$r = Call POST /api/ventas @{ sucursalId = 1; clienteId = $cli2; metodoPagoId = 1; mostrador = $true; detalles = @(@{ productoId = $prod; cantidad = 1 }) } $adm
Check "venta de mostrador se registra" ($r.code -eq 201) "$($r.code) $($r.raw)"
Check "venta de mostrador NO genera pedido" ($null -eq $r.body.pedidoId) $r.raw
$despues = @((Call GET /api/pedidos $null $adm).body).Count
Check "la cola de pedidos no cambia" ($antes -eq $despues) "antes=$antes despues=$despues"
$r = Call GET /api/ventas $null $adm
Check "la venta de mostrador cuenta en ventas" (@($r.body).Count -eq 3) $r.raw

Write-Host ""
Write-Host ("Resultado: {0} OK, {1} con fallas" -f $script:ok, $script:fail) -ForegroundColor $(if ($script:fail) { 'Red' } else { 'Green' })

