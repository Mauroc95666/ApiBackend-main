<script setup>
import { ref, computed, onMounted } from 'vue';
import api from '@/api/axios';
import { store, puedeVer } from '@/store';
import { toast, confirmar } from '@/ui/feedback';
import { bs, entero, fechaHora, mensajeError, descargarCsv } from '@/utils/format';
import AppIcon from '@/ui/AppIcon.vue';
import AppModal from '@/ui/AppModal.vue';
import Campo from '@/ui/Campo.vue';
import EncabezadoPagina from '@/ui/EncabezadoPagina.vue';
import EstadoVacio from '@/ui/EstadoVacio.vue';
import ImagenProducto from '@/ui/ImagenProducto.vue';
import Insignia from '@/ui/Insignia.vue';
import TarjetaKpi from '@/ui/TarjetaKpi.vue';

const inventarios = ref([]);
const productos = ref([]);
const sucursales = ref([]);
const usuarios = ref([]);
const cargando = ref(true);
const errorCarga = ref('');

const puedeEditar = puedeVer('inventario');
const sucursalFija = store.sucursalId != null;

const busqueda = ref('');
const filtroEstado = ref('TODOS');
const filtroSucursal = ref(store.sucursalId ?? 0);

async function cargar() {
  cargando.value = true;
  errorCarga.value = '';
  try {
    const pedir = (url) => api.get(url).then((r) => r.data || []);
    const [i, p, s, u] = await Promise.all([pedir('/inventarios'), pedir('/productos'), pedir('/sucursales').catch(() => []), store.esAdmin ? pedir('/usuarios').catch(() => []) : []]);
    inventarios.value = i;
    productos.value = p;
    sucursales.value = s;
    usuarios.value = u;
  } catch (e) {
    errorCarga.value = mensajeError(e, 'No se pudo cargar el inventario.');
  } finally {
    cargando.value = false;
  }
}

const producto = (id) => productos.value.find((p) => p.id === id);
const nombreProducto = (id) => producto(id)?.nombre || `Producto #${id}`;
const nombreSucursal = (id) => sucursales.value.find((s) => s.id === id)?.nombre || '—';

// Estado de un ítem: sin stock, crítico (bajo el mínimo), al límite u OK.
function estado(i) {
  if (i.stockActual <= 0) return { clave: 'CRITICO', tono: 'peligro', texto: 'Sin stock' };
  if (i.stockMinimo != null && i.stockActual < i.stockMinimo) return { clave: 'CRITICO', tono: 'peligro', texto: 'Crítico' };
  if (i.stockMinimo != null && i.stockActual === i.stockMinimo) return { clave: 'CRITICO', tono: 'aviso', texto: 'Al límite' };
  return { clave: 'OK', tono: 'ok', texto: 'OK' };
}
function porcentaje(i) {
  const ref = (i.stockMinimo || 10) * 2;
  return Math.max(3, Math.min(100, Math.round((i.stockActual / ref) * 100)));
}

const base = computed(() => inventarios.value.filter((i) => !filtroSucursal.value || i.sucursalId === filtroSucursal.value));
const filtrados = computed(() => {
  const t = busqueda.value.trim().toLowerCase();
  return base.value
    .filter((i) => (filtroEstado.value === 'TODOS' || estado(i).clave === filtroEstado.value) && (!t || nombreProducto(i.productoId).toLowerCase().includes(t)))
    .sort((a, b) => nombreProducto(a.productoId).localeCompare(nombreProducto(b.productoId), 'es'));
});
const criticos = computed(() => base.value.filter((i) => estado(i).clave === 'CRITICO').length);
const sinStock = computed(() => base.value.filter((i) => i.stockActual <= 0).length);
const valorStock = computed(() => base.value.reduce((s, i) => s + i.stockActual * Number(producto(i.productoId)?.precio || 0), 0));

// ----- Movimiento (entrada / salida) -----
const modalMov = ref(false);
const mov = ref({ inventarioId: null, tipo: 'ENTRADA', cantidad: 1, motivo: '' });
const errorMov = ref('');
const guardandoMov = ref(false);
const MOTIVOS = { ENTRADA: ['Compra a proveedor', 'Producción', 'Ajuste de inventario'], SALIDA: ['Merma', 'Consumo interno', 'Ajuste de inventario'] };

const itemMov = computed(() => inventarios.value.find((i) => i.id === mov.value.inventarioId));
const stockResultante = computed(() => {
  if (!itemMov.value) return null;
  const c = Number(mov.value.cantidad) || 0;
  return mov.value.tipo === 'ENTRADA' ? itemMov.value.stockActual + c : itemMov.value.stockActual - c;
});

function abrirMovimiento(tipo, item = null) {
  mov.value = { inventarioId: item?.id ?? filtrados.value[0]?.id ?? inventarios.value[0]?.id ?? null, tipo, cantidad: 1, motivo: '' };
  errorMov.value = '';
  modalMov.value = true;
}

async function registrarMovimiento() {
  errorMov.value = '';
  const c = Number(mov.value.cantidad);
  if (!itemMov.value) return (errorMov.value = 'Elegí un ítem del inventario.');
  if (!Number.isInteger(c) || c <= 0) return (errorMov.value = 'La cantidad tiene que ser un número entero mayor a 0.');
  if (stockResultante.value < 0) return (errorMov.value = `No hay suficiente stock: disponible ${itemMov.value.stockActual}.`);
  guardandoMov.value = true;
  try {
    const { data } = await api.post(`/inventarios/${itemMov.value.id}/movimiento`, { tipo: mov.value.tipo, cantidad: c, motivo: mov.value.motivo.trim() || null });
    toast.ok(`${mov.value.tipo === 'ENTRADA' ? 'Entrada' : 'Salida'} registrada. Stock actual: ${data.stockActual}.`);
    modalMov.value = false;
    await cargar();
  } catch (e) {
    errorMov.value = mensajeError(e, 'No se pudo registrar el movimiento.');
  } finally {
    guardandoMov.value = false;
  }
}

// ----- Alta / edición del ítem -----
const modalItem = ref(false);
const editando = ref(null);
const formItem = ref({ productoId: null, sucursalId: null, stockActual: 0, stockMinimo: 5 });
const erroresItem = ref({});
const guardandoItem = ref(false);

function abrirNuevoItem() {
  editando.value = null;
  formItem.value = { productoId: null, sucursalId: filtroSucursal.value || sucursales.value[0]?.id || null, stockActual: 0, stockMinimo: 5 };
  erroresItem.value = {};
  modalItem.value = true;
}
function abrirEditarItem(i) {
  editando.value = i;
  formItem.value = { ...i };
  erroresItem.value = {};
  modalItem.value = true;
}
async function guardarItem() {
  const f = formItem.value;
  const e = {};
  if (!f.productoId) e.productoId = 'Elegí el producto.';
  if (!f.sucursalId) e.sucursalId = 'Elegí la sucursal.';
  if (!(Number(f.stockMinimo) >= 0)) e.stockMinimo = 'Tiene que ser 0 o más.';
  if (!editando.value && !(Number(f.stockActual) >= 0)) e.stockActual = 'Tiene que ser 0 o más.';
  erroresItem.value = e;
  if (Object.keys(e).length) return;
  guardandoItem.value = true;
  try {
    const cuerpo = { ...f, stockActual: Number(f.stockActual) || 0, stockMinimo: Number(f.stockMinimo) };
    if (editando.value) await api.put(`/inventarios/${editando.value.id}`, cuerpo);
    else await api.post('/inventarios', cuerpo);
    toast.ok(editando.value ? 'Stock mínimo actualizado.' : 'Producto agregado al inventario.');
    modalItem.value = false;
    await cargar();
  } catch (err) {
    toast.error(mensajeError(err, 'No se pudo guardar.'));
  } finally {
    guardandoItem.value = false;
  }
}
async function eliminar(i) {
  const si = await confirmar({ titulo: 'Quitar del inventario', mensaje: `¿Quitar "${nombreProducto(i.productoId)}" del inventario de ${nombreSucursal(i.sucursalId)}? Se pierde su historial de movimientos.`, textoOk: 'Quitar', peligro: true });
  if (!si) return;
  try {
    await api.delete(`/inventarios/${i.id}`);
    toast.ok('Ítem quitado del inventario.');
    await cargar();
  } catch (e) {
    toast.error(mensajeError(e, 'No se pudo quitar el ítem.'));
  }
}

// ----- Historial de movimientos de un ítem -----
const modalHist = ref(false);
const histItem = ref(null);
const movimientos = ref([]);
const cargandoHist = ref(false);
const nombreUsuario = (id) => usuarios.value.find((u) => u.id === id)?.nombre || `Usuario #${id}`;

async function verHistorial(i) {
  histItem.value = i;
  movimientos.value = [];
  modalHist.value = true;
  cargandoHist.value = true;
  try {
    movimientos.value = (await api.get('/movimientosinventario', { params: { inventarioId: i.id } })).data || [];
  } catch (e) {
    toast.error(mensajeError(e, 'No se pudo cargar el historial.'));
  } finally {
    cargandoHist.value = false;
  }
}

function exportar() {
  descargarCsv('inventario.csv', [
    ['Producto', 'Sucursal', 'Stock actual', 'Stock mínimo', 'Estado'],
    ...filtrados.value.map((i) => [nombreProducto(i.productoId), nombreSucursal(i.sucursalId), i.stockActual, i.stockMinimo ?? '', estado(i).texto]),
  ]);
}

onMounted(cargar);
</script>

<template>
  <div>
    <EncabezadoPagina titulo="Inventario" subtitulo="Existencias por sucursal, entradas y salidas">
      <button type="button" class="btn btn-secundario" :disabled="!filtrados.length" @click="exportar"><AppIcon name="download" :size="16" /> Exportar</button>
      <template v-if="puedeEditar">
        <button type="button" class="btn btn-secundario" @click="abrirNuevoItem"><AppIcon name="plus" :size="16" /> Agregar producto</button>
        <button type="button" class="btn btn-secundario" :disabled="!inventarios.length" @click="abrirMovimiento('SALIDA')"><AppIcon name="arrowDown" :size="16" /> Salida</button>
        <button type="button" class="btn btn-primario" :disabled="!inventarios.length" @click="abrirMovimiento('ENTRADA')"><AppIcon name="arrowUp" :size="16" /> Entrada</button>
      </template>
    </EncabezadoPagina>

    <div v-if="errorCarga" class="aviso-linea error" role="alert" style="margin-bottom: 16px">
      <AppIcon name="alert" :size="18" /> <span class="crece">{{ errorCarga }}</span>
      <button type="button" class="btn btn-secundario btn-sm" @click="cargar">Reintentar</button>
    </div>

    <div class="rejilla-kpi" style="margin-bottom: 20px">
      <TarjetaKpi titulo="Ítems en inventario" icono="boxes" :valor="entero(base.length)" :cargando="cargando" />
      <TarjetaKpi titulo="Por reponer" icono="alert" :tono="criticos ? 'aviso' : 'ok'" :valor="entero(criticos)" detalle="En o bajo el mínimo" :cargando="cargando" />
      <TarjetaKpi titulo="Sin stock" icono="x" :tono="sinStock ? 'peligro' : 'ok'" :valor="entero(sinStock)" :cargando="cargando" />
      <TarjetaKpi titulo="Valor del stock" icono="receipt" tono="info" :valor="bs(valorStock)" detalle="A precio de venta" :cargando="cargando" />
    </div>

    <div class="tarjeta">
      <div class="herramientas">
        <div class="entrada-icono buscador">
          <AppIcon name="search" :size="17" class="icono-izq" />
          <input v-model="busqueda" type="search" placeholder="Buscar producto..." aria-label="Buscar producto" />
        </div>
        <select v-if="sucursales.length > 1 && !sucursalFija" v-model.number="filtroSucursal" aria-label="Filtrar por sucursal" style="width: auto">
          <option :value="0">Todas las sucursales</option>
          <option v-for="s in sucursales" :key="s.id" :value="s.id">{{ s.nombre }}</option>
        </select>
        <div class="segmentos" role="group" aria-label="Filtrar por estado">
          <button type="button" class="segmento" :class="{ activo: filtroEstado === 'TODOS' }" @click="filtroEstado = 'TODOS'">Todos</button>
          <button type="button" class="segmento" :class="{ activo: filtroEstado === 'CRITICO' }" @click="filtroEstado = 'CRITICO'">Por reponer</button>
          <button type="button" class="segmento" :class="{ activo: filtroEstado === 'OK' }" @click="filtroEstado = 'OK'">OK</button>
        </div>
      </div>

      <div v-if="cargando" class="tabla-contenedor"><table class="tabla"><tbody><tr v-for="n in 5" :key="n"><td v-for="c in 5" :key="c"><span class="esqueleto"></span></td></tr></tbody></table></div>

      <EstadoVacio v-else-if="!inventarios.length" icono="boxes" titulo="El inventario está vacío" texto="Agregá los productos que tenés en cada sucursal para controlar su stock.">
        <button v-if="puedeEditar" type="button" class="btn btn-primario" @click="abrirNuevoItem"><AppIcon name="plus" :size="16" /> Agregar producto</button>
      </EstadoVacio>
      <EstadoVacio v-else-if="!filtrados.length" icono="search" titulo="Sin resultados" texto="Ningún ítem coincide con los filtros." />

      <div v-else class="tabla-contenedor">
        <table class="tabla">
          <thead>
            <tr><th>Producto</th><th v-if="sucursales.length > 1" class="oculto-movil">Sucursal</th><th>Stock</th><th class="num oculto-movil">Mínimo</th><th>Estado</th><th v-if="puedeEditar" class="acciones">Acciones</th></tr>
          </thead>
          <tbody>
            <tr v-for="i in filtrados" :key="i.id">
              <td>
                <div class="fila"><div class="mini"><ImagenProducto :url="producto(i.productoId)?.imagenUrl" :nombre="nombreProducto(i.productoId)" /></div><strong>{{ nombreProducto(i.productoId) }}</strong></div>
              </td>
              <td v-if="sucursales.length > 1" class="oculto-movil">{{ nombreSucursal(i.sucursalId) }}</td>
              <td style="min-width: 150px">
                <div class="numeros negrita">{{ entero(i.stockActual) }}</div>
                <div class="nivel" role="img" :aria-label="`Nivel de stock ${porcentaje(i)}%`"><div :class="estado(i).tono" :style="{ width: porcentaje(i) + '%' }"></div></div>
              </td>
              <td class="num oculto-movil">{{ i.stockMinimo ?? '—' }}</td>
              <td><Insignia :tono="estado(i).tono">{{ estado(i).texto }}</Insignia></td>
              <td v-if="puedeEditar" class="acciones">
                <button type="button" class="btn btn-secundario btn-sm" @click="abrirMovimiento('ENTRADA', i)">+ Entrada</button>
                <button type="button" class="btn btn-secundario btn-sm" @click="abrirMovimiento('SALIDA', i)">− Salida</button>
                <button type="button" class="btn btn-fantasma btn-sm btn-icono" aria-label="Ver historial" title="Historial de movimientos" @click="verHistorial(i)"><AppIcon name="clock" :size="16" /></button>
                <button type="button" class="btn btn-fantasma btn-sm btn-icono" aria-label="Editar mínimo" title="Editar stock mínimo" @click="abrirEditarItem(i)"><AppIcon name="edit" :size="16" /></button>
                <button v-if="store.esAdmin" type="button" class="btn btn-peligro btn-sm btn-icono" aria-label="Quitar del inventario" @click="eliminar(i)"><AppIcon name="trash" :size="15" /></button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>

    <!-- Movimiento -->
    <AppModal v-model="modalMov" :titulo="mov.tipo === 'ENTRADA' ? 'Registrar entrada' : 'Registrar salida'">
      <form id="form-mov" class="formulario" novalidate @submit.prevent="registrarMovimiento">
        <div v-if="errorMov" class="aviso-linea error" role="alert"><AppIcon name="alert" :size="18" /> <span>{{ errorMov }}</span></div>
        <div class="segmentos" role="group" aria-label="Tipo de movimiento" style="justify-self: start">
          <button type="button" class="segmento" :class="{ activo: mov.tipo === 'ENTRADA' }" @click="mov.tipo = 'ENTRADA'">Entrada</button>
          <button type="button" class="segmento" :class="{ activo: mov.tipo === 'SALIDA' }" @click="mov.tipo = 'SALIDA'">Salida</button>
        </div>
        <Campo label="Producto" requerido v-slot="{ id }">
          <select :id="id" v-model="mov.inventarioId">
            <option v-for="i in inventarios" :key="i.id" :value="i.id">{{ nombreProducto(i.productoId) }}{{ sucursales.length > 1 ? ' · ' + nombreSucursal(i.sucursalId) : '' }} (hay {{ i.stockActual }})</option>
          </select>
        </Campo>
        <Campo label="Cantidad" requerido v-slot="{ id }"><input :id="id" v-model.number="mov.cantidad" type="number" min="1" step="1" inputmode="numeric" /></Campo>
        <Campo label="Motivo (opcional)" v-slot="{ id }">
          <input :id="id" v-model="mov.motivo" maxlength="200" placeholder="Ej: compra a proveedor" />
          <div class="chips" style="margin-top: 6px"><button v-for="m in MOTIVOS[mov.tipo]" :key="m" type="button" class="chip" @click="mov.motivo = m">{{ m }}</button></div>
        </Campo>
        <p v-if="itemMov" class="resultado" :class="{ malo: stockResultante < 0 }">
          Stock: <strong>{{ itemMov.stockActual }}</strong> <AppIcon name="arrowRight" :size="14" /> <strong>{{ stockResultante }}</strong>
        </p>
      </form>
      <template #pie>
        <button type="button" class="btn btn-secundario" @click="modalMov = false">Cancelar</button>
        <button type="submit" form="form-mov" class="btn btn-primario" :disabled="guardandoMov">{{ guardandoMov ? 'Guardando...' : 'Registrar' }}</button>
      </template>
    </AppModal>

    <!-- Alta / edición -->
    <AppModal v-model="modalItem" :titulo="editando ? 'Editar stock mínimo' : 'Agregar producto al inventario'" tamano="sm">
      <form id="form-item" class="formulario" novalidate @submit.prevent="guardarItem">
        <p v-if="editando" class="texto-suave">El stock cambia solo con entradas y salidas, para que quede registrado en el historial.</p>
        <Campo label="Producto" requerido :error="erroresItem.productoId" v-slot="{ id }">
          <select :id="id" v-model="formItem.productoId" :disabled="!!editando"><option :value="null" disabled>Elegí un producto</option><option v-for="p in productos" :key="p.id" :value="p.id">{{ p.nombre }}</option></select>
        </Campo>
        <Campo label="Sucursal" requerido :error="erroresItem.sucursalId" v-slot="{ id }">
          <select :id="id" v-model="formItem.sucursalId" :disabled="!!editando || sucursalFija"><option v-for="s in sucursales" :key="s.id" :value="s.id">{{ s.nombre }}</option></select>
        </Campo>
        <Campo v-if="!editando" label="Stock inicial" :error="erroresItem.stockActual" v-slot="{ id }"><input :id="id" v-model.number="formItem.stockActual" type="number" min="0" step="1" /></Campo>
        <Campo label="Stock mínimo" :error="erroresItem.stockMinimo" ayuda="Cuando baja de este número se genera una alerta." v-slot="{ id }"><input :id="id" v-model.number="formItem.stockMinimo" type="number" min="0" step="1" /></Campo>
      </form>
      <template #pie>
        <button type="button" class="btn btn-secundario" @click="modalItem = false">Cancelar</button>
        <button type="submit" form="form-item" class="btn btn-primario" :disabled="guardandoItem">Guardar</button>
      </template>
    </AppModal>

    <!-- Historial -->
    <AppModal v-model="modalHist" :titulo="histItem ? `Movimientos · ${nombreProducto(histItem.productoId)}` : ''" tamano="lg">
      <div v-if="cargandoHist" class="pila-sm"><span class="esqueleto"></span><span class="esqueleto"></span><span class="esqueleto"></span></div>
      <EstadoVacio v-else-if="!movimientos.length" icono="clock" titulo="Sin movimientos" texto="Todavía no hay entradas ni salidas registradas para este ítem." />
      <div v-else class="tabla-contenedor">
        <table class="tabla">
          <thead><tr><th>Fecha</th><th>Tipo</th><th class="num">Cantidad</th><th>Motivo</th><th v-if="usuarios.length">Usuario</th></tr></thead>
          <tbody>
            <tr v-for="m in movimientos" :key="m.id">
              <td>{{ fechaHora(m.fecha) }}</td>
              <td><Insignia :tono="m.tipo === 'ENTRADA' ? 'ok' : 'aviso'">{{ m.tipo === 'ENTRADA' ? 'Entrada' : 'Salida' }}</Insignia></td>
              <td class="num">{{ m.tipo === 'ENTRADA' ? '+' : '−' }}{{ m.cantidad }}</td>
              <td>{{ m.motivo || '—' }}</td>
              <td v-if="usuarios.length">{{ nombreUsuario(m.usuarioId) }}</td>
            </tr>
          </tbody>
        </table>
      </div>
    </AppModal>
  </div>
</template>

<style scoped>
.herramientas { display: flex; align-items: center; gap: 12px; flex-wrap: wrap; padding: 14px 16px; border-bottom: 1px solid var(--borde); }
.buscador { width: min(300px, 100%); }
.mini { width: 38px; height: 38px; border-radius: 8px; overflow: hidden; flex: none; font-size: 1rem; }
.nivel { height: 6px; border-radius: 3px; background: var(--superficie-2); overflow: hidden; margin-top: 5px; max-width: 150px; }
.nivel > div { height: 100%; border-radius: 3px; }
.nivel .ok { background: var(--ok); }
.nivel .aviso { background: #d9962b; }
.nivel .peligro { background: var(--peligro); }
.resultado { display: flex; align-items: center; gap: 8px; padding: 10px 14px; border-radius: var(--r-sm); background: var(--superficie-2); }
.resultado.malo { background: var(--peligro-suave); color: var(--peligro); }
</style>
