<script setup>
import { ref, computed, onMounted } from 'vue';
import api from '@/api/axios';
import { store, puedeVer } from '@/store';
import { bs, claveDia, hoyLocal, haceCuanto, aFecha } from '@/utils/format';
import AppIcon from '@/ui/AppIcon.vue';
import EncabezadoPagina from '@/ui/EncabezadoPagina.vue';
import TarjetaKpi from '@/ui/TarjetaKpi.vue';
import Insignia from '@/ui/Insignia.vue';
import EstadoVacio from '@/ui/EstadoVacio.vue';

const emit = defineEmits(['ir']);

const productos = ref([]);
const inventarios = ref([]);
const ventas = ref([]);
const pedidos = ref([]);
const cargando = ref(true);

const veVentas = puedeVer('ventas');
const veInventario = puedeVer('inventario');

async function cargar() {
  cargando.value = true;
  const pedir = (url, habilitado = true) => (habilitado ? api.get(url).then((r) => r.data || []).catch(() => []) : Promise.resolve([]));
  [productos.value, inventarios.value, ventas.value, pedidos.value] = await Promise.all([
    pedir('/productos'),
    pedir('/inventarios'),
    pedir('/ventas', veVentas),
    pedir('/pedidos', veVentas),
  ]);
  cargando.value = false;
}

const saludo = computed(() => {
  const h = new Date().getHours();
  return h < 12 ? 'Buenos días' : h < 19 ? 'Buenas tardes' : 'Buenas noches';
});
const fechaTexto = new Date().toLocaleDateString('es-BO', { weekday: 'long', day: 'numeric', month: 'long' });

// ----- Ventas -----
const hoy = hoyLocal();
const ventasDeHoy = computed(() => ventas.value.filter((v) => claveDia(v.fecha) === hoy));
const totalHoy = computed(() => ventasDeHoy.value.reduce((s, v) => s + Number(v.total || 0), 0));

// Últimos 7 días (incluye hoy), con la fecha real y no solo el día de la semana.
const serie = computed(() => {
  const dias = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    dias.push({ clave: claveDia(d), etiqueta: d.toLocaleDateString('es-BO', { weekday: 'short' }).replace('.', ''), total: 0, cantidad: 0 });
  }
  const porClave = Object.fromEntries(dias.map((d) => [d.clave, d]));
  ventas.value.forEach((v) => {
    const d = porClave[claveDia(v.fecha)];
    if (d) { d.total += Number(v.total || 0); d.cantidad++; }
  });
  return dias;
});
const total7 = computed(() => serie.value.reduce((s, d) => s + d.total, 0));
const maxSerie = computed(() => Math.max(1, ...serie.value.map((d) => d.total)));

// ----- Pedidos -----
const META_MIN = 30;
const ESTADOS = [
  { clave: 'PENDIENTE', texto: 'Pendientes', tono: 'aviso' },
  { clave: 'EN PREPARACION', texto: 'En preparación', tono: 'info' },
  { clave: 'LISTO', texto: 'Listos para entregar', tono: 'ok' },
];
const activos = computed(() => pedidos.value.filter((p) => ESTADOS.some((e) => e.clave === p.estado)));
const porEstado = computed(() => ESTADOS.map((e) => ({ ...e, cantidad: pedidos.value.filter((p) => p.estado === e.clave).length })));
const minutosEspera = (p) => Math.max(0, Math.round((Date.now() - aFecha(p.fechaCreacion).getTime()) / 60000));
const fueraDeMeta = computed(() => activos.value.filter((p) => minutosEspera(p) > META_MIN).length);
const ultimosPedidos = computed(() => pedidos.value.slice(0, 6)); // la API ya los trae del más nuevo al más viejo

const tonoEstado = (e) => ({ PENDIENTE: 'aviso', 'EN PREPARACION': 'info', LISTO: 'ok', ENTREGADO: '', CANCELADO: 'peligro' }[e] ?? '');

// ----- Inventario -----
const nombreProducto = (id) => productos.value.find((p) => p.id === id)?.nombre || `Producto #${id}`;
const stockCritico = computed(() =>
  inventarios.value
    .filter((i) => i.stockMinimo != null && i.stockActual <= i.stockMinimo)
    .sort((a, b) => a.stockActual - b.stockActual)
);

const atajos = computed(() =>
  [
    { clave: 'ventas', texto: 'Registrar una venta', icono: 'receipt' },
    { clave: 'pedidos', texto: 'Ver pedidos', icono: 'clipboard' },
    { clave: 'inventario', texto: 'Mover inventario', icono: 'boxes' },
    { clave: 'productos', texto: 'Productos', icono: 'package' },
    { clave: 'reportes', texto: 'Reportes', icono: 'chart' },
  ].filter((a) => puedeVer(a.clave))
);

onMounted(cargar);
</script>

<template>
  <div>
    <EncabezadoPagina :titulo="`${saludo}, ${(store.usuario?.nombre || '').split(' ')[0] || 'equipo'}`" :subtitulo="fechaTexto.charAt(0).toUpperCase() + fechaTexto.slice(1)">
      <button type="button" class="btn btn-secundario" :disabled="cargando" @click="cargar">
        <AppIcon name="refresh" :size="16" :class="{ girando: cargando }" /> Actualizar
      </button>
    </EncabezadoPagina>

    <div class="pila" style="gap: 20px">
      <div class="rejilla-kpi">
        <TarjetaKpi
          v-if="veVentas"
          titulo="Ventas de hoy"
          icono="receipt"
          :valor="bs(totalHoy)"
          :detalle="`${ventasDeHoy.length} ${ventasDeHoy.length === 1 ? 'venta' : 'ventas'}`"
          :cargando="cargando"
        />
        <TarjetaKpi v-if="veVentas" titulo="Últimos 7 días" icono="chart" tono="info" :valor="bs(total7)" detalle="Total vendido" :cargando="cargando" />
        <TarjetaKpi
          v-if="veVentas"
          titulo="Pedidos en curso"
          icono="clipboard"
          tono="aviso"
          :valor="activos.length"
          :detalle="fueraDeMeta ? `${fueraDeMeta} pasan de ${META_MIN} min` : 'Todo dentro de la meta'"
          :cargando="cargando"
        />
        <TarjetaKpi
          v-if="veInventario || veVentas"
          titulo="Stock crítico"
          icono="alert"
          :tono="stockCritico.length ? 'peligro' : 'ok'"
          :valor="stockCritico.length"
          :detalle="stockCritico.length ? 'Productos bajo el mínimo' : 'Sin alertas'"
          :cargando="cargando"
        />
        <TarjetaKpi titulo="Productos" icono="package" tono="ok" :valor="productos.length" detalle="En catálogo" :cargando="cargando" />
      </div>

      <div v-if="atajos.length" class="atajos">
        <button v-for="a in atajos" :key="a.clave" type="button" class="atajo" @click="emit('ir', a.clave)">
          <AppIcon :name="a.icono" :size="18" /> {{ a.texto }}
        </button>
      </div>

      <div class="dos-col">
        <section v-if="veVentas" class="tarjeta">
          <div class="tarjeta-cabecera">
            <h3>Ventas de los últimos 7 días</h3>
            <span class="texto-suave texto-chico">{{ bs(total7) }}</span>
          </div>
          <div class="tarjeta-cuerpo">
            <div v-if="cargando" class="esqueleto" style="height: 180px"></div>
            <EstadoVacio v-else-if="total7 === 0" icono="chart" titulo="Sin ventas esta semana" texto="Cuando registres ventas vas a verlas acá." />
            <div v-else class="barras" role="img" :aria-label="`Ventas de los últimos 7 días: ${bs(total7)}`">
              <div v-for="d in serie" :key="d.clave" class="col" :title="`${d.clave}: ${bs(d.total)} (${d.cantidad} ventas)`">
                <span class="valor numeros">{{ d.total ? Math.round(d.total) : '' }}</span>
                <div class="pista"><div class="barra" :class="{ hoy: d.clave === hoy }" :style="{ height: Math.max(d.total ? 4 : 0, (d.total / maxSerie) * 100) + '%' }"></div></div>
                <span class="etq">{{ d.etiqueta }}</span>
              </div>
            </div>
          </div>
        </section>

        <section v-if="veVentas" class="tarjeta">
          <div class="tarjeta-cabecera"><h3>Pedidos por atender</h3><button type="button" class="btn btn-fantasma btn-sm" @click="emit('ir', 'pedidos')">Ver todos</button></div>
          <div class="tarjeta-cuerpo pila-sm">
            <template v-if="cargando"><span class="esqueleto"></span><span class="esqueleto"></span><span class="esqueleto"></span></template>
            <template v-else>
              <div v-for="e in porEstado" :key="e.clave" class="estado-fila">
                <Insignia :tono="e.tono">{{ e.texto }}</Insignia>
                <strong class="numeros">{{ e.cantidad }}</strong>
              </div>
              <p v-if="!activos.length" class="texto-suave texto-chico">No hay pedidos pendientes. ¡Todo al día!</p>
            </template>
          </div>
        </section>

        <section v-if="veInventario || veVentas" class="tarjeta">
          <div class="tarjeta-cabecera">
            <h3>Stock para reponer</h3>
            <button v-if="veInventario" type="button" class="btn btn-fantasma btn-sm" @click="emit('ir', 'inventario')">Ir al inventario</button>
          </div>
          <div class="tarjeta-cuerpo pila-sm">
            <template v-if="cargando"><span class="esqueleto"></span><span class="esqueleto"></span></template>
            <p v-else-if="!stockCritico.length" class="texto-suave">Todos los productos están sobre su mínimo.</p>
            <template v-else>
              <div v-for="i in stockCritico.slice(0, 6)" :key="i.id" class="estado-fila">
                <span class="truncar">{{ nombreProducto(i.productoId) }}</span>
                <Insignia :tono="i.stockActual <= 0 ? 'peligro' : 'aviso'">{{ i.stockActual <= 0 ? 'Sin stock' : `${i.stockActual} de ${i.stockMinimo}` }}</Insignia>
              </div>
            </template>
          </div>
        </section>

        <section v-if="veVentas" class="tarjeta">
          <div class="tarjeta-cabecera"><h3>Últimos pedidos</h3></div>
          <div class="tabla-contenedor">
            <table class="tabla">
              <tbody>
                <tr v-if="cargando"><td><span class="esqueleto"></span></td></tr>
                <template v-else>
                  <tr v-for="p in ultimosPedidos" :key="p.id">
                    <td>
                      <strong>#{{ p.id }}</strong>
                      <div class="texto-tenue texto-chico">{{ haceCuanto(p.fechaCreacion) }}</div>
                    </td>
                    <td>{{ p.modalidad === 'DELIVERY' ? 'Delivery' : 'Retiro' }}</td>
                    <td class="texto-derecha"><Insignia :tono="tonoEstado(p.estado)">{{ p.estado }}</Insignia></td>
                  </tr>
                </template>
                <tr v-if="!cargando && !ultimosPedidos.length"><td class="texto-suave" style="padding: 24px">Todavía no hay pedidos.</td></tr>
              </tbody>
            </table>
          </div>
        </section>
      </div>
    </div>
  </div>
</template>

<style scoped>
.dos-col { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 20px; align-items: start; }
@media (max-width: 1000px) { .dos-col { grid-template-columns: 1fr; } }

.atajos { display: flex; gap: 10px; flex-wrap: wrap; }
.atajo {
  display: inline-flex; align-items: center; gap: 8px; padding: 9px 14px; border-radius: 999px; cursor: pointer;
  border: 1px solid var(--borde-fuerte); background: var(--superficie); color: var(--texto); font-weight: 600; font-size: 14px;
}
.atajo:hover { border-color: var(--marca); color: var(--marca); background: var(--marca-suave); }

.barras { display: grid; grid-template-columns: repeat(7, 1fr); gap: 10px; height: 210px; align-items: end; }
.col { display: grid; grid-template-rows: 18px 1fr 20px; height: 100%; gap: 4px; text-align: center; }
.valor { font-size: 11px; color: var(--texto-3); }
.pista { display: flex; align-items: flex-end; background: var(--superficie-2); border-radius: 8px; overflow: hidden; }
.barra { width: 100%; background: #d9a867; border-radius: 8px 8px 0 0; transition: height 0.4s ease; }
.barra.hoy { background: var(--marca); }
.etq { font-size: 12px; color: var(--texto-2); text-transform: capitalize; }

.estado-fila { display: flex; align-items: center; justify-content: space-between; gap: 12px; }
</style>
